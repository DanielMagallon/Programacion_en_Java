package InterfazChess;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Timer;

public class Tiempo
{
	int x;
	Timer timer;
	 
	public Tiempo() {
		
		timer = new Timer(1000, new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
				System.out.println(x++);
			}
		});
		
		timer.start();
	}
}

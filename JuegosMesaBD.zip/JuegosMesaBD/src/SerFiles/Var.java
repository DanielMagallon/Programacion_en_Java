package SerFiles;

import java.io.Serializable;


public class Var implements Serializable 
{
	private static final long serialVersionUID = 827766789829679691L;

	public int hora,min,seg,index;

	public Object game;
}

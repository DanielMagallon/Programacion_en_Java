package Perfomance;

import java.util.Vector;

public  class TreeQuery 
{
	public static final String joinJuegosMesa = " inner join juegosmesa jg on p.Id_juego = jg.Id_juego ";
	public static final String joinPartJugadores = " inner join partidas_has_jugadores phj on p.Id_partida = phj.id_partida ";
	public static final String joinJugadores = " inner join jugadores j on phj.Id_jugador = j.Id_jugador ";
	public static final String joinAvatars = " inner join avatars a on j.Id_avatar = a.Id_avatar ";
	public static final String joinPartida = " inner join partidas p on p.Id_partida = phj.Id_partida ";
	public static final String fromPart_Jugadores = " from partidas_has_jugadores phj ";
	public static final String fromPartidas = " from partidas p ";

	
	public static String getTotalPartidasState(String res, String user)
	{
		
		String r = Script.getInstance().consultaUnique(query
				("count(*)", fromPartidas, 
				String.format("where j.Nombre_usuario = '%s' && phj.esado_part='%s';", user,res),
				joinPartJugadores,joinJugadores));
		
		return r;
	}
	
	public static String getTotalPartidasJugadas(String res, String user)
	{
		
		String r = Script.getInstance().consultaUnique(query
				("count(*)", fromPartidas, 
				String.format("where j.Nombre_usuario = '%s';", user,res),
				joinPartJugadores,joinJugadores));
		
		return r;
	}
	
	public static String getTotalPartidasGameState(String user, String res, String game)
	{
		String r = Script.getInstance().consultaUnique(query
				("count(*)", fromPartidas, 
				String.format("where j.Nombre_usuario = '%s' && phj.esado_part='%s' "
				+ "&& jg.Nombre_juego='%s';", user,res,game),
				joinJuegosMesa,joinPartJugadores,joinJugadores));
		
		return r;
	}
	
	public static Vector<String[]> partidasPlayedStateName(String user, String res, String game)
	{
		
		return Script.getInstance().consultaGet(query
				("p.Nombre_partida,p.Tiempo_partida", fromPartidas, 
				String.format("where j.Nombre_usuario = '%s' && phj.esado_part='%s' "
				+ "&& jg.Nombre_juego='%s';", user,res,game),
				joinJuegosMesa,joinPartJugadores,joinJugadores));
	}
	
//	public static Vector<String[]> getPartidaAndDuration(String user,String res,String game)
//	{
//		return  Script.getInstance().consultaGet(query
//				("p.Nombre_partida,p.Tiempo_partida", fromPart_Jugadores, 
//				String.format("where j.Nombre_usuario = '%s' && phj.esado_part='%s' "
//				+ "&& jg.Nombre_juego='%s';", user,res,game),
//				joinJugadores,joinPartida,joinJuegosMesa));
//	}
	
	public static Vector<String[]> getResultPlayers(String id)
	{
		return  Script.getInstance().consultaGet(query
				("j.Nombre_usuario,phj.esado_part", fromPart_Jugadores, 
				String.format("where phj.Id_partida='%s';", id),
				joinJugadores,joinPartida,joinJuegosMesa));
	}
	
	
	public static String query(String selectSource, String from,String where,String...args)
	{
		StringBuilder query = new StringBuilder("select "+selectSource.concat(from));
		
		for(String a : args)
		{
			query.append(a);
		}
		
		query.append(where);
		
//		System.out.println(query);
		
		return query.toString();
	}
	
}

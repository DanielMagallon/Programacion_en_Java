package Perfomance;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JOptionPane;

/**
 * 
 * @author Lalo
 *
 *group by : para agrupar los registros seleccionados en funcion de un campo
 *having: especifica las condicions o criterios que deben cumplir los grupos
 *
 *like: utilizado en la comparacion de un modelo
 *in: utilizado para especificar registros  de una base de datos
 *
 *comando+from+where+group by+order by
 *
 *avg: utilizada para calcular el promedio de los valores de un campo determinado
 *
 */

public class Conexion
{
	public  Connection conexion;

	public String errorConexion;
	
	private DatabaseMetaData metaData;
	
	public Conexion()
	{
		driver();
	}

	
	private void driver()
	{
		try
		{
			Class.forName("com.mysql.jdbc.Driver");

		} catch (ClassNotFoundException e)
		{
			JOptionPane.showMessageDialog(null, "Error en el conector/driver", "Error", 
					JOptionPane.ERROR_MESSAGE);
		}
	}

	public boolean conectarBD(String bd, String localhost,String user, String pass)
	{
			conexion = null;

			try
			{
				conexion = DriverManager.getConnection
						("jdbc:mysql://" + localhost + "/" + bd,user,pass);
				return true;

			}catch(SQLException ex){
		        
				errorConexion = ex.getMessage();
				return false;
		    }
		
	}

	public ResultSet getTables() throws SQLException
	{
		ResultSet r;
		metaData = conexion.getMetaData();
		r = metaData.getTables(null, null, null, null);
		
		return r;
	}

	public void cerrarConexion() throws SQLException 
	{
		if(conexion!=null)
			conexion.close();
	}
}
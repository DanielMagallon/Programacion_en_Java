package Perfomance;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.util.ArrayList;


import Games.General.Metodo;

public class TreeButtonRound extends Draws 
{
	public int ID;
	public String name;
	
	public int middleX;
	public static int posYPuntero;
	
	private Metodo metodo;
	
	public TreeButtonRound(int id) 
	{
		ID = id;
	}
	
	public String texto;
	private int esp;
	private Color cF,cB;
	private Font f;
	public static int size,widthTotal;
	private int index;
	private boolean ciclo=false;
	
	public TreeButtonRound padre;
	
	private int alturaF1,ancho;
	
	private ArrayList<TreeButtonRound> hijos;
	{
		hijos = new ArrayList<>();
	}
	
	public TreeButtonRound(String txt, int espaciado, int altura,int ancho,Font font, Color cF,
						Color background) 
	{
		texto = txt;
		this.ancho = ancho;
		alturaF1 = altura;
		f = font;
		esp = espaciado;
		this.cF = cF;
		cB = background;
	}
	
	public void addAction(Metodo met)
	{
		metodo = met;
	}
	
	public void responder()
	{
		metodo.metodo();
	}
	
	public boolean hasNext()
	{
		ciclo = index<hijos.size(); 
		return ciclo;
	}
	
	public String getTitle() throws IllegalAccessException
	{
		if(!ciclo)
		{
			throw new IllegalAccessException("getTitle()->Este metodo debe ser llamado con los metodos next() y hasNext();");
		}
		return hijos.get(index).texto;
	}
	
	public TreeButtonRound aux;
	
	public boolean isOnNode(int x, int y, boolean onNode, TreeButtonRound b, TreeButtonRound padre)
	{
			
		if(isOnText(x, y))
		{
			padre.aux = b==null ? padre : b;
			return  true;
		}
		
		for(TreeButtonRound bs : hijos)
		{
			onNode = bs.isOnNode(x, y,onNode,bs,padre);
		}

		return onNode;
	}
	
	public TreeButtonRound next()
	{
		if(!ciclo) ciclo = true;
		return hijos.get(index++);
	}
	
	public void addChild(TreeButtonRound btn)
	{
		btn.padre = this;
		size+=btn.alturaF1+180;
		Canvas c = new Canvas();
		widthTotal+=btn.ancho+c.getFontMetrics(btn.f).stringWidth(btn.texto)+100;
		
		hijos.add(btn);
	}
	
	public void drawAll(Graphics g)
	{
		for(TreeButtonRound b : hijos)
		{
			drawChild(b, g);
			b.drawAll(g);
		}
	}
	
	public void vaciar()
	{
		
		for(TreeButtonRound b : hijos)
		{
			b.vaciar();
			b.hijos.clear();
		}
		index = 0;
	}
	
	public void padreNull()
	{
		hijos.clear();
		aux = null;
	}
	
	@Override
	public void drawTextInRound(String txt, int x, int y, int espaciado, Font font, Color cF, 
			Color background,Graphics g) 
	{
		super.drawTextInRound(txt, x, y, espaciado, font, cF, background, g);
		
		middleX = (x1Text-x0Text)/2+x0Text;
	}
	
	public int posChild;
	public void drawChild(TreeButtonRound btn, Graphics g)
	{
		if(posYPuntero==0)
			posYPuntero = y1Text+btn.alturaF1;
		
		posChild = (posYPuntero-(y1Text-y0Text)/2);
		g.setColor(Color.BLACK);
		g.drawLine(middleX, y1Text, middleX, posYPuntero);
		g.drawLine(middleX, posYPuntero, middleX+btn.ancho, posYPuntero);
		
		btn.drawTextInRound(btn.texto, middleX+btn.ancho+btn.esp, posChild, btn.esp, btn.f, 
				btn.cF, btn.cB, g);
		posYPuntero+=btn.alturaF1;
	}
	
	public final int getX0()
	{
		return x0Text;
	}
	
	public final int getX1()
	{
		return x1Text;
	}

	
	public final int getY0()
	{
		return y0Text;
	}

	
	public final int getY1()
	{
		return y1Text;
	}


	
}

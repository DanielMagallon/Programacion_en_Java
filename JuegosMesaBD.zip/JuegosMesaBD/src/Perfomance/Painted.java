package Perfomance;

import java.awt.Graphics;

public interface Painted {
	
	void paintGraphics(Graphics g);
}

package Perfomance;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Vector;

import javax.swing.JOptionPane;

public class Script {
	// Subconsulta: select * from Automovil where rfc in (Select rfc from clientes
	// where edad>30);

	// select Nombre_jugador,Esado_part from Jugadores as j inner join
	// partidas_has_jugadores
	// as pj on j.Id_jugador = pj.Id_jugador and pj.Id_partida=3;

	// select Nombre_jugador,Esado_part from Jugadores as j inner join
	// partidas_has_jugadores
//	 as pj on j.Id_jugador = pj.Id_jugador and pj.Esado_part = 1 inner join Partidas as p
//		     on p.Id_juego = 1;

	private Conexion conector;
	private ResultSet rs;
	private Statement st;
//	private PreparedStatement ps;
	
	public String[] columnsName;
	public Vector<String[]> datosTable;
	public Vector<String> tablas;
	
	public String bdActual;
	
	private static Script script;

	
	private Script() {
		conector = new Conexion();
		tablas = new Vector<>();
	}

	public static Script getInstance() {
		if (script == null)
			script = new Script();

		return script;
	}

	public boolean conectar(String bd, String localhost, String user, String pass) {
		try 
		{
			conector.cerrarConexion();
			if(conector.conectarBD(bd, localhost, user, pass))
			{
				tablas();
				st = conector.conexion.createStatement();
				bdActual = bd;
				return true;
			}
			
		} 
		catch (SQLException e) 
		{
			conector.errorConexion = e.getMessage();
			
		}
		return false;
	}
	
	private void tablas()
	{
		tablas.clear();
		
		try 
		{
			ResultSet r = conector.getTables();
			while(r.next())
			{
				tablas.add(r.getString("TABLE_NAME"));
			}
			
			r.close();
			
		} 
		catch (SQLException e)
		{
			JOptionPane.showMessageDialog(null, e.getMessage(), "No se pudieron extraer las tablas\n"
					+ "Pero se puede hacer movimientos con ellas", 
					JOptionPane.WARNING_MESSAGE);
		}
	}
	
	public boolean isAutoIncrement(int column)
	{
		try 
		{
			ResultSetMetaData r = rs.getMetaData();

			return r.isAutoIncrement(column+1);
			
		} catch (SQLException e) {

			return false;
		}
	}
	
	
	public String getErrorConexion() {
		return conector.errorConexion;
	}

	public boolean delete(String query)
	{
		return Query(query, "No se pudo eliminar", "Registro eliminado de la base de datos",true);
	}
	
	public boolean update(String query)
	{
		return Query(query, "No se pudo modificar", "Registro modificado de la base de datos",true);
	}
	
	public boolean insert(String query,boolean showed)
	{
		return Query(query, "No se pudo agregar un nuevo registro", 
				"Registro agregado en la base de datos",showed);
	}
	
	public boolean internalQuerys(String query)
	{
		return Query(query, "Consulta incorrecta", "",false);
	}
	
	public boolean exists(String reg, int campo)
	{
		for(String regs[] : datosTable)
		{
			if(regs[campo].equalsIgnoreCase(reg))
			{
				return true;
			}
		}
		
		return false;
	}
	
	public boolean exists(String reg, String table, String campo)
	{
		try 
		{
			rs = st.executeQuery(String.format
					("select count(*) from %s where %s = '%s';", table,campo,reg));

			if(rs.next())
			{
				return !(rs.getInt(1) == 0);
			}
		} 
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
	}
	
	public boolean exists(String reg, String table, String campo, String id)
	{
		try 
		{
			rs = st.executeQuery(String.format
					("select count(*) from %s where %s = '%s' && %s;", table,campo,reg,id));

			if(rs.next())
			{
				return !(rs.getInt(1) == 0);
			}
		} 
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
	}
	
	private boolean Query(String query, String errorMsg, String correctMsg,boolean show) {

		try {
//			st = conector.conexion.createStatement();

			st.executeUpdate(query);

			if(show)
			JOptionPane.showMessageDialog(null, correctMsg, "Todo salio bien", 
					JOptionPane.INFORMATION_MESSAGE);
			
			return true;

		} catch (SQLException e) {
			
			JOptionPane.showMessageDialog(null, e.getMessage(), errorMsg,
					JOptionPane.ERROR_MESSAGE);
			
			return false;
		}
	}

//	public void agregarV(String nombre, int edad) {
//		String con = "INSERT INTO proyectos Values(?,?)";
//
//		try {
//			ps = conector.conexion.prepareStatement(con);
//
//			ps.setInt(1, edad);
//			ps.setString(2, nombre);
//			ps.execute();
//			System.out.println("Agregado");
//
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	}

//	public Vector<Vector<String>> consulta(String consulta) {
//		Vector<Vector<String>> vector = new Vector<Vector<String>>();
//
//		try {
//
//			st = conector.conexion.createStatement();
//
//			// Execute query-> cuando no se altera la bd
//			// Ecuteupdat cuando si, (insert into)
//			rs = st.executeQuery(consulta);
//			int ind = 0;
//
//			while (rs.next()) {
//				vector.add(new Vector<String>());
//				vector.get(ind).add(rs.getInt(1) + "");
//				vector.get(ind).add(rs.getString(2));
//				ind++;
//			}
//
//		} catch (SQLException e) {
//			System.out.println("Error al consultar");
//			e.printStackTrace();
//		}
//
//		return vector;
//	}

	public void consultadaMetaData(String co) {

		try {
//			st = conector.conexion.createStatement();

			getColumnTables(co);

			int cols = columnsName.length;

			datosTable = new Vector<>();

			while (rs.next()) 
			{
				String datos[] = new String[cols];

				for (int i = 1; i <= cols; i++) {
					datos[i - 1] = rs.getString(i);
				}

				datosTable.add(datos);
			}
			
		} catch (SQLException e) {
			showSqlError(e.getMessage());
		}

	}
	
	public Vector<String[]> consultaGet(String co)
	{
		try {

			Vector<String[]> datosv = new Vector<>();

			rs = st.executeQuery(co);
			
			int cols = rs.getMetaData().getColumnCount();
			
			while (rs.next()) 
			{
				String datos[] = new String[cols];

				for (int i = 1; i <= cols; i++) {
					datos[i - 1] = rs.getString(i);
				}

				datosv.add(datos);
			}
			return datosv;
			
		} catch (SQLException e) {
			showSqlError(e.getMessage());
		}
		
		return null;
		
	}
	
	
	public String consultaUnique(String con)
	{
		try {
			rs = st.executeQuery(con);
			
			
			if(rs.next())
			{
				return rs.getString(1);
			}
			
		} catch (SQLException e) {
			showSqlError(e.getMessage());
		}
		
		return null;
	}
	
	
	public String getIdPrimaryColumn(String table)
	{
		String query = String.format("show columns from %s;", table);
		
		try 
		{
//			st = conector.conexion.createStatement();
			rs = st.executeQuery(query);
			
			
			while(rs.next()) 
			{
				if(rs.getString("Key").equalsIgnoreCase("PRI"))
				{
					return rs.getString("Field");
				}
			}
			
		} 
		catch (SQLException e) 
		{
			showSqlError(e.getMessage());
		}
		
		return "";
	}
	
	public ArrayList<String> getIdForeignColumns(String table)
	{
		String query = String.format("show columns from %s;", table);
		ArrayList<String> list = new ArrayList<>();
		
		try 
		{
			rs = st.executeQuery(query);
			
			
			while(rs.next()) 
			{
				if(rs.getString("Key").equalsIgnoreCase("MUL"))
				{
					list.add(rs.getString("Field"));
				}
			}
			
		} 
		catch (SQLException e) 
		{
			showSqlError(e.getMessage());
		}
		
		return list;
	}
	
	public void getColumnTables(String co)
	{
		ResultSetMetaData r=null;
		try 
		{
			rs = st.executeQuery(co);
			r = rs.getMetaData();
			int cols = r.getColumnCount();
			columnsName = new String[cols];
			for (int i = 1; i <= cols; i++) {
				columnsName[i - 1] = r.getColumnName(i);
			}
			
		} catch (SQLException e) {
			showSqlError(e.getMessage());
		}
		
		
	}
	
	private void showSqlError(String msg)
	{
		JOptionPane.showMessageDialog(null, msg, "Ocurrio en error", JOptionPane.ERROR_MESSAGE);
	}
	


}

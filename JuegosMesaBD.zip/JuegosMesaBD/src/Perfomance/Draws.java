package Perfomance;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;

public  class Draws 
{
	 public int xHueco;

	 public int yHueco;

	 public int lado;

	 public int xImg;

	 public int yImg;

	 public int ladoImg;
	
	 public int diagonal;
	
	 Color colorAro,colorHueco;
	
	public void colorAro(Color c)
	{
		colorAro = c;
		
	}
	
	public void colorHueco(Color c)
	{
		colorHueco = c;
	}
	
	public void dibujarAro( int x,  int y, int diametro, int grosorAro,Graphics g)
	{
		g.setColor(colorAro);
		g.fillOval(x, y, diametro, diametro);

		lado = diametro-grosorAro*2;
		
		xHueco = x+grosorAro;
		yHueco = y+grosorAro;
		
		g.setColor(colorHueco);
		g.fillOval(xHueco,yHueco,lado,lado);
	}
	
	public  void drawInternalAroImage(Image img,Graphics g)
	{
		g.setColor(Color.BLACK);
		diagonal = (lado*15)/100;
		
		xImg = xHueco+diagonal;
		yImg = yHueco+diagonal;
		ladoImg = lado - ((xImg-xHueco)*2);
		
		g.drawImage(img, xImg, yImg, ladoImg, ladoImg, null);
		
	}
	
	 public int xNext,yNext,hNext,x0Next,y0Next,xBef,yBef,hBef,x0Bef,y0Bef; 
	 Color next,before;
	
	public void colorNext(Color c)
	{
		next = c;
	}
	
	public void colorBefor(Color c)
	{
		before = c;
	}
	
	public void drawNext( int x,  int y,  int h,  int w, Graphics g)
	{
		x0Next = x;
		y0Next = y;
		xNext = x + w;
		yNext = y + h;
		hNext = y+h*2;
		g.setColor(next);
		
		Graphics2D g2 = (Graphics2D) g;
		g2.setStroke(new BasicStroke(7f));
	
		g2.drawLine(x, y, xNext, yNext);
		g2.drawLine(x, hNext, xNext, yNext);
		
	}
	
	public void drawBefore( int x,  int y,  int h,  int w, Graphics g)
	{
		x0Bef = x;
		y0Bef = y;
		xBef = x - w;
		yBef = y + h;
		hBef = y+h*2;
		
		g.setColor(before);
		
		Graphics2D g2 = (Graphics2D) g;
		g2.setStroke(new BasicStroke(7f));
	
		g2.drawLine(x, y, xBef, yBef);
		g2.drawLine(x, hBef, xBef, yBef);
	}
	
	public int xContorno,yContorno,wContorno,hContorno;
	Color colorContorno,colorContHueco;
	
	public void setColorContorno(Color c)
	{
		colorContorno = c;
	}
	
	public void setColorHueco(Color c)
	{
		colorContHueco = c;
	}
	
	public void drawContour( int x,  int y,  int w, int h, int grosorW, int grosorH,Graphics g)
	{
		g.setColor(colorContorno);
		g.fillRect(x, y, w, h);
		
		xContorno = x+grosorW;
		yContorno = y+grosorH;
		
		g.setColor(colorContHueco);
		
		wContorno = w - grosorW*2;
		hContorno = h - grosorH*2;
		
		g.fillRect(xContorno, yContorno, wContorno, hContorno);
		
	}
	
	public int xImage,yImage,witdhImage,heiImage,compX=5,compY=5;
	
	public void drawInternalImageContour(Image img, Graphics g)
	{
		xImage = xContorno+compX;
		yImage = yContorno+compY;
		
		witdhImage = wContorno - compX*2;
		heiImage = hContorno - compY*2;
		
		g.drawImage(img, xImage, yImage, witdhImage, heiImage, null);
	}
	
	
	public int x0Text,y0Text,x1Text,y1Text;
	public void drawTextInRound(String txt, int x, int y,int espaciado, Font font, Color cF,
								Color background,Graphics g)
	{
		g.setFont(font);
		int wid = g.getFontMetrics().stringWidth(txt);
		int hei = g.getFontMetrics().getHeight();
		
		g.setColor(background);
		
		x0Text = x-espaciado;
		y0Text = y;
		x1Text = x + (wid+espaciado*2)-espaciado;
		y1Text = y + hei;
		
		g.fillRoundRect(x0Text, y, wid+espaciado*2, hei, 100, 100);
		
		g.setColor(cF);
		g.drawString(txt, x, y+g.getFontMetrics().getMaxAscent());
	}
	
	
	public boolean isOnText(int x, int y)
	{
		return (x>=x0Text && x<=x1Text) && (y>=y0Text && y<=y1Text);
	}
	
	public boolean isOnImageContour(int x, int y)
	{
		return (x>=xImage && x<=xImage+witdhImage) && (y>=yImage && y<=yImage+heiImage);
	}
	
	public boolean isOnNext( int x,  int y)
	{
		return (x>=x0Next && x<=xNext) &&
			   (y>=y0Next && y<=hNext);
	}
	
	public boolean isOnBefore( int x,  int y)
	{
		return (x>=xBef && x<=x0Bef) &&
			   (y>=y0Bef && y<=hBef);
	}
	
	public boolean isOnImage( int x,  int y)
	{
		return (x>=xImg && x<=(xImg+ladoImg)) && ((y>=yImg && y<=(yImg+ladoImg)));
	}
	
}

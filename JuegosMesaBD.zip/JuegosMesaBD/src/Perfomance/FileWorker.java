package Perfomance;

import java.io.File;

public class FileWorker 
{
	public static void deleteFiles(String path)
	{
		File ruta = new File(path);
		
		File[] files = ruta.listFiles();
		
		for(File f : files)
		{
			if(f.delete())
				System.out.println("Elimnated: "+f.getName());
		}
	}
}

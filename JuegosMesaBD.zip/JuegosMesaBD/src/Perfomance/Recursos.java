package Perfomance;

import java.awt.Cursor;
import java.awt.Image;
import java.util.Vector;

import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;

public class Recursos {

	public static ImageIcon playIcon,addAvatar,tablaImg,searchIcon,cancelIcon,
				   startGame,seePlayers,addGame,upBig,downBig,renaudarIc,pause,fullScreen,
				   reset,suspendGame; 
	
	public static Image fondo;
	
	public static Cursor handCursor;
	
	public static JFileChooser fileChosser;
	
	public static String pathAvatars,pathMiniAvatars,pathIconsGame,pathFilesGame;
	
	public static String pathResources;
	
	public static String[][] imgAvatar,users;
	
	public static void updateAvatars()
	{
		Vector<String[]> vec = Script.getInstance().consultaGet("select * from avatars");
		
		imgAvatar = new String[vec.size()][2];
		
		for(int i=0; i<imgAvatar.length; i++)
		{
			imgAvatar[i][0] = vec.get(i)[0];
			imgAvatar[i][1] = vec.get(i)[1];
			
		}
	}
	
	public static void updateUsers()
	{
		Vector<String[]> vec = Script.getInstance().consultaGet(
				"select Nombre_jugador, Nombre_usuario, Imagen_avatar from jugadores as j " + 
			"inner join avatars as a on j.Id_avatar = a.Id_avatar order by Id_jugador;");
		
		users = new String[vec.size()][3];
		
		for(int i=0; i<users.length; i++)
		{
			users[i][0] = vec.get(i)[0];
			users[i][1] = vec.get(i)[1];
			users[i][2] = vec.get(i)[2];
			
		}
	}
	
	static
	{
		handCursor = new Cursor(Cursor.HAND_CURSOR);
		
		fileChosser = new JFileChooser();
		fileChosser.setFileFilter(new FileNameExtensionFilter(
				"Imagenes", "png","jpg","jpeg","gif"));
		
		
		pathResources = System.getProperty("user.dir")+"/src";
		
		upBig = getImage("/Recursos/", "upBig.png");
		
		reset = getImage("/Recursos/", "reset.png");
		
		fullScreen = getImage("/Recursos/", "full-screen.png");
		
		suspendGame = getImage("/Recursos/", "suspend.png");
		
		fondo = getImage("/Recursos/", "fondo.jpg").getImage();
		
		renaudarIc = getImage("/Recursos/", "renaudar.png");
		
		pause = getImage("/Recursos/", "pausar.png");
		
		downBig = getImage("/Recursos/", "downBig.png");
		
		addGame = getImage("/Recursos/", "addgame.png");
		
		addAvatar = getImage("/Recursos/", "adduser.png"); 
				
		startGame = getImage("/Recursos/", "startG.png");
		
		seePlayers = getImage("/Recursos/", "seePlayers.png");
		
		tablaImg = getImage("/Recursos/", "table.png");
		
		playIcon = getImage("/Recursos/","play.png");
		
		searchIcon = getImage("/Recursos/", "search.png");
		
		cancelIcon = getImage("/Recursos/", "cancel.png");
		
		pathIconsGame = pathResources+"/Recursos/Icon_games/";
		pathAvatars = pathResources+"/Recursos/Avatar/";
		pathMiniAvatars = pathResources+"/Recursos/Avatar/Mini/";
		pathFilesGame = pathResources+"/SerFiles/";
		
	}
	
	public static ImageIcon getImage(String ruta, String file)
	{
		return new ImageIcon(pathResources+ruta+file);
	}
}

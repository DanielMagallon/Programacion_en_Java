package Perfomance;

public interface MetodoGet<T> {

	T metodo();
}

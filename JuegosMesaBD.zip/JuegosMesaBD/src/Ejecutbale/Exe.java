package Ejecutbale;


import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JSplitPane;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

import Interfaz.FrameGame;
import Interfaz.PanelTablas;
import Perfomance.Script;


public class Exe extends JFrame
{

	private static final long serialVersionUID = 2299854356196491341L;
	
	private JMenuBar menuBar;
	
	public static WindowConnection windConect;
	
	private JSplitPane split;
	
	protected PanelTablas panelTablas;
	
	public Exe() 
	{

		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setExtendedState(MAXIMIZED_BOTH);
		setLayout(new BorderLayout());
		
		windConect = new WindowConnection(this);
		panelTablas = new PanelTablas();
		split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
		split.setLeftComponent(panelTablas);
		
		add(split,"Center");
		
		menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		addMenus();
		
		split.add(FrameGame.getInstance());
		
		windConect.conectar();
	
		
		
		setVisible(true);
		
	}
	
	private void addMenus()
	{
		JMenu menuProg = new JMenu("Programa");
		menuBar.add(menuProg);
		
		JMenuItem menuConect = new JMenuItem("Conectarse a una base de datos");
		menuConect.addActionListener((a)-> windConect.setVisible(true));
		
		menuProg.add(menuConect);
	}
	
	
	
	public static void main(String[] args)
	{
		SwingUtilities.invokeLater(()-> {
		        
		        new Exe();
		});
	}
	
	public class WindowConnection extends JDialog
	{
		private static final long serialVersionUID = -1364243316523129134L;
		
		private JTextField txtsDatos[];
		private JComboBox<String> comboDB;
		private Exe exe;
		private String defaults[] = {"juegosdemesa","localhost","root","root"};

		public WindowConnection(Exe ej) 
		{
			setSize(550, 220);
			setLocationRelativeTo(null);
			setDefaultCloseOperation(DISPOSE_ON_CLOSE);
			setModal(true);

			exe = ej;
			
			JLabel lbls[] = 
				{new JLabel("Base de datos: ",JLabel.CENTER), new JLabel("Localhost",JLabel.CENTER),
					 new JLabel("Usuario: ",JLabel.CENTER), new JLabel("Contrasenia",JLabel.CENTER)};
			
			txtsDatos = new JTextField[3];

			comboDB = new JComboBox<>(); 
			
			JPanel panelDatos = new JPanel();
			
			panelDatos.setLayout(new GridLayout(4, 2, 10, 15));
			
			
			for(int i=0; i<4; i++)
			{
				if(i==0) 
				{
					panelDatos.add(lbls[i]);
					panelDatos.add(comboDB);
					continue;
				}
				
				if(i!=3)
					txtsDatos[i-1] = new JTextField(defaults[i],15);
				
				else
				{
					txtsDatos[i-1] = new JPasswordField(defaults[i],15);
					((JPasswordField) txtsDatos[i-1]).setEchoChar('*');
				}
				
				panelDatos.add(lbls[i]);
				panelDatos.add(txtsDatos[i-1]);
			}
			
			JPanel panelBtns = new JPanel();
			
			JButton conect = new JButton("Conectar");
			conect.addActionListener((a)-> 
			{
				for(int i=0; i<txtsDatos.length; i++)
				{
					if(txtsDatos[i].getText().trim().isEmpty())
					{
						JOptionPane.showMessageDialog(this, "Todos los campos deben ser rellenados",
								"Campo: "+lbls[i+1].getText()+" no valido", JOptionPane.ERROR_MESSAGE);
						return;
					}
				}

				String bd = comboDB.getSelectedItem().toString();
			
				if(Script.getInstance().conectar (bd,txtsDatos[0].getText().trim(),
						txtsDatos[1].getText().trim(), txtsDatos[2].getText().trim()))
				{
					JOptionPane.showMessageDialog(this, "Conectado", "Conexion satisfactoria", 
							JOptionPane.INFORMATION_MESSAGE);
					exe.setTitle("Base de datos conectada: "+bd);
					exe.panelTablas.actualizar(bd, Script.getInstance().tablas);
					this.dispose();
					
				}
				
				else
				{
					JOptionPane.showMessageDialog(this, Script.getInstance().getErrorConexion(), 
							"Conexion fallida", 
							JOptionPane.ERROR_MESSAGE);
				}
				
			});
			panelBtns.add(conect);
			
			JButton cancel = new JButton("Cancelar");
			cancel.addActionListener((a)-> this.dispose());
			panelBtns.add(cancel);
			
			add(panelBtns, "South");
			add(panelDatos,"Center");
		}
		
		public void conectar()
		{
			Script.getInstance().conectar (defaults[0],defaults[1], defaults[2],
					defaults[3]);
			
			exe.setTitle("Base de datos conectada: Juegosdemesa");
			exe.panelTablas.actualizar("juegosdemesa", Script.getInstance().tablas);
			
			Vector<String[]> v = Script.getInstance().consultaGet("show databases;");

			for(String ds[] : v)
			{
				comboDB.addItem(ds[0]);
			}
			
		}
	}
}



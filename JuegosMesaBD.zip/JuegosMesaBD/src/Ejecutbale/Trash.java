package Ejecutbale;


public class Trash{

	/*
	 * Vector<String[]> s = Script.getInstance().consultaGet
				
				("SELECT * FROM information_schema.TABLE_CONSTRAINTS  WHERE "
						+ "information_schema.TABLE_CONSTRAINTS.CONSTRAINT_TYPE = 'FOREIGN KEY'  "
						+ "AND information_schema.TABLE_CONSTRAINTS.TABLE_SCHEMA = 'juegosdemesa' "
						+ "AND information_schema.TABLE_CONSTRAINTS.TABLE_NAME = 'partidas';");
				
				for(String d[] : s)
				{
					for(String  fg : d)
					{
						System.out.print(fg+" ");
					}
					
					System.out.println();
				}
				
				
				
	 */
	
//	@Override
//	protected void paintComponent(Graphics g)
//	{
//		super.paintComponent(g);
//		
//		Graphics2D g2d = (Graphics2D) g;
//		g2d.setPaint(new GradientPaint(200, 100, Color.red, 400, 200, Color.white));
//		g.fillOval(100, 200, 500, 500);
//		g.fillOval(100, 200, 700, 700);
	
//		g.setColor(Color.WHITE);
//		g.fillOval(125, 225, 450, 450);
//		g.fillOval(125, 225, 650, 650);
//	}
}

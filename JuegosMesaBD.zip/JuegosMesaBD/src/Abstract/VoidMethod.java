package Abstract;

public interface VoidMethod
{

	public void method();
	
}

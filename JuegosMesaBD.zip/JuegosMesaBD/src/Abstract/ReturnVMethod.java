package Abstract;

public interface ReturnVMethod {

	public boolean get();
}

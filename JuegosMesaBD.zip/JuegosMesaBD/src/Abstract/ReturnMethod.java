package Abstract;

public interface ReturnMethod<T>  {

	public boolean method_get(T t);
}

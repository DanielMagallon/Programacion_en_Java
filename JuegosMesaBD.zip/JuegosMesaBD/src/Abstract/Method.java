package Abstract;


@FunctionalInterface
public interface Method
{
	public void method(int i, int j);
}

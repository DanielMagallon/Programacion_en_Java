package Abstract;

public interface VoidMethodParameter<T>{
	
	public void method(T t);
}

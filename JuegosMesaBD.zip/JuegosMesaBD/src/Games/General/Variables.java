package Games.General;

import java.awt.Color;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.border.Border;

public class Variables
{
	public static int iFor,jFor;
	
	public static Border bordeNegro = BorderFactory.createLineBorder(Color.BLACK);
	
	public static final int jugador1 = 2;
	public static final int jugador2 = -jugador1;
	
	public static ImageIcon fichaGato = getImgIcon("/Gato/Recursos/", "circle.png");
	public static ImageIcon fichaGato2 = getImgIcon("/Gato/Recursos/", "cross.png");
	
	public static ImageIcon getImgIcon(String ruta, String file)
	{
		return new ImageIcon(Variables.class.getResource("/Games"+ruta+file));
	}
}

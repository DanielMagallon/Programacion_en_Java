package Games.General;


public interface SerializableGame<T> {

	void deserializarJuego(Game<?> juegoGeneral,T t);

}

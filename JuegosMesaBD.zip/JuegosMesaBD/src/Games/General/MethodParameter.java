package Games.General;

public interface MethodParameter<T> {

	void methodSet(T t);
}

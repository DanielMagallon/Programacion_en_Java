package Games.General;

import javax.swing.JLabel;

@SuppressWarnings("serial")
public class Casilla extends JLabel
{
}

package Games.General;

import java.awt.AlphaComposite;
import java.awt.BorderLayout;
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.io.File;
import java.io.Serializable;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.Timer;

import Interfaz.TimeGame;
import Perfomance.Recursos;
import Perfomance.Script;
import Perfomance.Serializa;
import SerFiles.Var;


@SuppressWarnings("serial")
public abstract class Game<T extends JComponent> implements Serializable
{
	public transient String nombreJuego,nombrePart,idPart;
	public transient T fg;
	public transient List<Object[]> datos_jugadores;
	protected transient PanelTexto panelText;
	protected transient JPanel contenedor,infoGame;
	protected transient JList<String> jugadoresList; 
	protected transient String idGame;
	protected transient TimeGame timer;
	protected transient JLabel lblTurnoPlayer;
	protected transient Object jugador[];
	protected transient int index,indexant;
	private transient JPanel panelNombreP;
	private transient JTextField txtName;
	private transient boolean continueGame,isShowedGame,isFinished;
	
	public void init(T g,String name,String id, List<Object[]>lista, TimeGame timer)
	{
		continueGame = isFinished = false;
		datos_jugadores = lista;
		this.timer = timer;
		idGame = id;
		contenedor = new JPanel();
		contenedor.setLayout(new BorderLayout());
		infoGame = new JPanel();
		infoGame.setLayout(new BorderLayout());
		contenedor.add(infoGame,"West");
		jugadoresList = new JList<>();
		infoGame.add(new JScrollPane(jugadoresList),"Center");
		lblTurnoPlayer = new JLabel("",JLabel.LEFT);
		infoGame.add(lblTurnoPlayer,"South");
		nombreJuego = name;
		fg = g;
		panelText = new PanelTexto("Presione el boton amarillo para jugar");
		
		DefaultListModel<String> model = new DefaultListModel<>();
		jugadoresList.setPreferredSize(new Dimension(200, 300));
		jugadoresList.setModel(model);
		jugadoresList.setEnabled(false);
		
		model.addElement("Turno de los jugadores: ");
		for(Object[] d : lista)
		{
			model.addElement(d[2].toString());
		}
		
		index=-1;
		nextPlayer();
		
		panelNombreP = new JPanel();
		panelNombreP.setBorder(BorderFactory.createTitledBorder("Nombre de la partida"));
		panelNombreP.add(txtName = new JTextField(15));
		infoGame.add(panelNombreP,"North");
	}
	
	public abstract void initGame();
	
	public boolean isShowedGame()
	{
		return isShowedGame;
	}
	
	public boolean isFinished() {
		return isFinished;
	}
	
	public void continueGame(int index,String part, String idPart,Object gameSer)
	{
		this.index = index;
		continueGame = true;
		nombrePart = part;
		isFinished = false;
		this.idPart = idPart;
		txtName.setText(part);
		txtName.setEditable(false);
		nextPlayer();
	}
	
	
	public void play()
	{
		panelText.parar();
		isShowedGame = true;
		fg.remove(panelText);
	}
	
	public void stop()
	{
		fg.add(panelText);
		panelText.start();
		isShowedGame = false;
	}
	
	public void reset()
	{
		index=-1;
		nextPlayer();
	}
	
	public int suspend()
	{
		fg.add(panelText);
		onFinish(Estado_Partida.SUSPENDED, null);
		
		Var variables = new Var();
		
		variables.index = indexant;
		variables.hora = timer.h;
		variables.min = timer.min;
		variables.seg = timer.seg;
		variables.game = getSerGame();
		
		Serializa.saveObject(variables, new File(Recursos.pathFilesGame+nombreJuego+"/"+nombrePart+".part"));

		JOptionPane.showMessageDialog(contenedor, "Partida guardarda");
		
		return 1;
	}
	
	public abstract Object getSerGame();
	
	public JPanel getContenedor() {
		return contenedor;
	}
	
	public void nextPlayer()
	{
		indexant = index;
		index++;
		
		jugador = datos_jugadores.get(index);
		jugadoresList.setSelectedIndex(index+1);
		
		lblTurnoPlayer.setText("Turno de: "+jugador[2]);
//		lblTurnoPlayer.setText("Turno de: "+indexant);
		lblTurnoPlayer.setIcon((ImageIcon)jugador[0]);
		
		if(index==datos_jugadores.size()-1)
		{
			index = -1;
		}
	}
	
	public String getActualPlayer()
	{
		return jugador[2].toString();
	}
	
	public void onFinish(Estado_Partida estado, String winner)
	{
		timer.finished();
		String duration=timer.getDuration();
		isFinished = true;
		
		if(continueGame)
		{
			estado.updateQuery(datos_jugadores, idPart, winner,duration);
		}
		
		else
		{
			nombrePart=txtName.getText();
		
			while(true)
			{
				if( nombrePart == null || nombrePart.equals("")  || Script.getInstance().exists(nombrePart, "partidas", "Nombre_partida", 
						"id_juego='"+idGame+"'"))
				{
					JOptionPane.showMessageDialog(contenedor, "Nombre no valido\n"
							+ "Puede que la partida con ese nombre ya exista o no se haya especificado un nombre", 
							"Partida existente en el juego: "+nombreJuego, JOptionPane.ERROR_MESSAGE);
					
					nombrePart = JOptionPane.showInputDialog("Ingregsar nombre: ");
					
				}
					else break;
			}
			
					
			String consulta = String.format("insert into partidas (Nombre_partida,"
			+ "Id_juego,Tiempo_Partida) values ('%s', '%s', '%s');", nombrePart,idGame,duration);
			
			if(Script.getInstance().insert(consulta,false))
			{
				idPart = Script.getInstance().consultaUnique(String.format
				("select Id_partida from partidas  where Nombre_partida='%s' && id_juego=%s", 
						nombrePart,idGame));
				
				estado.makeQuery(datos_jugadores, idPart, winner);
				
				
			}
			else {
				JOptionPane.showMessageDialog(contenedor, "No se pudo guardar la partida en la bd", 
						"Error al guardar", JOptionPane.ERROR_MESSAGE);
			}
		}
		
		continueGame=false;
		txtName.setEditable(true);
		txtName.setText("");
	}
	
	 
	class PanelTexto extends JPanel
	{
		private Timer timer;
		private int x,ancho;
		private Font fuente;
		private String c;
		
		public PanelTexto(String cad) 
		{
			c = cad;
			fuente = new Font("Serif", Font.ITALIC|Font.BOLD, 57);
			
			ancho = getWidth()+ (new Canvas().getFontMetrics(fuente).stringWidth(cad)/2);
			x =  ancho;
			
			timer = new Timer(60, (L)-> 
			{
				x-=10;
				
				if(x<-ancho*2)
				{
					x = ancho;
				}
				
				repaint();
			});
		}
		
		public void start()
		{
			timer.start();
		}
		
		public void parar()
		{
			timer.stop();
			x = ancho;
		}
		
		@Override
		protected void paintComponent(Graphics g) 
		{
			super.paintComponent(g);
			
			 Graphics2D g2 = (Graphics2D) g.create();
			 g.dispose();
			 
		    int w = getWidth();
		    int h = getHeight();
		    g2.setComposite(AlphaComposite.getInstance(
		            AlphaComposite.SRC_OVER, .5f));
		    g2.setPaint(new GradientPaint(0, 0, Color.WHITE, 0, h, Color.BLUE));
		    g2.fillRect(0, 0, w, h);
		 
			g2.setFont(fuente);
			g2.setColor(Color.magenta);
			g2.drawString(c, x, getHeight()/2);
			g2.dispose();
		}
	}
}

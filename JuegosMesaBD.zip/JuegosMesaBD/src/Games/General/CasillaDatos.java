package Games.General;

public class CasillaDatos
{

}

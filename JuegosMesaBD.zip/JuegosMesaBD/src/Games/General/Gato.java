package Games.General;

import java.io.File;
import java.io.Serializable;

import javax.swing.JComponent;

import Games.Gato.Disegn.TableroGato;
import Games.Gato.Perfomance.GatoTableroData;
import Perfomance.Recursos;
import Perfomance.Serializa;

public class Gato extends Game<JComponent> implements Serializable{
	
	private static final long serialVersionUID = -383665833920128966L;
	private transient TableroGato tg;
	
	
	public void initGame() 
	{
		tg = new TableroGato(this);
		getContenedor().add(tg,"Center");
		stop();
	}
	
	@Override
	public void continueGame(int index, String part,String idPart, Object gameSer) 
	{
		super.continueGame(index, part,idPart,gameSer);
		
		tg = new TableroGato();
		getContenedor().add(tg,"Center");
		tg.deserializarJuego(this, (GatoTableroData) gameSer);
	}
	
	
	@Override
	public void play() 
	{
		super.play();
		super.fg.add(getContenedor());
		
		super.fg.repaint();
	}
	
	@Override
	public void stop() 
	{
		super.fg.remove(getContenedor());
		super.stop();
		super.fg.validate();
	}
	
	@Override
	public Object getSerGame() 
	{
		return tg.tableroDatos;
	}
	
	@Override
	public void reset() 
	{
		super.reset();
		tg.reset();
	}
	
	public static void main(String[] args) 
	{
		Serializa.saveObject(new Gato(), new File(Recursos.pathFilesGame+"Gato.game"));
	}
}

package Games.General;

import Perfomance.MetodoGet;

public interface Desabilitable {

	boolean habilitar();
}

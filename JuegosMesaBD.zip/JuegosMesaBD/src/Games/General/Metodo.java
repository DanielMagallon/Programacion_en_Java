package Games.General;

public interface Metodo
{
	void metodo();
}

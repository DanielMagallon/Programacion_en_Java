package Games.General;

import java.io.File;
import java.io.Serializable;

import javax.swing.JComponent;
import javax.swing.JOptionPane;

import Perfomance.Recursos;
import Perfomance.Serializa;

public class Ajedrez extends Game<JComponent> implements Serializable
{

	private static final long serialVersionUID = 3448872427286440779L;

	private transient Juego.Ajedrez aj;


	@Override
	public void play() 
	{
		super.play();
		super.fg.add(getContenedor());
		
		super.fg.repaint();
	}
	
	@Override
	public void stop() 
	{
		super.fg.remove(getContenedor());
		super.stop();
		super.fg.validate();
	}
	
	@Override
	public int suspend() 
	{
		if(JOptionPane.showConfirmDialog(getContenedor(), "No se pueden guardar el estado del ajedrez\n"
				+ "Esta seguro de cerrar la ventana? No se suspendera el juego","Version beta ajedrez",
				JOptionPane.YES_NO_OPTION) == JOptionPane.OK_OPTION)
		{
			fg.add(panelText);
			timer.finished();
			return 1;
		}
		
		return -1;
	}
	
	@Override
	public SerializableGame<?> getSerGame() {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public void reset() {
		// TODO Auto-generated method stub
		super.reset();
		aj.tablero.acomodadoPrincipal();
	}
	
	public static void main(String[] args) {
		Serializa.saveObject(new Ajedrez(), new File(Recursos.pathFilesGame+"Ajedrez.game"));
	}

	@Override
	public void initGame() {
		
		aj = new Juego.Ajedrez(this);
		getContenedor().add(aj.tablero,"Center");
		stop();
	}
}

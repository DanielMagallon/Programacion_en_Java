package Games.General;

import java.util.List;

import Perfomance.Script;

public enum Estado_Partida {
	
	VICTORY("2"),
	TIE("1"),
	SUSPENDED("4"),
	NEXT;
	
	private String estado;
	
	private Estado_Partida()
	{
		
	}
	
	private Estado_Partida(String c)
	{
		estado = c;
	}
	public void makeQuery(List<Object[]> datos, String id_part,String userVictory)
	{
		if(userVictory==null)
		{
			for(Object[] registro : datos)
			{
				query(String.format("insert into partidas_has_jugadores values (%s,%s,%s);", 
					id_part,registro[1].toString(),estado));
			}
		}
		else
		{
			String dato;
			
			for(Object[] registro : datos)
			{
				dato = registro[2].equals(userVictory) ? estado : "3";
					
				query(String.format("insert into partidas_has_jugadores values (%s,%s,%s);", 
						id_part,registro[1].toString(),dato));
			}
		}
	}
	
	public void updateQuery(List<Object[]> datos, String id_part,String userVictory, String duration)
	{
		//Actualiza tiempo
		query(String.format("update partidas set Tiempo_partida='%s' where Id_partida=%s;", 
				duration,id_part));
	
		//Actualiza estado de la partida, si es null, hubo empat o bien suspension
		if(userVictory==null)
		{
			query(String.format("update partidas_has_jugadores set Esado_part=%s where Id_partida=%s", 
					estado,id_part));
		}
		else
		{
			query(String.format("update partidas_has_jugadores set Esado_part=3 where Id_partida=%s;", 
					id_part));
			
			for(Object[] reg : datos)
			{
				if(reg[2].toString().equalsIgnoreCase(userVictory))
				{
					query(String.format("update partidas_has_jugadores set Esado_part=%s where "
				+ "Id_partida=%s && Id_jugador=%s;", 
							estado,id_part,reg[1].toString()));
					break;
				}
			}
		}
	}
	
	private void query(String c)
	{
		Script.getInstance().insert(c,false);
	}
	
}

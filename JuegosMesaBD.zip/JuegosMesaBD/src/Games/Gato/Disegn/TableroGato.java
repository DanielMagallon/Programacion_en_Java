package Games.Gato.Disegn;

import javax.swing.JPanel;

import Games.Gato.Perfomance.GatoTableroData;
import Games.General.Estado_Partida;
import Games.General.Game;
import Games.General.SerializableGame;

import static Games.General.Variables.iFor;
import static Games.General.Variables.jFor;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class TableroGato extends JPanel implements SerializableGame<GatoTableroData>
{
	private static final long serialVersionUID = -2104245198853669073L;

	public CasillaGato casillas[][];
	
	private Clicked click;
	
	public GatoTableroData tableroDatos;
	
	public Game<?> general;

	public boolean habilitado=true;
	
	public TableroGato()
	{
		
	}
	
	public TableroGato(Game<?> juegoGeneral)
	{
		tableroDatos = new GatoTableroData("O", "X",this);
		this.general = juegoGeneral;
		
		init();
	}
	
	@Override
	public void deserializarJuego(Game<?> juegoGeneral,GatoTableroData t) 
	{
		tableroDatos = t;
		tableroDatos.setReference(this);
		this.general = juegoGeneral;
		
		init();
		
		for(iFor=0; iFor<3; iFor++)
		{
			for(jFor=0; jFor<3; jFor++)
			{
				casillas[iFor][jFor].setImage(tableroDatos.estadoTablero[iFor][jFor].jugador);
			}
		}
	}
	
	private void init()
	{
		casillas = new CasillaGato[3][3];
		click = new Clicked();
		
		setLayout(new GridLayout(3, 3,3,3));
		
		for(iFor=0; iFor<3; iFor++)
		{
			for(jFor=0; jFor<3; jFor++)
			{
				casillas[iFor][jFor] = new CasillaGato(iFor, jFor);
				casillas[iFor][jFor].addMouseListener(click);
				add(casillas[iFor][jFor]);
			}
		}			
		
		setPreferredSize(new Dimension(500, 500));
	}
	
	public void reset() 
	{
		tableroDatos.reset();
		habilitado = true;
		
		for(CasillaGato cg[] : casillas)
			for(CasillaGato c : cg)
				c.setImage(-1);
	}
	
	class Clicked extends MouseAdapter
	{
		int ind;
		CasillaGato casilla;
		
		@Override
		public void mouseClicked(MouseEvent arg0)
		{
			if(habilitado)
			{
				casilla = (CasillaGato) arg0.getComponent();
				
				if(tableroDatos.estaVacia(casilla.f, casilla.c))
				{
					casilla.setImage(tableroDatos.turno);
					
					Estado_Partida est = tableroDatos.actualizar(casilla.f, casilla.c); 
					
					if( est == Estado_Partida.NEXT)
					{
						general.nextPlayer();
					}
					else {
						if(est == Estado_Partida.TIE)
							general.onFinish(est, null);
						
						else {
	
							general.onFinish(est, general.getActualPlayer());
						}
						
						habilitado=false;
					}
					
				 }
			   }
			
		}
	}

}

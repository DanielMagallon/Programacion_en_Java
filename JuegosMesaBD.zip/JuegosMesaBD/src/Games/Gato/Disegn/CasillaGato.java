package Games.Gato.Disegn;

import Games.General.Casilla;
import Games.General.Variables;

import static Games.General.Variables.fichaGato;
import static Games.General.Variables.fichaGato2;
import static Games.General.Variables.jugador1;
import static Games.General.Variables.jugador2;

public class CasillaGato extends Casilla
{
	private static final long serialVersionUID = -6078570044916041403L;

	public final int f,c;
	
	public CasillaGato(int f, int c)
	{
		this.f = f;
		this.c = c;
		setHorizontalAlignment(CENTER);
		setOpaque(true);
		setBorder(Variables.bordeNegro);
	}
	
	public void setImage(int jugador)
	{
		setIcon(jugador == jugador1 ? fichaGato : jugador == jugador2 ? fichaGato2 : null);
	}
}

package Games.Gato.Perfomance;

import Games.General.Estado_Partida;
import Games.General.TableroDatos;

import static Games.General.Variables.iFor;
import static Games.General.Variables.jFor;
import static Games.General.Variables.jugador1;

import java.io.Serializable;

import javax.swing.JOptionPane;

import Games.Gato.Disegn.TableroGato;

public class GatoTableroData extends TableroDatos implements Serializable
{
	private static final long serialVersionUID = -3925916424089880954L;

	public GatoCasillaData estadoTablero[][];
	
	public String labelJ1,labelJ2;
	
	public int turno,casillasOcupadas;
	
	private transient static final int valores[][] = {
			
			{0,1,0,2,1,0,2,0,1,1,2,2},
			{0,0,0,2,1,1,2,1},
			{0,0,0,1,1,2,2,2,1,1,2,0},
			
			{0,0,2,0,1,1,1,2},
			{1,0,1,2,0,1,2,1,0,0,2,2,0,2,2,0},
			{0,2,2,2,1,0,1,1},
			
			{0,0,1,0,2,1,2,2,1,1,0,2},
			{2,0,2,2,0,1,1,1},
			{2,0,2,1,0,2,1,2,0,0,1,1},
			
	};
	
	private transient TableroGato referencia;
	
	public GatoTableroData(String lbl1,String lbl2, TableroGato parent)
	{
		referencia = parent;
		labelJ1 = lbl1;
		labelJ2 = lbl2;
		turno = jugador1;
		
		estadoTablero = new GatoCasillaData[3][3];
		
		int ind=0;
		for(iFor=0; iFor<3; iFor++)
		{
			for(jFor=0; jFor<3; jFor++)
			{
				estadoTablero[iFor][jFor] = new GatoCasillaData(iFor, jFor,this,ind);
				ind++;
			}
		}
	}
	
	public void setReference(TableroGato parent)
	{
		referencia = parent;
	}
	
	public void reset()
	{
		turno = jugador1;
		casillasOcupadas = 0;
		
		for(GatoCasillaData cs [] : estadoTablero)
			for(GatoCasillaData c : cs)
					c.reset();
	}

	public Estado_Partida actualizar(int f, int c)
	{
		estadoTablero[f][c].actualizar(turno);
		casillasOcupadas++;
		return determinarJuego(f,c);
	}
	
	public void mostrarEstado()
	{
		for(GatoCasillaData cs []: estadoTablero)
		{
			for(GatoCasillaData c : cs)
			{
				System.out.print("| "+c+" |");
			}
				
			System.out.println("\n------------------");
			
		}
		
		System.out.println("\n");
	}
	
	public boolean estaVacia(int f, int c)
	{
		return estadoTablero[f][c].estaVacia();
	}
	
	public Estado_Partida determinarJuego(int f, int c)
	{
		int ind = estadoTablero[f][c].alpha;
		for(iFor=0; iFor<valores[ind].length-1; iFor+=4)
		{
			if(estadoTablero[valores[ind][iFor]][valores[ind][iFor+1]].jugador == turno)
			{
				if(estadoTablero[valores[ind][iFor+2]][valores[ind][iFor+3]].jugador == turno)
				{
					JOptionPane.showMessageDialog(referencia, 
							"Gano el jugador: "+referencia.general.getActualPlayer());
					return Estado_Partida.VICTORY; 
				}
			}
		}
		
		if(casillasOcupadas==9)
		{
			JOptionPane.showMessageDialog(null, "Empate");
			return Estado_Partida.TIE;
		}
		
		turno = -turno;
		return Estado_Partida.NEXT;
	}
	

}

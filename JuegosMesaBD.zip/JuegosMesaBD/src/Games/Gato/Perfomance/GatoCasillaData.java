package Games.Gato.Perfomance;

import java.io.Serializable;

import Games.General.CasillaDatos;
import Games.General.Variables;

public class GatoCasillaData extends CasillaDatos implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -3173067076869561025L;
	
	public final int fila,columna,alpha;
	public int jugador;
	public String label;
	public GatoTableroData ref;
	
	public GatoCasillaData(int f, int c,GatoTableroData r,int alpha)
	{
		fila = f;
		ref = r;
		columna = c;
		this.alpha = alpha;
		reset();
	}
	
	public void actualizar(int val)
	{
		jugador = val;
		
		label = (val==Variables.jugador1) ? ref.labelJ1 : ref.labelJ2;
		
	}
	
	public void reset()
	{
		jugador = -1;
		label = "--";
	}
	
	public boolean estaVacia()
	{
		return jugador==-1;
	}
	
	@Override
	public String toString()
	{
		return label;
	}
}

package Interfaz;

import static Perfomance.Recursos.pathIconsGame;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Vector;

import javax.imageio.ImageIO;
import javax.swing.BoxLayout;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import Perfomance.FileWorker;
import Perfomance.MetodoGet;
import Perfomance.Recursos;
import Perfomance.Script;

public class WindTable extends JDialog
{
	private static final long serialVersionUID = 5161600069233839126L;
	public TableData tablaDatos;
	public WindowRegistros wr;
	private WindowDelete wd;
	private File output;
	
	private JButton btnAdd,btnDelete,btnDeleteAll;
	
	private JPanel panelIconGame;
	private LabelUpdateImage lblIconGame;
	private JTextField txtNameIcon;

	private boolean createImg;
	private String tableSQL,query, tablasRelacionadas[];
	
	public WindTable() 
	{
		setSize(600,600);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		
		setModal(true);
		
		wr = new WindowRegistros();
		wd = new WindowDelete();
		tablaDatos = new TableData();
		
		panelIconGame = new JPanel();
		
		lblIconGame = new LabelUpdateImage(txtNameIcon = new JTextField(15),"Icono");
		
		panelIconGame.add(lblIconGame,"West");
		panelIconGame.add(txtNameIcon);
		
		btnAdd = new JButton("Agregar registro");
		btnAdd.addActionListener((a)->
		{
		
			createImg = false;
			
			if(Script.getInstance().bdActual.equalsIgnoreCase("juegosdemesa"))
			{
				if(tableSQL.equalsIgnoreCase("partidas_has_jugadores"))
				{
					wr.mostrar(1);
				}
				
				else if(tableSQL.equalsIgnoreCase("juegosmesa"))
				{
					lblIconGame.reset();
					wr.mostrar(2);
				}
				
				else if(tableSQL.equalsIgnoreCase("jugadores"))
				{
					wr.mostrar(3);
				}
				
				
				else wr.mostrar();
			}
			else
			{
				wr.mostrar();
			}
				
		});
		
		btnDelete = new JButton("Eliminacion");
		btnDelete.addActionListener((a)->{
			
			wd.mostrar();
		});
		
		btnDeleteAll = new JButton("Elimina todos los registros");
		btnDeleteAll.addActionListener((a)->
		{
			
			if(Script.getInstance().delete("delete from "+tableSQL+";"))
			{
				Script.getInstance().internalQuerys("alter table "+tableSQL+" auto_increment=1;");
				tablaDatos.refresh(tableSQL);
				
				if(tableSQL.equalsIgnoreCase("juegosmesa"))
				{
					FileWorker.deleteFiles(pathIconsGame);
				}
			}
		});
		
		JPanel pBtns =  new JPanel();
		
		pBtns.add(btnAdd);
		pBtns.add(btnDelete);
		pBtns.add(btnDeleteAll);
		
		add(pBtns,"South");
		add(tablaDatos.sc,"Center");
		
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
	}
	
	public void setSQLTable(String name)
	{
		tableSQL = name;
		
		tablasRelacionadas = null;
		
		if(tableSQL.equalsIgnoreCase("partidas_has_jugadores"))
		{
			tablasRelacionadas = new String[]{"jugadores","partidas"};
		}
		
		else if(tableSQL.equalsIgnoreCase("jugadores"))
		{
			tablasRelacionadas = new String[] {"avatars"};
		}
		
		else if(tableSQL.equalsIgnoreCase("partidas"))
		{
			tablasRelacionadas = new String[] {"juegosmesa"};
		}
		
	}

	public boolean validarFKeys()
	{
		if(tablasRelacionadas==null)
			return true;
		
		String pkey;
		Vector<String[]> vec;
		
		for(String tabla : tablasRelacionadas)
		{
			pkey = Script.getInstance().getIdPrimaryColumn(tabla);
			vec = Script.getInstance().consultaGet(String.format("select %s from %s ", pkey,tabla));
			
			if(vec.isEmpty())
			{
				JOptionPane.showMessageDialog(this, "No se podra hacer modificiones a la tabla\n"
						+ "Debe llenar primero las otras tablas referenciadas", 
						"Registro externos vacios", JOptionPane.WARNING_MESSAGE);
				return false;
			}
		}
		
		return true;
	}
	
	private void crearImagen()
	{
		try 
		{
			if(ImageIO.write(lblIconGame.getBufferImage(), lblIconGame.getFormat().replace
					(".", ""), output))
			{
				JOptionPane.showMessageDialog(this, "Se ha agregado un nuevo juego", 
						"Base de datos actualizada", JOptionPane.INFORMATION_MESSAGE);
			}

			else
			{
				Script.getInstance().delete("delete from juegosmesa where Icono_juego"
						+ "='"+txtNameIcon.getText()+lblIconGame.getFormat()+"';");
			}
		} catch (IOException e) {
			JOptionPane.showMessageDialog(this, "Ocurrio un error al guardar la imagen", 
					"No se pudo guardar la imagen", JOptionPane.ERROR_MESSAGE);
		}
	}
	
	@SuppressWarnings("serial")
	class WindowRegistros extends JDialog
	{
		JLabel lbls[];
		JTextField txts[];
		JComboBox<String> cboxEnum;
		JCheckBox check;
		JPanel panelDatos;
		StringBuilder selection,newValues;
		JButton ok;
		
		private ArrayList<JTextField> referencias;
		
		private MetodoGet<Boolean> met;
		
		public WindowRegistros() 
		{
			setModal(true);
			cboxEnum = new JComboBox<String>(new String[] {"Empate","Victoria","Derrota","Suspendida"});
			check = new JCheckBox("Juego de mas de 2 jugadores");
			setDefaultCloseOperation(DISPOSE_ON_CLOSE);
			setLayout(new BorderLayout());
			
			selection = new StringBuilder();
			newValues = new StringBuilder();
			
			referencias = new ArrayList<>();
			
			ok = new JButton("Aplicar");
			ok.addActionListener((a)->
			{
				
				if(met.metodo())
				{
					if(Script.getInstance().insert(query,true))
					{
						if(createImg)
							crearImagen();
						
						dispose();
						tablaDatos.refresh(tableSQL);
					}
				}
				
			});
			
			panelDatos = new JPanel();
			panelDatos.setLayout(new BoxLayout(panelDatos, BoxLayout.Y_AXIS));
			JScrollPane sc = new JScrollPane(panelDatos);
			add(sc,"Center");
			
			JPanel ps = new JPanel();
			
			ps.add(ok);
			add(ps,"South");
		}
		
		public void mostrar()
		{
			
			panelDatos.removeAll();
			referencias.clear();
			selection.setLength(0);
			
			lbls = new JLabel[Script.getInstance().columnsName.length];
			txts = new JTextField[lbls.length];
			
			panelDatos.setLayout(new GridLayout(lbls.length, 2,5,10));
			
			
			for(int i=0; i<lbls.length; i++)
			{
				lbls[i] = new JLabel(Script.getInstance().columnsName[i],JLabel.CENTER);
				txts[i] = new JTextField(15);
				
				if(Script.getInstance().isAutoIncrement(i))
				{
					txts[i].setText("(Es auto_increment la llave)");
					txts[i].setEditable(false);
				}
				else
				{
					selection.append(Script.getInstance().columnsName[i]+",");
					referencias.add(txts[i]);
				}
				
				panelDatos.add(lbls[i]);
				panelDatos.add(txts[i]);
			}
			
			selection.deleteCharAt(selection.length()-1);

			met = ()->
			{
				
				newValues.setLength(0);
				
				for(JTextField r : referencias)
				{
					if(r.getText().trim().isEmpty())
					{
						JOptionPane.showMessageDialog(this, "Debe rellenar todos los campos", 
								"Statement fallido", JOptionPane.ERROR_MESSAGE);
						return false;
					}
					newValues.append("'"+r.getText().trim()+"',");
				}
				
				newValues.deleteCharAt(newValues.length()-1);
				
				query = "insert into "+tableSQL+" ("+selection+") values ("+newValues+");";
			
				return true;
			};
			
			source();
			
		}
		
		public void mostrar(int tabla)
		{
			panelDatos.removeAll();
			
			lbls = new JLabel[3];
			
			panelDatos.setLayout(new GridLayout(Script.getInstance().columnsName.length, 2,5,10));
			
			lbls[0] = new JLabel(Script.getInstance().columnsName[0],JLabel.CENTER);
			lbls[1] = new JLabel(Script.getInstance().columnsName[1],JLabel.CENTER);
			lbls[2] = new JLabel(Script.getInstance().columnsName[2],JLabel.CENTER);
			
			JTextField txt1 = new JTextField(15);
			JTextField txt2 = new JTextField(15);
			
			panelDatos.add(lbls[0]);
			panelDatos.add(txt1);
			
			panelDatos.add(lbls[1]);
			panelDatos.add(txt2);
			
			panelDatos.add(lbls[2]);
			
			if(tabla==1)
			{
				panelDatos.add(cboxEnum);
				met = ()->
				{
					if(txt1.getText().trim().isEmpty() || txt2.getText().isEmpty())
					{
						JOptionPane.showMessageDialog(this, "Debe rellenar todos los campos", 
								"Statement fallido", JOptionPane.ERROR_MESSAGE);
						return false;
					}
					
					newValues.setLength(0);
					newValues.append("'"+txt1.getText()+"',");
					newValues.append("'"+txt2.getText()+"',");
					newValues.append("'"+(cboxEnum.getSelectedIndex()+1)+"'");
					
					query = "insert into partidas_has_jugadores values("+newValues+");";
					
					return true;
				};
			}
			else if(tabla==2)
			{
				txt1.setText("(Es auto_increment la llave)");
				txt1.setEditable(false);
				
				panelDatos.add(check);
				panelDatos.add(new JLabel("Icono de juego",JLabel.CENTER));
				panelDatos.add(panelIconGame);
				
				met = ()->
				{
					if(txt2.getText().trim().isEmpty())
					{
						JOptionPane.showMessageDialog(this, "Debe rellenar todos los campos", 
								"Statement fallido", JOptionPane.ERROR_MESSAGE);
						return false;
					}
					
					if(Script.getInstance().exists(txt2.getText(), "juegosmesa", "Nombre_juego"))
					{
						JOptionPane.showMessageDialog(this, "Ya existe un juego con el mismo nombre", 
								"Nombre juego existente", JOptionPane.ERROR_MESSAGE);
						return false;
					}
					
					if(!lblIconGame.hayImagen())
					{
						JOptionPane.showMessageDialog(this, "Debe escoger un icono para el juego", 
								"Statement fallido", JOptionPane.ERROR_MESSAGE);
						return false;
					}
					
					if(txtNameIcon.getText().trim().isEmpty())
					{
						JOptionPane.showMessageDialog(this, "Debe especificar un nombre a la imagen", 
								"Nombre de imagen vacio", JOptionPane.ERROR_MESSAGE);
						return false;
					}
					
					if(lblIconGame.createBufferImage())
					{
						 output = new File
						(pathIconsGame+txtNameIcon.getText()+lblIconGame.getFormat());
						
						if(output.exists())
						{
							JOptionPane.showMessageDialog(this, "Ya existe una imagen con el mismo nombre", 
									"Cambie el nombre de la imagen", JOptionPane.ERROR_MESSAGE);
							return false;
						}
						
						char c = check.isSelected() ? '1' : '0';
						query = String.format("insert into juegosmesa (Nombre_juego,Mayor2Jugadores,Icono_juego)"
								+ " values ('%s','%c','%s');",txt2.getText(),c,
								txtNameIcon.getText()+lblIconGame.getFormat());
						
						createImg = true;
						
						return true;
					}
					
					return false;
				};
			}
			
			else 
			{
				txt1.setText("(Es auto_increment la llave)");
				txt1.setEditable(false);
			
				
				JTextField txtUser = new JTextField(15);
				
				txt2.addKeyListener(new KeyAdapter() {
					
					
					@Override
					public void keyReleased(KeyEvent e) 
					{
						txtUser.setText(txt2.getText());
					}
				});
				
				JPasswordField txtPass = new JPasswordField(15);
				txtPass.setEchoChar('*');
				
				panelDatos.add(txtUser);
				JCheckBox passReq = new JCheckBox("Password");
				passReq.setSelected(true);
				passReq.addChangeListener((a)->{
					
					if(passReq.isSelected())
					{
						passReq.setText("Password");
						txtPass.setEditable(true);
					}
					else
					{
						passReq.setText("Sin password");
						txtPass.setEditable(false);
					}
					
					
				});
				passReq.setHorizontalAlignment(JCheckBox.CENTER);
				panelDatos.add(passReq);
				panelDatos.add(txtPass);
				
				panelDatos.add(new JLabel(Script.getInstance().columnsName[4],JLabel.CENTER));
				
				JComboBox<ImageIcon> imagesAvatar = new JComboBox<>();
				panelDatos.add(imagesAvatar);
				
				
				
				Recursos.updateAvatars();
				
				for(String name[] : Recursos.imgAvatar)
				{
					imagesAvatar.addItem(Recursos.getImage("/Recursos/Avatar/Mini/", 
							name[1]));
				}
				
				met = ()->
				{
					if(txt2.getText().trim().isEmpty() || 
							txtUser.getText().trim().isEmpty() || txtPass.getPassword()==null)
					{
						JOptionPane.showMessageDialog(this, "Debe rellenar todos los campos", 
								"Statement fallido", JOptionPane.ERROR_MESSAGE);
						return false;
					}
					
					if(Script.getInstance().exists(txtUser.getText().trim(), 2))
					{
						JOptionPane.showMessageDialog(this, "El usuario con el nombre \""+
					txtUser.getText().trim()+"\" ya se encuentra registrado\nIntente con otro nombre de usuario", 
								"Usuario existente", JOptionPane.ERROR_MESSAGE);
						return false;
					}
					
					String pass = passReq.isSelected() ? new String(txtPass.getPassword()) : "";
					
					query = "insert into jugadores (Nombre_jugador,Nombre_usuario,Pasw_jugador,"
				+ "Id_avatar) values('"+txt2.getText()+"','"+txtUser.getText()+"','"+
							pass+"','"+Recursos.imgAvatar
							[imagesAvatar.getSelectedIndex()][0]+"');";
					
					return true;
				};
			}
			
			source();
		}
		
		private void source()
		{
			panelDatos.validate();
			
			pack();
			setLocationRelativeTo(null);
			setVisible(true);
		}
	}
	
	@SuppressWarnings("serial")
	class WindowDelete extends JDialog implements ActionListener
	{
		JList<String> campos,operadoresLogicos,operadoresRelacionales;
		DefaultListModel<String> modelo;
		JButton ok,okCampo,okOpL,okOpR,nuevoGrupo,fueraGrupo,addDato,btnDelete,btnNot;
		StringBuilder selection;
		JTextField dato;
		JTextArea txtA = new JTextArea(5,10);
		
		private int parentsis;
		private Component gruposC[][];
		
		public WindowDelete() 
		{
			setModal(true);
			setLayout(new BorderLayout());
			
			operadoresLogicos = new JList<String>(new String[]{"and","or"});
			operadoresRelacionales = new JList<>(new String[] {">","<",">=","<=","=","!=","<>"});
			
			campos = new JList<>();
			modelo = new DefaultListModel<String>();
			
			addDato = new JButton("Agregar Dato");
			addDato.addActionListener(this);
			dato = new JTextField(15); 
			
			selection=new StringBuilder();
			
			txtA.setLineWrap(true);
			txtA.setWrapStyleWord(true);
			txtA.setEditable(false);
			
			campos.setModel(modelo);
			
			JPanel panelDatos = new JPanel();
			panelDatos.setLayout(new GridLayout(2, 4,5,5));
			JScrollPane sc = new JScrollPane(campos);
			panelDatos.add(sc);

			JScrollPane sc2 = new JScrollPane(operadoresRelacionales);
			JScrollPane sc3 = new JScrollPane(operadoresLogicos);
			
			panelDatos.add(sc2);
			panelDatos.add(sc3);
			
			
			JPanel pg = new JPanel();
			pg.setLayout(new GridLayout(6, 1,0,10));
			
			pg.add(dato);
			pg.add(addDato);
			
			pg.add(btnNot = new JButton("Not"));
			btnNot.addActionListener(this);
			
			pg.add(nuevoGrupo = new JButton("("));
			nuevoGrupo.addActionListener(this);
			
			pg.add(fueraGrupo = new JButton(")"));
			fueraGrupo.addActionListener(this);
			
			pg.add(btnDelete = new JButton("Hacer eliminacion"));
			btnDelete.addActionListener(this);
			
			panelDatos.add(pg);
			
			
			
			okCampo = new JButton("Copy");
			okCampo.addActionListener(this);
			
			
			JPanel p = new JPanel();
			p.setLayout(new GridLayout(2,1,0,10));
			p.add(okCampo,"North");
			panelDatos.add(p);
			
			okOpR = new JButton("Copy");
			okOpR.addActionListener(this);
			
			
			
			JPanel p2 = new JPanel();
			p2.setLayout(new GridLayout(2,1,0,10));
			p2.add(okOpR);
			panelDatos.add(p2);
			
			okOpL = new JButton("Copy");
			okOpL.addActionListener(this);
			
			
			JPanel p3 = new JPanel();
			p3.setLayout(new GridLayout(2,1,0,10));
			p3.add(okOpL);
			panelDatos.add(p3);
			
			add(panelDatos,"Center");
			
			JPanel panelSta = new JPanel();
			panelSta.setLayout(new BorderLayout());
			JScrollPane sct = new JScrollPane(txtA);
			panelSta.add(sct);
			
			add(panelSta,"South");
			
			gruposC = new Component[][]
				{
						{nuevoGrupo},
						{campos,okCampo},
						{operadoresRelacionales,okOpR},
						{dato,addDato},
						{operadoresLogicos,okOpL},
						{fueraGrupo},
						{btnDelete}
						
						
				};
			
		}
		
	
		@Override
		public void actionPerformed(ActionEvent e) 
		{
			if(e.getSource() == nuevoGrupo)
			{
				selection.append("( ");
				habilitarGrupo(-1, 1);
				parentsis++;
			}
			
			else if(e.getSource() == fueraGrupo)
			{
				selection.append(" ) ");
				parentsis--;
				
				if(parentsis==0)
					habilitarGrupo(-1, 4,6);
				
				else
					habilitarGrupo(5, 4);
				
			}
			
			else if(e.getSource() == okCampo)
			{
				selection.append(campos.getSelectedValue()+" ");
				habilitarGrupo(-1, 2);
				
			}
			
			else if(e.getSource() == okOpL)
			{
				selection.append(operadoresLogicos.getSelectedValue()+" ");
				habilitarGrupo(-1, 0,1);
			}
			
			else if(e.getSource() == okOpR)
			{
				selection.append(operadoresRelacionales.getSelectedValue()+" ");
				habilitarGrupo(-1, 3);
			}
			
			else if(e.getSource() == addDato)
			{
				selection.append(" '"+dato.getText()+"' ");
				habilitarGrupo(-1, 4, parentsis != 0 ? 5 : 6);
			}
			
			else if(e.getSource() == btnDelete)
			{
				query = txtA.getText()+";";
				if(Script.getInstance().delete(query))
				{
					txtA.setText("");
					this.dispose();
					tablaDatos.refresh(tableSQL);
				}				
			}
			
			else if(e.getSource() == btnNot)
			{
				selection.append("not ");
			}
			
			txtA.setText("delete from "+tableSQL+" where "+selection.toString());
		}
		
		public void mostrar()
		{
			modelo.clear();
			habilitarGrupo(-1, 0,1);
			selection.setLength(0);
			parentsis=0;
			for(String name : Script.getInstance().columnsName)
			{
				modelo.addElement(name);
			}
			
			pack();
			setLocationRelativeTo(null);
			setVisible(true);
			
		}
		
		private void habilitarGrupo(int grupoMismo, int...grupos)
		{
			int ind=0;
			boolean hab;
			for(int i=0; i<gruposC.length; i++)
			{
				if(i==grupoMismo)
					continue;
				
				if(ind!=grupos.length)
				{
					hab = i==grupos[ind];
					
					if(hab)
						ind++;

				}
				else hab = false;
				
				for(int j=0; j<gruposC[i].length; j++)
					gruposC[i][j].setEnabled(hab);
				
			}
			
			
			
		}
		
	}
}


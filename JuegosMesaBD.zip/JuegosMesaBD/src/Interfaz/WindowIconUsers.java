package Interfaz;

import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import static Perfomance.Recursos.users;
import static Perfomance.Recursos.updateUsers;
import static Perfomance.Recursos.getImage;

import java.awt.Color;
import java.awt.GridLayout;


@SuppressWarnings("serial")
public class WindowIconUsers extends JDialog
{
	private JPanel profiles;
	private int f,c=5;
	private static WindowIconUsers ref;
	
	
	public WindowIconUsers() 
	{
		setModal(true);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		
		profiles = new JPanel();
		add(new JScrollPane(profiles),"Center");
		profiles.setBackground(Color.white);
		ref = this;
	}

	
	public void mostrar()
	{
		profiles.removeAll();
		UserIcon.indexColor=0;
		updateUsers();
		f = users.length/c+1;
		profiles.setLayout(new GridLayout(f, c,5,5));
		
		for(String registro[] : users)
		{
			profiles.add(new UserIcon(registro[0], registro[1], 
					getImage("/Recursos/Avatar/", registro[2]).getImage()));
		}

		pack();
		setLocationRelativeTo(null);
		setVisible(true);
	}
	
	public static void destroy()
	{
		ref.dispose();
	}
	
	public static void habilitar()
	{
		ref.setVisible(true);
	}
}


package Interfaz;

import static Perfomance.Recursos.addAvatar;
import static Perfomance.Recursos.getImage;
import static Perfomance.Recursos.imgAvatar;
import static Perfomance.Recursos.pathAvatars;
import static Perfomance.Recursos.pathMiniAvatars;
import static Perfomance.Recursos.updateAvatars;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import Perfomance.Script;

public class WindowAvatars extends JDialog implements ActionListener, Runnable
{
	private static final long serialVersionUID = -1336107559474119789L;

	private JPanel panelAvatar;
	
	private int f,c=5;
	
	private JLabel lblAddAvatar;
	
	private JTextField txtName;
	private JButton btnOk;
	
	private Click listener;
	
	private LabelUpdateImage labelAvatar,labelMiniAvatar;
	
	private WindowNewAvatar wna;
	
//	private Thread demon;
	
	public WindowAvatars() 
	{
		setLayout(new BorderLayout());
		panelAvatar = new JPanel(); 
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		
		add(panelAvatar,"Center");
		setModal(true);
		
		listener = new Click();
		
		
		wna = new WindowNewAvatar();
		
		lblAddAvatar = new JLabel(addAvatar,JLabel.CENTER);
		lblAddAvatar.setOpaque(true);
		lblAddAvatar.addMouseListener(listener);
		
//		demon = new Thread(this);
//		demon.start();
	}
	
	private boolean updatePicture;
	
	public void mostrar(boolean updatePicture)
	{
		panelAvatar.removeAll();
		this.updatePicture = updatePicture;
		labelMiniAvatar.reset();
		labelAvatar.reset();
		
		updateAvatars();
		f = imgAvatar.length/c+1;
		panelAvatar.setLayout(new GridLayout(f,c,5,5));

		LabelAvatar lbl;
		for(String img[] : imgAvatar)
		{
			lbl = new LabelAvatar(getImage("/Recursos/Avatar/", img[1]),img[0]);
			lbl.addMouseListener(listener);
			panelAvatar.add(lbl);
		}
		
		if(!updatePicture)
		panelAvatar.add(lblAddAvatar);
		
		panelAvatar.validate();
		pack();
		setLocationRelativeTo(null);
		setVisible(true);
		
	}
	
	private String user;
	public Image picureUser;
	public WindowAvatars setUser(String user)
	{
		picureUser = null;
		this.user = user;
		return this;
	}
	
	@Override
	public void actionPerformed(ActionEvent e)
	{
		if(!labelAvatar.hayImagen() || !labelMiniAvatar.hayImagen())
		{
			JOptionPane.showMessageDialog(this, "Debe ingresar las imagenes requeridas", 
					"Campo imagen vacio(s)", JOptionPane.ERROR_MESSAGE);
			return;
		}
		if(txtName.getText().trim().isEmpty())
		{
			JOptionPane.showMessageDialog(this, "Debe ingresar un nombre al avatar", 
					"Campo nombre imagen vacio", JOptionPane.ERROR_MESSAGE);
			return;
		}
		
		try 
		{
			
			if(labelAvatar.createBufferImage() && labelMiniAvatar.createBufferImage())
			{
				if(!labelAvatar.getFormat().equalsIgnoreCase(labelMiniAvatar.getFormat()))
				{
					JOptionPane.showMessageDialog(this, "Ambas imagen deben tener el mismo formato", 
							"Error en formato de imagen", JOptionPane.ERROR_MESSAGE);
					return;
				}
			
				File output = new File(pathAvatars+txtName.getText()+labelAvatar.getFormat());
				File outputM = new File(pathMiniAvatars+txtName.getText()+labelMiniAvatar.getFormat());
				
				if(!output.exists())
				{
					if(Script.getInstance().insert(String.format ("insert into avatars (Imagen_avatar) "
							+ "values ('%s')", txtName.getText()+labelAvatar.getFormat()),true))
					if(ImageIO.write(labelAvatar.getBufferImage(),labelAvatar.getFormat().replace(".", ""), 
					output) && ImageIO.write(labelMiniAvatar.getBufferImage(), labelMiniAvatar.getFormat().replace
							(".", ""), outputM))
					{
								JOptionPane.showMessageDialog(this, "Se ha guardado la imagen", 
										"Base de datos actualizada", JOptionPane.INFORMATION_MESSAGE);
								wna.dispose();
								mostrar(false);
					}
					else
					{
						Script.getInstance().delete(String.format("delete from avatars where "
							+ "Imagen_avatar = '%s';", txtName.getText()+labelAvatar.getFormat()));
						
						JOptionPane.showMessageDialog(this, "No se ha podido agregar la imagen", 
								"Error", JOptionPane.INFORMATION_MESSAGE);
					}
				}
				else
				{
					JOptionPane.showMessageDialog(this, "Ya existe una imagen con el mismo nombre", 
							"Cambie el nombre de la imagen", JOptionPane.ERROR_MESSAGE);
				}
			}
		} 
		catch (IOException e1) 
		{
			JOptionPane.showMessageDialog(this, "Ocurrio un error al guardar la imagen", 
					"No se pudo guardar la imagen", JOptionPane.ERROR_MESSAGE);
			
		}
		
	}
	
	@Override
	public void run() 
	{
//		while(true)
//		{
//			try {
//				Thread.sleep(10000);
//				mostrar();
//			} catch (InterruptedException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//		}
			
	}
	
	class Click extends MouseAdapter
	{
		@Override
		public void mousePressed(MouseEvent e) 
		{
			JLabel lbl = (JLabel) e.getComponent();
			
				lbl.setBackground(Color.GREEN);
			
			if(updatePicture)
			{
				
			}
		}
		
		@Override
		public void mouseReleased(MouseEvent e) 
		{
			JLabel lbl = (JLabel) e.getComponent();
			lbl.setBackground(null);
			
			if(lbl == lblAddAvatar)
			{
				WindowAvatars.this.dispose();
				wna.setVisible(true);
			}
			
			else
			{
				if(updatePicture)
				{
					String id = ((LabelAvatar) lbl).id_avatar;
					
					if(Script.getInstance().update(String.format
					("update jugadores set Id_avatar=%s where Nombre_usuario='%s'", id,user)))
					{
						picureUser = ((ImageIcon) lbl.getIcon()).getImage();					
					} else picureUser = null;
					
					WindowAvatars.this.dispose();
				}
				else
				{
					
				}
			}
		}
	}
	
	@SuppressWarnings("serial")
	class WindowNewAvatar extends JDialog 
	{
		
		public WindowNewAvatar() 
		{
			setModal(true);
			setLayout(new BorderLayout());
			
			JPanel panelAv = new JPanel();
			
			panelAv.setLayout(new GridLayout(2, 1));

			txtName = new JTextField(15);
			
			JPanel panelNA = new JPanel();
			{
				labelAvatar = new LabelUpdateImage(txtName,"Avatar");
				panelNA.add(labelAvatar);
				
				panelAv.add(panelNA);
			}
			
			JPanel panelAM = new JPanel();
			{
				panelAv.add(panelAM);
				labelMiniAvatar = new LabelUpdateImage(null,"Avatar miniatura");
				panelAM.add(labelMiniAvatar);
			}
		
			JPanel panelOk = new JPanel();
			{
				panelOk = new JPanel();
				
				JLabel lblName = new JLabel("Nombre del avatar: ",JLabel.CENTER);
				
				panelOk.setLayout(new FlowLayout(FlowLayout.CENTER));
				
				panelOk.add(lblName);
				
				panelOk.add(txtName);
				
				btnOk = new JButton("Aplicar");
				btnOk.addActionListener(WindowAvatars.this);
				panelOk.add(btnOk);
				
				JButton btnCancel = new JButton("Cancelar");
				
				btnCancel.addActionListener((a)-> {
					this.dispose();
					WindowAvatars.this.setVisible(true);
				});
				
				panelOk.add(btnCancel);
				
			}
			
			add(panelAv);
			add(panelOk,"South");
			setSize(500, 300);
			setLocationRelativeTo(null);
		}
	}
}

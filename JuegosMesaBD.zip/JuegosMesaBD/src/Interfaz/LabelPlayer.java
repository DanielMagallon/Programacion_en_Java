package Interfaz;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.JToggleButton;

import Perfomance.Script;
import Perfomance.TreeQuery;

public class LabelPlayer extends JPanel implements ActionListener
{
	private static final long serialVersionUID = 1328826941815919709L;
	
	private Image avatar;
	private String name,user,pass,id,clave;
	private static Font font;
	
	private JTextField txtPass;
	private JToggleButton toggParticipar;
	private JButton btnRenaudar;
	private TableButton table;
	
	private int index;
	
	public static WindowRenaudar wr;
	
	static
	{
		wr = new WindowRenaudar();
	}
	
	public static int num_part;
	public static int altura;
	
	public LabelPlayer(ImageIcon playerAvatar, String id,String nombre, String usuario, String pass, int ind) 
	{
		index = ind;
		setLayout(new BorderLayout());
		setPreferredSize(new Dimension(350, 150));
		setBorder(BorderFactory.createLineBorder(Color.blue));
		setBackground(Color.white);
		
		table = new TableButton();
		toggParticipar = new JToggleButton("PARTICIPAR");
		toggParticipar.setBackground(Color.WHITE);
		
		btnRenaudar = new JButton("Reanudar partidas");
		btnRenaudar.setBackground(Color.white);
		
		font = new Font("Sans Serif", Font.ITALIC, 22);
		
		avatar = playerAvatar.getImage();
		this.id = id;
		this.pass = pass;
		name = nombre;
		user = usuario;

		JPanel panel = new JPanel();
		{
			panel.setBackground(Color.white);
			panel.setLayout(new BorderLayout());
			panel.add(toggParticipar,"Center");
			panel.add(btnRenaudar,"South");
			
			add(panel,"East");
		}
		
		JPanel pd = new JPanel();
		
		{
			pd.setBackground(Color.WHITE);
			pd.add(new JLabel("Password: "));
			
			if(pass.equals(""))
			{
				txtPass = new JTextField("No requerido",15);
				txtPass.setEditable(false);
				
			}else txtPass = new JPasswordField(15);
				
			pd.add(txtPass);
			
			add(pd,"South");
		}
		
		altura+=150;
		toggParticipar.addActionListener(this);
		btnRenaudar.addActionListener(this);
		
		busqueda();
	}
	
	private void busqueda()
	{
		Vector<String[]> v = Script.getInstance().consultaGet(TreeQuery.query
				("p.Id_partida,p.Nombre_partida,p.Tiempo_partida", TreeQuery.fromPartidas, 
				String.format("where j.Nombre_usuario = '%s' && phj.esado_part='suspendida' "
				+ "&& jg.Nombre_juego='%s';", user,WindowParticipantes.enJuego),
				TreeQuery.joinJuegosMesa,TreeQuery.joinPartJugadores,
				TreeQuery.joinJugadores));
		
		Vector<Object> vector;
		
		for(String[] r : v )
		{
			vector = new Vector<>();
			
			for(String s : r)
			{
				vector.addElement(s);
			}
			
			table.agregar(vector, ()->
			{
				wr.dispose();
				WindowParticipantes.wp.dispose();
				FrameGame.wjuegos.dispose();
				return  Script.getInstance().consultaGet(TreeQuery.query
						("Imagen_avatar,j.Id_jugador,Nombre_usuario", TreeQuery.fromPart_Jugadores, 
						String.format("where phj.Id_partida='%s';", r[0]),
						TreeQuery.joinJugadores,TreeQuery.joinPartida,
						TreeQuery.joinJuegosMesa,TreeQuery.joinAvatars));
			});
			
			
		}
		
		
		if(v.isEmpty())
		{
			btnRenaudar.setEnabled(false);
		}
	}
	
	
	@Override
	public void actionPerformed(ActionEvent e) 
	{
		if(e.getSource() == btnRenaudar)
		{
			wr.addTable(table);
			return;
		}
		
		if(!toggParticipar.isSelected())
		{
			WindowParticipantes.remover(index);
			num_part--;
		}
		
		else
		{
			num_part++;
			
			if(num_part<=WindowParticipantes.MAX_PLAYERS)
			{
				if(txtPass.isEditable())
				{
					clave = txtPass.getText();
					if(clave.trim().isEmpty())
					{
						JOptionPane.showMessageDialog(this, "Debe ingresar su contrase�a", 
							"Contrase�a requerida", JOptionPane.ERROR_MESSAGE);
						toggParticipar.setSelected(false);
						txtPass.requestFocus();
						num_part--;
					}
				
					else if(!clave.equals(pass))
					{
						JOptionPane.showMessageDialog(this, "Contrase�a incorrecta", 
								"Ingresa de nuevo la contrase�a", JOptionPane.ERROR_MESSAGE);
						txtPass.setText("");
						toggParticipar.setSelected(false);
						txtPass.requestFocus();
						num_part--;
					} else WindowParticipantes.agregaParticipante(new ImageIcon(avatar), user,id, index);
				} else WindowParticipantes.agregaParticipante(new ImageIcon(avatar), user, id,index);
				
			}
			else
			{
					JOptionPane.showMessageDialog(null, String.format
				("Solo pueden participar en este juego hasta %d jugadores", WindowParticipantes.MAX_PLAYERS), 
				"Numero de participantes excedidos", JOptionPane.ERROR_MESSAGE);
					toggParticipar.setSelected(false);
					num_part--;
			}
		}
		
		WindowParticipantes.verifica();
	}
	
	@Override
	protected void paintComponent(Graphics g) 
	{
		super.paintComponent(g);
		
		g.setColor(Color.blue);
		g.setFont(font);
		g.drawString("Nombre: "+name, 150, 60);
		g.drawString("Nombre usuario: "+user, 150, 100);
		g.drawImage(avatar, 30, 30, 90, 90, this);
	}
	
	public String getID()
	{
		return id;
	}
}

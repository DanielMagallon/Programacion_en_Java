package Interfaz;

import javax.swing.ImageIcon;
import javax.swing.JLabel;

@SuppressWarnings("serial")
public class LabelAvatar extends JLabel
{
	public String id_avatar;
	
	public LabelAvatar(ImageIcon ic, String id) 
	{
		super(ic);
		this.id_avatar = id;
	}
}

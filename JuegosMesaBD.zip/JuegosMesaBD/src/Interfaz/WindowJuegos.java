package Interfaz;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import Perfomance.Script;


@SuppressWarnings("serial")
public class WindowJuegos extends JDialog implements ActionListener
{
	private JPanel panel;
	private LabelGames labelJuegos;
	private PanelBusquedas panelSearch; 
	
	public WindowJuegos() 
	{
		setModal(true);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
	
		
		add(panel = new JPanel());
		panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
		
		labelJuegos = new LabelGames();
		panel.add(labelJuegos);
		
		JPanel panelA = new JPanel();
		{
			JButton btnCancel = new JButton("Cerrar");
			panelA.setBackground(Color.white);
			btnCancel.setBackground(Color.white);
			btnCancel.addActionListener((a)->dispose());
			panelA.add(btnCancel);
			add(panelA,"South");
		}
		
		panelSearch = new PanelBusquedas(this,"Buscar juego: ",30);
		add(panelSearch,"North");
	}
	
	@Override
	public void actionPerformed(ActionEvent e) 
	{
		
		if(panelSearch.isSearchCommand(e.getSource()))
		{
			String valorCampo = Script.getInstance().consultaUnique(String.format
					("select Id_juego from juegosmesa where Nombre_juego = '%s'", 
					panelSearch.getInfoTextField()));
			
			
			if(valorCampo != null && labelJuegos.find(valorCampo))
			{
				labelJuegos.get();
			}
			else
			{
				JOptionPane.showMessageDialog(this, "No se encontraron resultados", 
						"Juego no encontrado", JOptionPane.INFORMATION_MESSAGE);
			}
		}
		else
		{
			panelSearch.emptyTxt();
		}
	}
	
	public void mostrar()
	{
		Vector<String[]> vec = Script.getInstance().consultaGet("select * from juegosmesa;");
		labelJuegos.setJuegos(vec);
		labelJuegos.get();
		pack();
		setLocationRelativeTo(null);
		setVisible(true);
	}
}

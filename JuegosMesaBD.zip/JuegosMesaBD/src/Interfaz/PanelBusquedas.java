package Interfaz;

import static Perfomance.Recursos.cancelIcon;
import static Perfomance.Recursos.searchIcon;

import java.awt.Color;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

@SuppressWarnings("serial")
public class PanelBusquedas extends JPanel 
{
	private JTextField txtCampo;
	private JButton btnBuscar;
	private JButton btnCancel;
	
	public PanelBusquedas(ActionListener listener, String labelBuscar, int widthTxt) 
	{
		setBackground(Color.white);
		add(new JLabel(labelBuscar));
	
		btnBuscar = new JButton(searchIcon);
		btnBuscar.setBorderPainted(false);
		btnBuscar.setBackground(Color.WHITE);
		
		
		btnCancel = new JButton(cancelIcon);
		btnCancel.setBorderPainted(false);
		btnCancel.setBackground(Color.WHITE);
		
		btnBuscar.addActionListener(listener);
		btnBuscar.setName("search");

		
		btnCancel.addActionListener(listener);
		btnCancel.setName("cancel");
		
		txtCampo = new JTextField(widthTxt);
		txtCampo.addActionListener(listener);
		txtCampo.setName("search");
		
		add(txtCampo);
		add(btnCancel);
		add(btnBuscar);
	}

	public void emptyTxt()
	{
		txtCampo.setText("");
	}
	
	public String getInfoTextField()
	{
		return txtCampo.getText();
	}
	
	public boolean isSearchCommand(Object source)
	{
		return btnBuscar == source || txtCampo == source;
	}
	
	public boolean isCancelCommand(Object source)
	{
		return btnCancel == source;
	}
	
}

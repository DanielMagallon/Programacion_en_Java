package Interfaz;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;

import javax.swing.JPanel;
import javax.swing.JScrollPane;

import Perfomance.Painted;

@SuppressWarnings("serial")
public class PaintScroll extends JPanel 
{
	public int h,w;
	private JScrollPane sc;
	
	private Painted paint;
	
	public PaintScroll(Painted paint) 
	{
		this.paint = paint;
		setBackground(Color.decode("#FAF4CF"));
		
		setPreferredSize(new Dimension(h, w));
		
		sc = new JScrollPane(this);
	}

	public void preferedSize(int h, int w)
	{
		setPreferredSize(new Dimension(w, h));
		sc.setViewportView(this);
	}
	
	public JScrollPane getScroll()
	{
		return sc;
	}
	
	@Override
	protected void paintComponent(Graphics g) 
	{
		super.paintComponent(g);
		paint.paintGraphics(g);
	}
}

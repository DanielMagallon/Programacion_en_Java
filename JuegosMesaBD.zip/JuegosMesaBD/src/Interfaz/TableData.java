package Interfaz;

import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import Perfomance.Script;

public class TableData extends JTable {
	
	private static final long serialVersionUID = 7500900997368827052L;
	public JScrollPane sc;
	private DefaultTableModel modelo;
	
	
	@SuppressWarnings("serial")
	public TableData() 
	{
		sc  = new JScrollPane(this);
		modelo = new DefaultTableModel() {
			
			@Override
			public boolean isCellEditable(int row, int column) {
				
				return false;
			}
			
		};
				
		setModel(modelo);
		
		
	}
	
	public void refresh(String table)
	{
		consultaColumnas("select *from "+table+";");
	}
	
	public void resetAll()
	{
		modelo.setRowCount(0);
		modelo.setColumnCount(0);
	}
	
	public void consultaColumnas(String c)
	{
		resetAll();
		int i;
		
		Script.getInstance().consultadaMetaData(c);
		
		for(i=0; i<Script.getInstance().columnsName.length; i++)
		{
			modelo.addColumn(Script.getInstance().columnsName[i]);
		}
		
		for(String reg[] : Script.getInstance().datosTable)
		{
			modelo.addRow(reg);
		}
	}
}

package Interfaz;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.util.Vector;

import javax.swing.BorderFactory;
import javax.swing.JPanel;

import Perfomance.Draws;
import Perfomance.Recursos;
import Perfomance.Script;

public class UserIcon extends JPanel 
{
	private static final long serialVersionUID = -8696862113358656641L;
	public String user;
	public Image img;
	
	private static Draws contorno;
	private static Font font;
	private static WindowProfileUser wpu;
	private static Color paletaColores[] = 
		{
			Color.decode("#F7F4DF"),
			Color.decode("#E3E0D8"),
			Color.decode("#F3EDE3"),
			Color.decode("#ECEDD5"),
			Color.decode("#F0DED1"),
			Color.decode("#F7F4DF"),
		};
	static
	{
		wpu = new WindowProfileUser();
		contorno = new Draws();
		contorno.setColorContorno(Color.BLUE);
		contorno.setColorHueco(Color.white);
	}
	public static int indexColor;
	
	public UserIcon(String name,String user, Image img) 
	{
		this.user = "Usuario: "+user;
		this.img = img;
		setPreferredSize(new Dimension(185, 185));
		setBorder(BorderFactory.createLineBorder(Color.BLACK));
		setBackground(paletaColores[indexColor]);
		nextColor();
		
		font = new Font("Sans Serif", Font.BOLD, 22);
		
		addMouseMotionListener(new MouseMotionAdapter() 
		{
			@Override
			public void mouseMoved(MouseEvent e) 
			{
				setCursor(Recursos.handCursor);
			}
		});
		
		addMouseListener(new MouseAdapter() 
		{
			@Override
			public void mouseClicked(MouseEvent e) 
			{
				
				Vector<String[]> regs = Script.getInstance().consultaGet
				(String.format("select distinct pg.Nombre_juego from juegosmesa pg " + 
					"inner join partidas p on p.Id_juego = pg.Id_juego " + 
					"inner join partidas_has_jugadores phj " + 
					"on phj.Id_partida = p.Id_partida " + 
					"inner join jugadores j on phj.Id_jugador = j.Id_jugador \n" + 
					"where j.Nombre_usuario='%s';",user));
				
				String games[] = new String[regs.size()];
				
				for(int i=0; i<games.length; i++)
				{
					games[i] = regs.elementAt(i)[0];
				}
				
				WindowIconUsers.destroy();
				wpu.mostrar(UserIcon.this.img,user,games,UserIcon.this,name);
			}
		});
		
	}
	
	private static void nextColor()
	{
		indexColor++;
		
		if(indexColor==paletaColores.length-1)
			indexColor=0;
		
	}
	
	@Override
	protected void paintComponent(Graphics g) 
	{
		super.paintComponent(g);
		
		g.setFont(font);
		//g.drawImage(img, 30, 30, 130,130,this);
		g.drawString(user, 10, 20);
	
		contorno.drawContour(10, 25, 150, 150, 10, 10, g);
		contorno.drawInternalImageContour(img, g);
	}
	
}

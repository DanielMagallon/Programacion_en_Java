package Interfaz;

import static Perfomance.Recursos.seePlayers;
import static Perfomance.Recursos.startGame;
import static Perfomance.Recursos.playIcon;
import static Perfomance.Recursos.pause;
import static Perfomance.Recursos.reset;
import static Perfomance.Recursos.suspendGame;
import static Perfomance.Recursos.fullScreen;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.io.File;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JDesktopPane;
import javax.swing.JDialog;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JToggleButton;
import javax.swing.JToolBar;
import javax.swing.event.InternalFrameAdapter;
import javax.swing.event.InternalFrameEvent;

import Ejecutbale.Exe;
import Games.General.Game;
import Games.General.MethodParameter;
import Perfomance.Recursos;
import Perfomance.Script;
import Perfomance.Serializa;
import SerFiles.Var;

public class FrameGame extends JPanel implements MethodParameter<String>
{

	private static final long serialVersionUID = 5239487496132855845L;
	
	private TimeGame tiempo;
	private JLabel lblTime;
	private WindowIconUsers wiu;
	public static WindowJuegos wjuegos;
	private JToolBar barraGame;
	private JButton btnChosseGame,btnSeePlayers,btnBigScreen,btnReset,btnSuspend;
	public JToggleButton btnPlaey;
	
	public static FrameGame instance;
	
	private JDesktopPane desktop;
	public JInternalFrame internalf;
	
	private BigScreen bs;
	
	@SuppressWarnings("serial")
	private FrameGame() 
	{
		
		setSize(600,600);
		setLayout(new BorderLayout());
		
		desktop = new JDesktopPane() 
		{
			@Override
			protected void paintChildren(Graphics g) 
			{
				g.drawImage(Recursos.fondo, 0,0,getWidth(),getHeight(), this);
				super.paintChildren(g);				
			}
		};
		
		barraGame = new JToolBar(JToolBar.HORIZONTAL); 
		barraGame.setFloatable(false);
		barraGame.setBackground(Color.white);
		
		tiempo = new TimeGame(this);
		
		add(desktop,"Center");
		internalf = new JInternalFrame("Ventana de juegos",true,true,true,true);
		
		internalf.addInternalFrameListener(new InternalFrameAdapter() 
		{
			@Override
			public void internalFrameClosing(InternalFrameEvent e) 
			{
				if(!game.isShowedGame())
					return;
				
				if(!game.isFinished())
				{
					tiempo.waits();
					if(JOptionPane.showConfirmDialog(internalf, "Desea salir del juego?\n"
						+ "Se suspendera la partida actual","...",
						JOptionPane.YES_NO_OPTION) == JOptionPane.OK_OPTION)
					{
						if(game.suspend()==1)
						{
							tiempo.suspend();
							internalf.hide();
						}
					}
					else tiempo.continues();
				} else {
					tiempo.suspend();
					internalf.hide();
				}
			}
		});
		
		internalf.setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
		
		desktop.add(internalf);
		bs = new BigScreen(internalf);
		
		add(barraGame,"North");
	
		wjuegos = new WindowJuegos();
		wiu = new WindowIconUsers();
		
		btnChosseGame = new JButton(startGame);
		btnChosseGame.setMargin(null);
		btnChosseGame.setOpaque(false);
		btnChosseGame.setBorderPainted(false);
		btnChosseGame.setToolTipText("Escoger un juego");
		btnChosseGame.addActionListener((a)-> 
		{
			if(Script.getInstance().bdActual.equalsIgnoreCase("juegosdemesa"))
			{
				juegos();
			}
			else
			{
				
				int x = JOptionPane.showConfirmDialog(this, "No esta conectado a la base de datos juegosdemesa\n"
						+ "Desea conectarse","Base de datos no conectada",JOptionPane.YES_NO_OPTION);
				
				if(x==JOptionPane.OK_OPTION)
				{
					Exe.windConect.conectar();
					juegos();
				}
			}
		});
		
		
		btnSeePlayers = new JButton(seePlayers);
		btnSeePlayers.setOpaque(false);
		btnSeePlayers.setBorderPainted(false);
		btnSeePlayers.setToolTipText("Ver perfiles");
		btnSeePlayers.addActionListener((q)-> {
			if(Script.getInstance().bdActual.equalsIgnoreCase("juegosdemesa"))
				wiu.mostrar();
			else
			{
				int x = JOptionPane.showConfirmDialog(this, "No esta conectado a la base de datos juegosdemesa\n"
						+ "Desea conectarse","Base de datos no conectada",JOptionPane.YES_NO_OPTION);
				
				if(x==JOptionPane.OK_OPTION)
				{
					Exe.windConect.conectar();
					wiu.mostrar();
				}
			}
			
		});
		
		btnPlaey = new JToggleButton(playIcon);
		btnPlaey.setEnabled(false);
		btnPlaey.setOpaque(false);
		btnPlaey.setBorderPainted(false);
		btnPlaey.setToolTipText("Empezar juego");
		btnPlaey.addActionListener((w)->
		{
			if(btnPlaey.isSelected())
			{
				game.play();
				tiempo.start();
			}else
			{
				tiempo.stop();
				game.stop();
			}
		});
		
		btnBigScreen = new JButton(fullScreen);
		btnBigScreen.setToolTipText("Pantalla completa");
		btnBigScreen.setEnabled(false);
		btnBigScreen.setBorderPainted(false);
		btnBigScreen.setOpaque(false);
		btnBigScreen.addActionListener((A)->{
			internalf.hide();
			bs.show(game.getContenedor());
		});
		
		btnReset = new JButton(reset);
		btnReset.setToolTipText("Reiniciar juego");
		btnReset.setEnabled(false);
		btnReset.setBorderPainted(false);
		btnReset.setOpaque(false);
		btnReset.addActionListener((a)->{
			tiempo.reset();
			game.reset();
		});
		
		btnSuspend = new JButton(suspendGame);
		btnSuspend.setToolTipText("Suspender partida");
		btnSuspend.setEnabled(false);
		btnSuspend.setBorderPainted(false);
		btnSuspend.setOpaque(false);
		btnSuspend.addActionListener((a)->{
			if(game.suspend()==1)
				tiempo.suspend();
		});
		
		barraGame.add(btnChosseGame);
		barraGame.add(btnSeePlayers);
		barraGame.add(btnPlaey);
		barraGame.add(btnBigScreen);
		barraGame.add(btnReset);
		barraGame.add(btnSuspend);
		barraGame.addSeparator(new Dimension(100, 32));
		barraGame.add(lblTime = new JLabel("00:00:00"));
	}
	
	private void juegos() {

		if(internalf.isVisible())
		{
			if(!game.isShowedGame())
				return;
			
			if(!game.isFinished())
			{
				tiempo.waits();
				int x = JOptionPane.showConfirmDialog(internalf, "Desea jugar otro juego?\n"
						+ "Se suspendera la partida actual","...",JOptionPane.YES_NO_OPTION);
				
				if(x == JOptionPane.OK_OPTION)
				{
					game.suspend();
					tiempo.suspend();
					wjuegos.mostrar();
				}else tiempo.continues();
			}else
			{
				tiempo.suspend();
				internalf.hide();
				wjuegos.mostrar();
			}
		}
		else wjuegos.mostrar();
	}

	public static FrameGame getInstance()
	{
		if(instance==null)
			instance = new FrameGame();
		
		return instance;
	}
	
	public Game<JInternalFrame> game;
	@SuppressWarnings("unchecked")
	public void initGame(File file, List<Object[]> datos)
	{
		internalf.getContentPane().removeAll();
		
		game = (Game<JInternalFrame>) Serializa.writeObject(file); 
		game.init(internalf,WindowParticipantes.enJuego,WindowParticipantes.idJuego,
					datos,tiempo);
		game.initGame();
		
		btnPlaey.setEnabled(true);
		
		internalf.setSize(game.getContenedor().getPreferredSize());
		internalf.setVisible(true);
		
		
		validate();
	}
	
	@SuppressWarnings("unchecked")
	public void continueGame(File file, List<Object[]> datos, String part,String idPart,String juego)
	{
		internalf.getContentPane().removeAll();
		
		
		game = (Game<JInternalFrame>) Serializa.writeObject(file); 
		game.init(internalf,WindowParticipantes.enJuego,WindowParticipantes.idJuego,
					datos,tiempo);
		
		Var variables = (Var) Serializa.writeObject(new File(Recursos.pathFilesGame+juego+"/"+part+".part"));
		
		tiempo.h = variables.hora;
		tiempo.min = variables.min;
		tiempo.seg = variables.seg;
		
		game.continueGame(variables.index, part,idPart,variables.game);
		
		internalf.setSize(game.getContenedor().getPreferredSize());
		internalf.setVisible(true);
		
		game.play();
		tiempo.start();
	}

	@Override
	public void methodSet(String t) 
	{
		if(t.equalsIgnoreCase("Duration"))
			lblTime.setText(tiempo.getDuration());
		
		else if(t.equalsIgnoreCase("Reset"))
		{
			lblTime.setText(tiempo.getDuration());
			
			if(!btnPlaey.isEnabled())
				btnPlaey.setEnabled(true);
			
			if(!btnSuspend.isEnabled())
				btnSuspend.setEnabled(true);
		}
		
		else if(t.equalsIgnoreCase("stop"))
		{
			btnPlaey.setIcon(playIcon);
			btnPlaey.setSelected(false);
			btnSuspend.setEnabled(false);
			btnReset.setEnabled(false);
			btnBigScreen.setEnabled(false);
		}
		
		else if(t.equalsIgnoreCase("suspend"))
		{
			btnPlaey.setIcon(playIcon);
			btnPlaey.setSelected(false);
			btnSuspend.setEnabled(false);
			btnReset.setEnabled(false);
			btnBigScreen.setEnabled(false);
			lblTime.setText(tiempo.getDuration());
			internalf.hide();
		}
		
		else if(t.equalsIgnoreCase("Start"))
		{
			btnPlaey.setIcon(pause);
			btnPlaey.setSelected(true);
			btnPlaey.setEnabled(true);
			btnSuspend.setEnabled(true);
			btnReset.setEnabled(true);
			btnBigScreen.setEnabled(true);
		}
		
		else if(t.equalsIgnoreCase("Finished"))
		{
			btnPlaey.setIcon(playIcon);
			btnSuspend.setEnabled(false);
			btnPlaey.setSelected(false);
			btnPlaey.setEnabled(false);
		}
	}
}


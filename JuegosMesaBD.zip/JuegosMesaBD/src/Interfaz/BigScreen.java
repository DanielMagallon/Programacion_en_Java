package Interfaz;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Toolkit;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JDialog;
import javax.swing.JInternalFrame;

@SuppressWarnings("serial")
public class BigScreen extends JDialog
{
	private Component c;
	
	public BigScreen(JInternalFrame internalf) 
	{
		setModal(true);
		setResizable(false);
		setSize(Toolkit.getDefaultToolkit().getScreenSize());
		setLocationRelativeTo(null);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		
		setLayout(new BorderLayout());
		
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent arg0) 
			{
				remove(c);
				internalf.add(c);
				internalf.setVisible(true);
			}
		});
	}
	
	public void show(Component component)
	{
		c = component;
		add(component,"Center");
		setVisible(true);
	}
}

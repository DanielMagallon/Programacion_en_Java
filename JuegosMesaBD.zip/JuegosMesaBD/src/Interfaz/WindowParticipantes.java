package Interfaz;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import Perfomance.Recursos;
import Perfomance.Script;


@SuppressWarnings("serial")
public class WindowParticipantes extends JDialog implements ActionListener
{
	private JPanel panelJugadores;
	private boolean busqueda;
	private PanelBusquedas panelSearch;
	private ArrayList<LabelPlayer> panelesParticipantes;
	private static JButton cancel,ok;

	public static String enJuego,idJuego;
	public static WindowParticipantes wp;
	public static int MAX_PLAYERS;
	
	protected static HashMap<Integer, Object[]> datosParticpantes;
	
	public WindowParticipantes() 
	{
		wp = this;
		setModal(true);
		setLayout(new BorderLayout());
		setResizable(false);
		setUndecorated(true);

		datosParticpantes = new LinkedHashMap<>();
		
		JPanel botones = new JPanel();
		{	
			botones.setBackground(Color.WHITE);
			botones.setBorder(BorderFactory.createLineBorder(Color.RED));
			
			cancel = new JButton("Regresar");
			cancel.setBackground(Color.WHITE);
			cancel.addActionListener((a)-> {
				this.dispose();
				LabelPlayer.num_part=0;
				
			});
			
			ok = new JButton("Continuar");
			ok.setBackground(Color.white);
			ok.addActionListener(this);
			
			
			botones.add(cancel);
			botones.add(ok);
			
			add(botones,"South");
			
		}
		
		panelJugadores = new JPanel();
		panelJugadores.setLayout(new BoxLayout(panelJugadores, BoxLayout.Y_AXIS));
	
		JScrollPane sc = new JScrollPane(panelJugadores);
		
		panelSearch = new PanelBusquedas(this,"Buscar por usuario: ",15);
		panelSearch.setBorder(BorderFactory.createLineBorder(Color.gray,3,true));
		add(panelSearch,"North");
		add(sc,"Center");
		
		panelesParticipantes = new ArrayList<>();
	}
	
	public static ArrayList<Object[]> participantes;
	@Override
	public void actionPerformed(ActionEvent e) 
	{
		if(e.getSource() == ok)
		{
			LabelPlayer.num_part=0;
		
			participantes = new ArrayList<>();
			
			datosParticpantes.forEach((k,v)->{
				
				participantes.add(v);
			});

			this.dispose();
			FrameGame.wjuegos.dispose();
		
				FrameGame.getInstance().initGame(new File(Recursos.pathFilesGame+enJuego+".game"), 
						participantes);
		}
		
		else if(panelSearch.isSearchCommand(e.getSource()))
		{
				String valorCampo = Script.getInstance().consultaUnique(String.format
					("select Id_jugador from jugadores where Nombre_usuario = '%s'", 
					panelSearch.getInfoTextField()));
					
				if(valorCampo==null)
				{
					JOptionPane.showMessageDialog(this, "No se encontro algun jugador con ese nombre"
							+ " de usuario", 
							"Usuario no registrado", JOptionPane.ERROR_MESSAGE);
					return;
				}
				
					panelJugadores.removeAll();
					put(valorCampo);
					
					setSize(550, 300);
					busqueda=true;
					panelJugadores.validate();
						
		}
		else
		{
			if(busqueda)
			{
				busqueda = false;
				putPanels();
			}
		}
	}
	
	private void put(String idPanel)
	{
		
		for(LabelPlayer p : panelesParticipantes)
		{
			if(p.getID().equals(idPanel))
			{
				panelJugadores.add(p);
				break;
			}
		}
		
	}
	
	private void putPanels()
	{
		panelJugadores.removeAll();
		LabelPlayer.altura=0;
		
		for(LabelPlayer p : panelesParticipantes)
		{
			panelJugadores.add(p);
			LabelPlayer.altura+=150;
		}
		
		pack();
	}
	
	
	public void jugadores(boolean twoPlayers, String juego, String idJuego)
	{
		WindowParticipantes.idJuego = idJuego;
		enJuego = juego;
		
		MAX_PLAYERS = twoPlayers ? 2 : 7;
		
		panelJugadores.removeAll();
		datosParticpantes.clear();
		panelesParticipantes.clear();
		ok.setEnabled(false);
		LabelPlayer.altura=0;
		
		Script.getInstance().consultadaMetaData("select Id_jugador,Nombre_jugador,Nombre_usuario,"
				+ "Pasw_jugador,Imagen_avatar from jugadores as j inner join avatars "
				+ "as a on j.Id_avatar = a.Id_avatar order by Id_jugador;");
		
		for(String regs[] : Script.getInstance().datosTable)
		{
			panelesParticipantes.add(new LabelPlayer(Recursos.getImage("/Recursos/Avatar/", 
					regs[4]), regs[0],regs[1], regs[2],regs[3],panelesParticipantes.size()));
			
			panelJugadores.add(panelesParticipantes.get(panelesParticipantes.size()-1));
		}	
		
		pack();
		setLocationRelativeTo(null);
		setVisible(true);
	}
	
	public static void agregaParticipante(ImageIcon img, String usuario,String iduser, int key)
	{
		datosParticpantes.put(key, new Object[] {img,iduser,usuario});
	}
	
	public static void remover(int key)
	{
		datosParticpantes.remove(key);
	}
	
	public static void verifica()
	{
		if(LabelPlayer.num_part>=2)
		{
			if(!ok.isEnabled())
				ok.setEnabled(true);
		}else ok.setEnabled(false);
		
	}
	
	@Override
	public void pack() 
	{
		if(LabelPlayer.altura>=600)
		{
			setSize(550, 600);
		}else setSize(550, LabelPlayer.altura+100);
	}
}
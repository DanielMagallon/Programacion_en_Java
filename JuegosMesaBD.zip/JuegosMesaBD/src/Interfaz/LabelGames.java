package Interfaz;

import static Perfomance.Recursos.getImage;
import static Perfomance.Recursos.addGame;
import static Perfomance.Recursos.handCursor;
import static Interfaz.PanelTablas.ventanaTablas; 

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Vector;

import javax.swing.BorderFactory;
import javax.swing.JPanel;

import Perfomance.Draws;
import Perfomance.Script;

@SuppressWarnings("serial")
public class LabelGames extends JPanel
{
	private Image imagen;
	private static Font font;
	private Vector<String[]> datos;
	private String registro[],titulo;
	private int index=0;
	public static Draws areaImagen;
	private Mouse evento;
	
	private WindowParticipantes wps; 
	
	public LabelGames()
	{
		setBorder(BorderFactory.createLineBorder(Color.BLACK));
		font = new Font("Sans Serif", Font.ITALIC|Font.BOLD, 72);
		setPreferredSize(new Dimension(800, 500));
		setBackground(Color.white);
		
		areaImagen = new Draws();
		areaImagen.colorAro(Color.blue);
		areaImagen.colorHueco(Color.black);
		areaImagen.colorNext(Color.green);
		areaImagen.colorBefor(Color.green);
		
		wps = new WindowParticipantes();
		evento = new Mouse();
		
		
		addMouseMotionListener(evento);
		addMouseListener(evento);
	}
	
	public void setJuegos(Vector<String[]> vec)
	{
		datos = vec;
	}
	
	public boolean find(String id)
	{
		for(int i=0; i<datos.size(); i++)
		{
			if(datos.elementAt(i)[0].equalsIgnoreCase(id))
			{
				index = i;
				return true;
			}
		}
		
		return false;
	}
	
	public void get()
	{
		if(datos.isEmpty())
		{
			imagen = addGame.getImage();
			titulo = "Agregar juego";
		}
		
		else
		{
			registro = datos.elementAt(index);
			titulo = registro[1];
			imagen = getImage("/Recursos/Icon_games/", registro[3]).getImage();
			
		}
		repaint();
	}
	
	public void next()
	{
		index++;
		if(index==datos.size())
		{
			index=0;
		}
		
		get();
	}
	
	public void before()
	{
		index--;
		
		if(index==-1)
		{
			index = datos.size()-1;
		}
		
		get();
	}
	
	@Override
	protected void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		
		g.setFont(font);
		g.drawString(titulo, 120, 70);
		areaImagen.dibujarAro(250, 100,300,20, g);
		areaImagen.drawInternalAroImage(imagen, g);
		areaImagen.drawNext(630, 160, 100, 100, g);
		areaImagen.drawBefore(190, 160, 100, 100, g);
	}

	class Mouse extends MouseAdapter
	{
		boolean onImg,onNext,onBef;
		
		@Override
		public void mouseMoved(MouseEvent e) 
		{
			if(areaImagen.isOnImage(e.getX(), e.getY()))
			{
				if(!onImg)
				{
					onImg = true;
					setCursor(handCursor);
					areaImagen.colorHueco(Color.cyan);
					repaint();
				}
			}
			else if(areaImagen.isOnNext(e.getX(), e.getY()))
			{
				if(!onNext)
				{
					onNext = true;
					areaImagen.colorNext(Color.CYAN);
					repaint();
					setCursor(handCursor);
				}
			}
			else if(areaImagen.isOnBefore(e.getX(), e.getY()))
			{
				if(!onBef)
				{
					onBef = true;
					setCursor(handCursor);
					repaint();
					areaImagen.colorBefor(Color.CYAN);
				}
			}
			else
			{
				if(onNext || onBef)
				{
					onNext = onBef = false;
					areaImagen.colorBefor(Color.green);
					areaImagen.colorNext(Color.green);
					repaint();
					setCursor(null);
				}
				else if(onImg)
				{
					onImg = false;
					areaImagen.colorHueco(Color.black);
					setCursor(null);
					repaint();
				}
			}
		}
		
		@Override
		public void mouseClicked(MouseEvent arg0) 
		{
			if(datos.size()>=1)
			{
				if(onNext)
				{
					next();
				}
				
				else if(onBef)
				{
					before();
				}
			}
			
			if(onImg)
			{
				areaImagen.colorHueco(Color.black);
				repaint();
				if(datos.isEmpty())
				{
					String consulta = "select * from juegosmesa;";
					ventanaTablas.setSQLTable("juegosmesa");
					ventanaTablas.tablaDatos.consultaColumnas(consulta);
					ventanaTablas.setVisible(true);
					
					 datos = Script.getInstance().consultaGet("select * from juegosmesa;");
					 get();
				}
					
				else	
					wps.jugadores(registro[2].equals("0"),titulo,registro[0]);
			}
			
		}
	}
}


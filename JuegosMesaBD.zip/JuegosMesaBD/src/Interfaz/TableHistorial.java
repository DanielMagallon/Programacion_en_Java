package Interfaz;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.util.Vector;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

@SuppressWarnings("serial")
public class TableHistorial extends JPanel 
{
	private DefaultTableModel modelo;
	private JScrollPane sc;
	private JTable table;
	private DefaultTableCellRenderer tcr = new DefaultTableCellRenderer();
	private JLabel titulo;
	
	
	public TableHistorial() 
	{
		setLayout(new BorderLayout());
		
		tcr.setHorizontalAlignment(SwingConstants.CENTER);
		modelo = new DefaultTableModel() {
			@Override
			public boolean isCellEditable(int row, int column) {
				return false;
			}
		};
		table = new JTable(modelo);
		sc = new JScrollPane(table);
		
		
		Color fondo = Color.decode("#92DCE0");
		table.getTableHeader().setBackground(fondo);
		sc.getViewport().setBackground(fondo);
		setBackground(Color.cyan);
	
		
		table.setFont(new Font("Serif", Font.PLAIN, 20));
		table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		table.getTableHeader().setFont(new Font("Serif", Font.BOLD, 24));
		add(sc,"Center");
		
		add(titulo = new JLabel(),"North");
		titulo.setHorizontalAlignment(SwingConstants.CENTER);
		titulo.setFont(new Font("Sans", Font.ITALIC, 32));
	}
	
	public void setTitle(String tit)
	{
		titulo.setText("Partidas "+tit);
	}
	
	
	public void actualizar(Vector<String[]> registros,String...columnas)
	{
		delete();
		
		int tam=0;
		
		for(String c : columnas)
		{
			if(c.length()>tam)
				tam = c.length();

			modelo.addColumn(c);
		}
		
		for(String reg[] : registros)
		{
			for(String r : reg)
				if(r.length()>tam)
					tam = r.length();
			
			modelo.addRow(reg);
		}
	
		maxWidth = (tam*13);
		
		for(int i=0; i<columnas.length; i++)
		{
			table.getColumnModel().getColumn(i).setPreferredWidth(maxWidth);
			table.getColumnModel().getColumn(i).setCellRenderer(tcr);
		}
	}

	public void delete()
	{
		modelo.setRowCount(0);
		modelo.setColumnCount(0);
	}
	
	private int maxWidth;
	
	public void actualizar(String[] dataRow,String...cols)
	{
		delete();
		
		int tam=0;
		
		for(String c : cols)
		{
			if(c.length()>tam)
				tam = c.length();
			
			modelo.addColumn(c);
		}
		
		for(int i=0; i<dataRow.length; i++)
		{
			if(dataRow[i].length()>tam)
				tam = dataRow[i].length();
		}
	
		maxWidth = (tam*13);
		
		for(int i=0; i<cols.length; i++)
		{
			table.getColumnModel().getColumn(i).setCellRenderer(tcr);
			table.getColumnModel().getColumn(i).setPreferredWidth(maxWidth);
		}
		
		
		modelo.addRow(dataRow);
	}
}

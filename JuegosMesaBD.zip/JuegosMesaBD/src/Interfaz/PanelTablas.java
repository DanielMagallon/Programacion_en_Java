package Interfaz;

import java.awt.BorderLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Vector;

import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import Perfomance.Recursos;

public class PanelTablas extends JPanel
{

	private static final long serialVersionUID = -2091378996645157174L;

	private JPanel panelBD,panelTables;
	
	private JLabel lblBd,lblsTables[];
	
	public static WindTable ventanaTablas;
	public static  WindowAvatars ventanaAvat;
	
	private TableListener list;
	
	public PanelTablas() 
	{
		setLayout(new BorderLayout(0,5));
		
		list = new TableListener();
		ventanaTablas = new WindTable();
		ventanaAvat = new WindowAvatars();
		
		lblBd = new JLabel("Base de datos: ");
		
		panelBD = new JPanel();
		panelBD.add(lblBd);
		
		
		panelTables = new JPanel();
		JScrollPane sc = new JScrollPane(panelTables);
		panelTables.setLayout(new BoxLayout(panelTables, BoxLayout.Y_AXIS));
		
		add(panelBD,"North");
		add(sc,"Center");
	}
	
	public void actualizar(String bd, Vector<String> tables)
	{
		lblBd.setText("Base de datos: "+bd);
		
		lblsTables = new JLabel[tables.size()];
		
		panelTables.removeAll();
		
		for(int i=0; i<tables.size(); i++)
		{
			panelTables.add(lblsTables[i] = new JLabel(tables.get(i),Recursos.tablaImg,
					JLabel.CENTER));
			
			lblsTables[i].addMouseListener(list);
		}
		
		panelTables.validate();
		panelTables.repaint();
	}
	
	class TableListener extends MouseAdapter
	{
		@Override
		public void mouseClicked(MouseEvent e) 
		{
			JLabel lbl = (JLabel) e.getComponent();
			
				if(lbl.getText().equalsIgnoreCase("avatars"))
				{
					
					ventanaAvat.mostrar(false);
				}
				
				else
				{
					String consulta = "select * from "+lbl.getText()+";";
					ventanaTablas.setSQLTable(lbl.getText());
					ventanaTablas.validarFKeys();
					ventanaTablas.tablaDatos.consultaColumnas(consulta);
					ventanaTablas.setVisible(true);
				}
		}
	}
}

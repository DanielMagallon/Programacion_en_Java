package Interfaz;

import javax.swing.Timer;

import Games.General.MethodParameter;


public class TimeGame
{
	public int h,min,seg;
	
	private Timer tiempo;
	
	private String timeString;
	
	private MethodParameter<String> met;
	
	public TimeGame(MethodParameter<String> metodo) 
	{
		met = metodo;
		
		tiempo = new Timer(1000, (a)-> 
		{
			seg++;
			
			if(seg==60)
			{
				min++;
				seg=0;
			}
			
			if(min==60)
			{
				h++;
				min=0;
			}
			
			timeString = String.format("%02d:%02d:%02d", h,min,seg);
			metodo.methodSet("Duration");
		});
	}
	
	public String getDuration()
	{
		return timeString;
	}
	
	public void reset()
	{
		tiempo.stop();
		h = 0;
		min = 0;
		seg = 0;
		timeString = String.format("%02d:%02d:%02d", h,min,seg);
		met.methodSet("Reset");
		tiempo.start();
	}
	
	public void stop()
	{
		tiempo.stop();
		met.methodSet("stop");
	}
	
	public void waits()
	{
		tiempo.stop();
	}
	
	public void continues()
	{
		tiempo.start();
	}
	
	public void suspend()
	{
		tiempo.stop();
		h = 0;
		min = 0;
		seg = 0;
		timeString = String.format("%02d:%02d:%02d", h,min,seg);
		met.methodSet("suspend");
	}
	
	public void finished()
	{
		tiempo.stop();
		met.methodSet("Finished");
	}
	
	public void start()
	{
		tiempo.start();
		met.methodSet("Start");
		
		//Obtiene el nombre del metodo
		//String name = new Object() {}.getClass().getEnclosingMethod().getName();
	}
}

package Interfaz;

import java.awt.BorderLayout;

import javax.swing.JDialog;

@SuppressWarnings("serial")
public class WindowRenaudar extends JDialog 
{
	public WindowRenaudar() 
	{
		setLayout(new BorderLayout());
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setSize(700, 300);
		setLocationRelativeTo(null);
		setModal(true);
	}
	
	public void addTable(TableButton tb)
	{
		getContentPane().removeAll();
		getContentPane().add(tb.getScroll(),"Center");
		
		setVisible(true);
	}
}

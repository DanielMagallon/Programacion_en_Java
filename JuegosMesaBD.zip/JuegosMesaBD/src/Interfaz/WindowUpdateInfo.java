package Interfaz;

import java.awt.GridLayout;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import Perfomance.Script;

public class WindowUpdateInfo extends JDialog{

	private static final long serialVersionUID = 3006100002121413136L;

	private JCheckBox passRequired;
	private JButton btnOk;
	private JTextField[] txts;
	
	public String user;
	
	public WindowUpdateInfo() 
	{
		setModal(true);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		
		JTextField txtId,txtNombre,txtUsuario,txtPass;
		txtId = new JTextField(15);
		txtId.setEditable(false);
		
		txtNombre = new JTextField(15);
		txtUsuario = new JTextField(15);
		txtPass = new JPasswordField(15);
		passRequired = new JCheckBox("Con password: ");
		
		txts = new JTextField[]{txtId,txtNombre,txtUsuario,txtPass};
				
		setLayout(new GridLayout(5,2,5,5));
		
		add(new JLabel("Id: "));
		add(txtId);
		
		add(new JLabel("Nombre: "));
		add(txtNombre);
		
		add(new JLabel("Nombre de usuario: "));
		add(txtUsuario);
		
		add(passRequired);
		add(txtPass);
		
		JPanel p = new JPanel();
		btnOk = new JButton("Aplicar cambios");
		JButton cancel = new JButton("Cancelar");
		cancel.addActionListener((a)->this.dispose());
		p.add(btnOk);
		p.add(cancel);
		add(p);
		
		passRequired.addActionListener((A)->
		{
			if(passRequired.isSelected())
			{
				passRequired.setText("Con password");
				txtPass.setEditable(true);
			}
			else  {
			
				passRequired.setText("Sin password");
				txtPass.setEditable(false);
			}
		});
		
		btnOk.addActionListener((A)->
		{
			String nombre = txtNombre.getText();
			 
			if(nombre.trim().isEmpty())
			{
				nombre = re[1];
			}
			
			 user = txtUsuario.getText();
			
			if(Script.getInstance().exists(user, "jugadores", "Nombre_usuario",
					"Id_jugador!="+re[0]))
			{
				JOptionPane.showMessageDialog(this, "Ese nombre de usuario ya existe", 
						"Nombre existente", JOptionPane.WARNING_MESSAGE);
				return;
			}
			
			if(user.trim().isEmpty())
			{
				user = re[2];
			}
			
			String pass = passRequired.isSelected() ? new String(txtPass.getText()) : "";

			if(passRequired.isSelected())
			{
				if(pass.trim().isEmpty())
				{
					pass = re[3];
				}
			}
			
			String update = String.format("Update jugadores set Nombre_jugador='%s',Nombre_usuario='%s',"
					+ "Pasw_jugador='%s' where Id_jugador=%s", nombre,user,pass,re[0]);
			
			if(Script.getInstance().update(update))
			{
				
				JOptionPane.showMessageDialog(this, "Campos actualizados",
						"Se han actualizados los datos", 
						JOptionPane.INFORMATION_MESSAGE);
			}
		});
	}
	
	private String re[];
	private boolean passValue;
	public void mostrar(Vector<String[]> datos)
	{
		int pos=0;
		re = datos.get(0);
		
		for(String regs : datos.get(0))
		{
			txts[pos].setText(regs);
			pos++;
		}
		
		passValue = txts[3].getText().equals("");
		passRequired.setSelected(!passValue);
		passRequired.setText(!passValue ? "Con contrase�a" : "Sin contrase�a");
		txts[3].setEditable(!passValue);
		
		pack();
		setLocationRelativeTo(null);
		setVisible(true);
	}
}

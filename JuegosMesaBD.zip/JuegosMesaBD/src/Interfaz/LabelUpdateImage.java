package Interfaz;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import javax.swing.JTextField;

import static Perfomance.Recursos.handCursor;
import static Perfomance.Recursos.fileChosser;

@SuppressWarnings("serial")
public class LabelUpdateImage extends JLabel implements ActionListener
{
	private File fileImg;
	private String name,tipoImg;
	private BufferedImage bf;
	private JTextField txt;
	private ImageIcon imagen;
	private Viewer viewer;
	private JPopupMenu pop;
	private JMenuItem mt1,mt2;
	
	public LabelUpdateImage(JTextField txtRef, String msg) 
	{
		super(msg,CENTER);
		txt = txtRef;
		pop = new JPopupMenu();
		
		mt1 = new JMenuItem("Cambiar imagen");
		 mt2 = new JMenuItem("Ver imagen");
		
		mt1.addActionListener(this);
		mt2.addActionListener(this);
		
		pop.add(mt1);
		pop.add(mt2);
		mt2.setEnabled(false);
		
		viewer = new Viewer();
		addMouseListener(new Action());
	}
	
	@Override
	public void actionPerformed(ActionEvent arg0) 
	{
		if(arg0.getSource() == mt1)
		{
			if(fileChosser.showOpenDialog(LabelUpdateImage.this) == JFileChooser.APPROVE_OPTION)
			{
				fileImg = fileChosser.getSelectedFile();
			
				imagen = new ImageIcon(fileImg.getPath());
				mt2.setEnabled(true);
				
				name = fileImg.getName();
				tipoImg = name.substring(name.indexOf("."));
				name = name.substring(0, name.indexOf("."));
				
				if(txt!=null)
					txt.setText(name);
			}
		}
		
		else
		{
			viewer.look();
		}
	}
	
	public boolean createBufferImage()
	{
		try 
		{
			bf = ImageIO.read(fileImg);
			return true;
			
		} catch (IOException e) 
		{
			JOptionPane.showMessageDialog(this, "Ocurrio un error al leer la imagen seleccionada", 
					"No se pudo cargar la imagen", JOptionPane.ERROR_MESSAGE);
			return false;
		}
	}
	
	public BufferedImage getBufferImage()
	{
		return bf; 
	}
	
	public String getFormat()
	{
		return tipoImg;
	}
	
	public boolean hayImagen()
	{
		return imagen!=null;
	}
	
	public void reset()
	{
		mt2.setEnabled(false);
		imagen = null;
	}
	
	class Action extends MouseAdapter
	{
		@Override
		public void mouseClicked(MouseEvent e) 
		{
			pop.show(LabelUpdateImage.this, e.getX(), e.getY());
		}
		
		@Override
		public void mouseEntered(MouseEvent e) 
		{
			setCursor(handCursor);
		}
	}
	
	class Viewer extends JDialog
	{
		private JLabel lbl;
		
		public Viewer() 
		{
			setModal(true);
			setLayout(new BorderLayout());
			
			lbl = new JLabel();
			lbl.setHorizontalAlignment(JLabel.CENTER);
			
			add(lbl);
		}
		
		public void look()
		{
			lbl.setIcon(imagen);
			pack();
			setLocationRelativeTo(null);
			setVisible(true);
		}
	}
}

package Interfaz;

import java.awt.Color;
import java.awt.Component;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.util.ArrayList;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;

import Perfomance.MetodoGet;
import Perfomance.Recursos;


@SuppressWarnings("serial")
public class TableButton extends JTable 
{
	private DefaultTableModel modelo;
	private JScrollPane sc;
	private ArrayList<MetodoGet<Vector<String[]>>> actions;
	public Vector<Object[]> registro; 
	
	public TableButton()
	{
		modelo = new DefaultTableModel() 
		{
			@Override
			public boolean isCellEditable(int row, int column) 
			{
				return false;
			}
			
			@Override
			public Class<?> getColumnClass(int col) 
			{
				return col == 3 ? JButton.class : String.class; 
			}
			
		};
		
		setSelectionBackground(null);

		actions = new ArrayList<>();
		modelo.addColumn("Id_partida");
		modelo.addColumn("Nombre de la partida");
		modelo.addColumn("Duracion de la partida");
		modelo.addColumn("Renaudar partida (Presionar boton)");
		
		setDefaultRenderer(JButton.class, new TableCellRenderer() {
			
			@Override
			public Component getTableCellRendererComponent(JTable arg0, Object arg1, boolean arg2, 
					boolean arg3, int arg4,int arg5) 
			{
				return (Component) arg1;
			}
		});
		
		sc = new JScrollPane(this);
		
		addMouseListener(new MouseAdapter() 
		{
			@Override
			public void mouseClicked(MouseEvent e) 
			{
				int row = TableButton.this.rowAtPoint(e.getPoint());
				int col = TableButton.this.columnAtPoint(e.getPoint());
				
				if(modelo.getColumnClass(col).equals(JButton.class))
				{
					registro = new Vector<>();
					for(String[] regs : actions.get(row).metodo())
					{
						registro.addElement(new Object[] 
						{
								Recursos.getImage("/Recursos/Avatar/", regs[0]),
								regs[1],regs[2]
						});
					}
					
					FrameGame.getInstance().continueGame(new File(Recursos.pathFilesGame+"Gato.game"), 
							registro,modelo.getValueAt(row,1).toString(),
							modelo.getValueAt(row, 0).toString(),
							WindowParticipantes.enJuego);
				}
			}
			
			@Override
			public void mouseEntered(MouseEvent e) 
			{
				setCursor(Recursos.handCursor);
			}
		});
		
		setModel(modelo);
		getColumnModel().getColumn(3).setPreferredWidth(150);
	}
	
	public void agregar(Vector<Object> v,MetodoGet<Vector<String[]>> action)
	{
		JButton btn = new JButton(Recursos.renaudarIc); 
		btn.setBackground(Color.white);
		v.addElement(btn);
		actions.add(action);
		modelo.addRow(v);
	}
	
	public JScrollPane getScroll()
	{
		return sc;
	}
}

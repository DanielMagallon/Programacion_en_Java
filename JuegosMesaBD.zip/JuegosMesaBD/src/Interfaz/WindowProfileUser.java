package Interfaz;


import static Interfaz.LabelGames.areaImagen;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.Vector;

import javax.swing.JDialog;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JSplitPane;

import Games.General.Variables;
import Perfomance.TreeButtonRound;
import Perfomance.Painted;
import Perfomance.Script;
import Perfomance.TreeQuery;

import static Perfomance.Recursos.handCursor;

@SuppressWarnings("serial")
public class WindowProfileUser extends JDialog implements Painted
{
	private Image img;
	private PanelFunction panelFunc;
	
	private static Font font;
	
	private String[] gamesPlayed;
	
	private String marcador,user;
	private int btnClicked;
	
	private PaintScroll paintScroll;
	private TableHistorial tb;
	
	private Color colorPadre = Color.decode("#EBD3E4");
	private Color colorJuegos = Color.decode("#B25899");
	private Color colorPartidasHijas = Color.decode("#E89995");
	
	TreeButtonRound btnPadre = new TreeButtonRound(10);
	private boolean drawInfo;
	private UserIcon userIconRef;
	private WindowUpdateInfo wui;
	
	public WindowProfileUser() 
	{
		setModal(true);
		setResizable(false);
		setSize(Toolkit.getDefaultToolkit().getScreenSize());
		setLocationRelativeTo(null);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		
		wui = new WindowUpdateInfo();
		
		getContentPane().setBackground(Color.white);
		setLayout(new BorderLayout());

		
		font = new Font("Arial", Font.BOLD, 40);
		tb = new TableHistorial();
		paintScroll = new PaintScroll(this);
		
		addWindowListener(new WindowAdapter() 
		{
			@Override
			public void windowClosing(WindowEvent e) 
			{
				WindowProfileUser.this.dispose();
				WindowIconUsers.habilitar();
			}
			
		});

		panelFunc = new PanelFunction();
		
		ClickInfo c = new ClickInfo();
		JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
		paintScroll.addMouseListener(c);
		paintScroll.addMouseMotionListener(c);
		
		split.setLeftComponent(paintScroll.getScroll());
		split.setRightComponent(tb);
		split.setDividerLocation(800);
		
		add(split,"Center");
		add(panelFunc,"North");
		
		btnPadre.addAction(()->
		{
			String cad="";
			
			for(String g : gamesPlayed)
			{
				cad+=g+"-";
			}
			
			tb.actualizar(new String[] 
			{
				cad,TreeQuery.getTotalPartidasState(marcador, user),
				TreeQuery.getTotalPartidasJugadas(marcador, user)
					
			}, "Juegos jugados","Total de partidas","Total de partidas jugadas en general");
		});
		
	}
	

	public void mostrar(Image im,String user, String[] games, UserIcon ic, String name)
	{
		img = im;   
		userIconRef = ic;
		this.user = user;
		gamesPlayed = games;
		setTitle("Nombre del usuario: "+name);
		TreeButtonRound.size=0;
		TreeButtonRound.widthTotal = 0;
		
		tb.delete();
		btnPadre.vaciar();
		btnPadre.padreNull();
		
		
		drawInfo =  false;
		
		for(String g : games)
		{
			TreeButtonRound b = new TreeButtonRound(g, 30, 100,50,font, Color.WHITE, colorJuegos);
			b.ID = 1;
			b.name = g;
			b.addAction(()->
			{
				tb.actualizar(new String[]{TreeQuery.getTotalPartidasGameState(user, marcador, g)}, 
					String.format("Total partidas en el juego: %s",g));
				
			});
			btnPadre.addChild(b);
		}
	
		paintScroll.preferedSize(TreeButtonRound.size, TreeButtonRound.widthTotal);
		
		setVisible(true);
		
	}
	
	
	@Override
	public void paintGraphics(Graphics g) 
	{
		TreeButtonRound.posYPuntero=0;

		if(drawInfo)
		{
			btnPadre.drawTextInRound("Juegos", 100, 50, 50, font, Color.black, colorPadre, g);
			btnPadre.drawAll(g);
		}
	}
	
	private void consulta()
	{

		btnPadre.vaciar();
		TreeButtonRound.size=0;
		TreeButtonRound.widthTotal = 0;
		
		
		while(btnPadre.hasNext())
		{
			TreeButtonRound btnPartida = new TreeButtonRound("Partidas",30,100,50, font, Color.WHITE, 
					Color.decode("#6D586E"));
			btnPartida.addAction(()-> 
			{
				tb.actualizar(TreeQuery.partidasPlayedStateName(user, marcador, btnPartida.padre.name),
				String.format("Partidas jugadas en el juego: %s",btnPartida.padre.name),
				"Duracion partida");
			});
			try 
			{
				addPartidaIn(btnPadre.getTitle(),btnPartida);
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			btnPadre.next().addChild(btnPartida);
		}
		paintScroll.preferedSize(TreeButtonRound.size, TreeButtonRound.widthTotal);
		
		tb.delete();
		
		drawInfo = true;
		repaint();
	}
	
	
	private void addPartidaIn(String juego, TreeButtonRound btn)
	{
		String con = String.format
				("select p.Nombre_partida,p.Id_partida from partidas p inner join " +
				"juegosmesa jg on p.Id_juego = jg.Id_juego inner join"+
				 " partidas_has_jugadores phj on p.Id_partida = phj.Id_partida " + 
				 "inner join jugadores j on phj.Id_jugador = j.Id_jugador " + 
				 "where j.Nombre_usuario='%s' && jg.Nombre_juego='%s' "
				 + "&& phj.Esado_part='%s';", user,juego,marcador);
		
		Vector<String[]> vec = Script.getInstance().consultaGet(con);
		
		btn.name = juego;
		
		for(String[] d : vec )
		{
			TreeButtonRound v = new TreeButtonRound(d[0], 30, 100,50,font, Color.WHITE, colorPartidasHijas);
			v.ID = 3;
			v.name = d[1];
			v.addAction(()-> 
			{		
					tb.actualizar(TreeQuery.getResultPlayers(d[1]), 
							"Jugadores de la partida","Resultado");
				});
			
			btn.addChild(v);
		}
		
	}
	
	class ClickInfo extends MouseAdapter
	{
		boolean on;
		
		@Override
		public void mouseMoved(MouseEvent e) 
		{
			if(btnPadre.isOnNode(e.getX(), e.getY(),false,null,btnPadre))
			{
				if(!on)
				{
					on = true;
					setCursor(handCursor);
				}
			}
			else 
			{
				if(on)
				{
					setCursor(null);
					on = false;
				}
			}
		}
		
		@Override
		public void mouseClicked(MouseEvent e) 
		{
			btnPadre.aux.responder();
		}
	}
	
	class PanelFunction extends JPanel
	{
		String funciones[] = {"VICTORIAS","DERROTAS","EMPATES","SUSPENSIONES"};
		Color backgroundsTexts[] = {Color.decode("#93B8E6"),Color.decode("#ABC3E0"),
								Color.decode("#54606E"),Color.decode("#8DA2BA")};
		TreeButtonRound txtButton[];
		private int i,y=50;
		private boolean onFuncion;
		private JPopupMenu menuDesp;
		
		public PanelFunction() 
		{
			setPreferredSize(new Dimension(750, 300));
			setBorder(Variables.bordeNegro);
			setBackground(Color.decode("#30E6E3"));
			setLayout(new BorderLayout());
			
			menuDesp = new JPopupMenu();
			
			areaImagen.setColorContorno(Color.black);
			areaImagen.setColorHueco(Color.white);
			
			txtButton = new TreeButtonRound[funciones.length];
			
			
			for(; i<txtButton.length; i++)
			{
				txtButton[i] = new TreeButtonRound(i);
			}
			
			MouseAdapter ma = new MouseAdapter() 
			{
				@Override
				public void mouseClicked(MouseEvent e) 
				{
					switch(btnClicked)
					{
						case 0:
							marcador = "victoria";
							tb.setTitle("ganadas");
							break;
							
						case 1:
							marcador = "derrota";
							tb.setTitle("perdidas");
							break;
							
						case 2:
							marcador = "empate";
							tb.setTitle("empatadas");
							break;
							
						case 3:
							marcador = "Suspendida";
							tb.setTitle("suspendidas");
							break;
							
						case 4:
							menuDesp.show(PanelFunction.super.getParent(), e.getX(), e.getY());
						default:
							return;
					}
					consulta();
					
				}
				
				@Override
				public void mouseMoved(MouseEvent e) 
				{
					int x = e.getX();
					int y = e.getY();
					
							
					for(TreeButtonRound b : txtButton)
					{
						if(b.isOnText(x, y))
						{
							if(!onFuncion)
							{
								btnClicked = b.ID;
								setCursor(handCursor);
							}
							onFuncion=true;
							break;
						}
						else 
						{
							if(onFuncion)
							{
								setCursor(null);
							}
							onFuncion = false;
						}
					}
					
					
					if(!onFuncion)
					{
						if(areaImagen.isOnImageContour(x, y))
						{
							btnClicked = 4;
							setCursor(handCursor);
							onFuncion = true;
						}
						else 
						{
							btnClicked = 5;
							setCursor(null);
							onFuncion = false;
						}
					}
				}
			};
			
			buildMenu();
			addMouseListener(ma);
			addMouseMotionListener(ma);
		}

		private void buildMenu()
		{
			JMenuItem mit = new JMenuItem("Cambiar foto");
			JMenuItem mit2 = new JMenuItem("Actualizar datos");
			
			menuDesp.add(mit);
			mit.addActionListener((a)->
			{
				PanelTablas.ventanaAvat.setUser(user).mostrar(true);
						
				if(PanelTablas.ventanaAvat.picureUser!=null)
				{
					img = PanelTablas.ventanaAvat.picureUser;
					userIconRef.img = img;
					repaint();
				}
			});
			
			menuDesp.add(mit2);
			
			mit2.addActionListener((a)->
			{
				wui.mostrar(Script.getInstance().consultaGet(String.format
						("select Id_jugador,Nombre_jugador, Nombre_usuario,"
						+"Pasw_jugador from jugadores where Nombre_usuario='%s';", 
						user)));
				
				if(wui.user!=null)
				{
					user = wui.user;
					userIconRef.user = user;
				}
			});
		}
		
		@Override
		protected void paintComponent(Graphics g)
		{
			super.paintComponent(g);
			
			areaImagen.drawContour(30,y, 200, 200, 10, 10, g);
			
			if(img!=null)
				areaImagen.drawInternalImageContour(img, g);
			
			for(i=0; i<txtButton.length; i++)
			{
				txtButton[i].drawTextInRound(funciones[i], 350, 
						y-10, 30, font, Color.white, backgroundsTexts[i], g);
				
				y=txtButton[i].getY1()+20;
			}
			
			y=50;
		}
	}
	
}

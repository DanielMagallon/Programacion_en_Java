package Manejador;

import java.awt.Desktop;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;

public class OpenExternalPath 
{
	public void mousePressed(MouseEvent e) {
		
		try
		{
			Desktop.getDesktop().open(new File("/SerFiles/"));
		} catch (IOException ex)
		{
			// TODO Auto-generated catch block
			ex.printStackTrace();
		}
	};
}

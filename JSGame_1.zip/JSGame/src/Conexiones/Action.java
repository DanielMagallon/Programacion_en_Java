package Conexiones;

public interface Action {
	void action(int key,Object code);
}

package Conexiones.net;

import javax.swing.JFrame;

public interface WaiteConnection 
{
	public abstract void waitClient(Server ss, JFrame f); 
	
}

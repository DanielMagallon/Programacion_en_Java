package Games;

import java.io.Serializable;

public class NodePosition<T> implements Serializable
{
	private static final long serialVersionUID = -7967735188632003672L;
	
	public NodePosition<T> next,before;
	public T posFrom,posTo;
	
	public NodePosition(T from,T to) 
	{
		posFrom = from;
		posTo = to;
	}
	
	@Override
	public String toString() 
	{
		return String.format("From %s to %s\n", posFrom,posTo);
	}
}

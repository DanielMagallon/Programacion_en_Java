package Games;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Games.Abstract.TableroViewer;
import Games.Ajedrez.Diseno.PanelAjedrez;
import Games.Ajedrez.Perfomance.GuardaJugadas;
import Manejador.Serializa;

import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

import java.awt.event.ActionListener;
import java.io.File;
import java.awt.event.ActionEvent;
import java.awt.Color;

@SuppressWarnings("serial")
public class Principal extends JFrame 
{

	private JPanel contentPane;

	private PanelAjedrez panelAjedrez;
	
	public static void main(String[] arg) {
		
//		String arg[] = new String[] {"/home/yeo/Escritorio/jugadas2.jcvg"};
		EventQueue.invokeLater(new Runnable() 
		{
			public void run() {
				try {
					
					if(arg.length==0)
					{
						Principal frame = new Principal();
						frame.setVisible(true);
//
					}
					if(arg.length==1)
					{
						
						if(arg[0].endsWith(".jcvg"))
						{
							GuardaJugadas jugadas = (GuardaJugadas) Serializa.writeObject
									(new File(arg[0]));
							new Principal(jugadas);
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	
	public static Principal instance;
	
	public Principal() 
	{
		setBackground(Color.DARK_GRAY);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setBackground(Color.WHITE);
		setJMenuBar(menuBar);
		
		JMenu mnJuegos = new JMenu("Juegos");
		menuBar.add(mnJuegos);
		
		JMenuItem mntmAjedrez = new JMenuItem("Ajedrez");
		mntmAjedrez.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent arg0) 
			{
				if(panelAjedrez == null)
				{
					panelAjedrez = new PanelAjedrez();
				}
				
				getContentPane().add(panelAjedrez);
				validate();
				
			}
		});
		mnJuegos.add(mntmAjedrez);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		//setSize(Toolkit.getDefaultToolkit().getScreenSize());
		setSize(700,700);
		if(panelAjedrez == null)
		{
			panelAjedrez = new PanelAjedrez();
		}
		
		getContentPane().add(panelAjedrez);
		
		instance = this;
	}	

	public Principal(GuardaJugadas jugadas)
	{
		new TableroViewer(jugadas, true);
	}
}

package Games;

import java.io.Serializable;

import static java.lang.System.out;

public class ListPositions<T> implements Serializable
{
	private static final long serialVersionUID = -1436242681795690724L;
	
	private NodePosition<T> inicio,fin,aux;
	
	
	public void insertPositions(T posI,T posF)
	{
		if(inicio==null)
			aux = inicio = fin = new NodePosition<T>(posI, posF);
		else {
			NodePosition<T> aux;
			aux = fin;
			fin.next = new NodePosition<T>(posI, posF);
			fin = fin.next;
			fin.before = aux; 
		}
	}
	
	public boolean hasNext()
	{
		if(aux==null)
		{
			aux = inicio;
			return false;
		}
		
		return true;
	}
	
	private NodePosition<T> puntero;
	
	public NodePosition<T> before() throws NullPointerException
	{
		if(puntero.before!=null)
		{
			aux = puntero;
			puntero = puntero.before;
		}		
		
		else throw new NullPointerException("Ya no hay mas elementos hacia atras");
		
		return puntero;
	}
	
	public NodePosition<T> next() throws NullPointerException
	{
		if(aux!=null)
		{
			puntero = aux;
			aux = aux.next;
		}
		
		else throw new NullPointerException("Ya no hay mas elementos hacia adelante");
		
		return puntero;
	}
	
	
	public void showPositions()
	{
		while(hasNext())
		{
			out.print(next());
		}
	}
}

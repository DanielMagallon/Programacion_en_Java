package Games.Ajedrez.Perfomance;

import static Games.Ajedrez.Diseno.PanelAjedrez.tableroAjedrez;
import static Games.Ajedrez.Perfomance.VarsChess.JUGADOR_BLANCAS;
import static Games.Ajedrez.Perfomance.VarsChess.piezaEnJuego;
import static Games.Ajedrez.Perfomance.VarsChess.rey;
import static Games.Ajedrez.Perfomance.VarsChess.peon;
import static Games.Ajedrez.Perfomance.VarsChess.torre;
import static Games.Ajedrez.Perfomance.VarsChess.turno;

import javax.swing.JOptionPane;

public class Propiedades 
{
	private static byte fromF,fromC,toF,toC;
	
	public static void copyPropierties(byte fromF,byte fromC,byte toF,byte toC)
	{
		Propiedades.fromF = fromF;
		Propiedades.fromC = fromC;
		Propiedades.toF = toF;
		Propiedades.toC = toC;
		
		tableroAjedrez.getEstadoActual().actualizarTablero(fromF, fromC,turno);
		tableroAjedrez.getEstadoActual().actualizarTablero(toF, toC, piezaEnJuego, turno);
		
		tableroAjedrez.getEstadoActual().deleteAction = true;
		
		//Cuando se hace el enroque agregar a las jugadas dicho mov
		if(piezaEnJuego == torre)
		{
			actualizaEnroque();
		}
		
		else if(piezaEnJuego == rey)
		{
			actualizarRey();
		}
		
		else if(piezaEnJuego == peon)
				actualizarPeon();
		
		tableroAjedrez.getEstadoActual().determinarTablas();
		
		if(tableroAjedrez.getEstadoActual().deleteAction)
			tableroAjedrez.getEstadoActual().setCaptura(null);
	}
	
	private static void actualizaEnroque()
	{
		if(turno == JUGADOR_BLANCAS)
		{
			if(tableroAjedrez.getEstadoActual().enroqueB)
			{
				if(fromF==tableroAjedrez.filas-1 && fromC==0)
					if(tableroAjedrez.getEstadoActual().get(tableroAjedrez.filas-1, 2).especialAct!=null)
					{
						tableroAjedrez.getEstadoActual().deleteActionOf(tableroAjedrez.filas-1, 2);
						JOptionPane.showMessageDialog(null, "Ya no habra enroque largo blancas");
					}
					else;
				
				else if(fromF==tableroAjedrez.filas-1 && fromC==7)
					if(tableroAjedrez.getEstadoActual().get(tableroAjedrez.filas-1, 6).especialAct!=null)
					{
						tableroAjedrez.getEstadoActual().deleteActionOf(tableroAjedrez.filas-1, 6);
						JOptionPane.showMessageDialog(null, "Ya no habra enroque corto blancas");
					}
			}
		}
		else
		{
			if(tableroAjedrez.getEstadoActual().enroqueN)
			{
				if(fromF==0 && fromC==0)
					if(tableroAjedrez.getEstadoActual().get(0, 2).especialAct!=null)
					{
						tableroAjedrez.getEstadoActual().deleteActionOf(0, 2);
						JOptionPane.showMessageDialog(null, "Ya no habra enroque largo negras");
					}
					else;
				
				else if(fromF==0 && fromC==7)
					if(tableroAjedrez.getEstadoActual().get(0, 6).especialAct!=null)
					{
						tableroAjedrez.getEstadoActual().deleteActionOf(0, 6);
						JOptionPane.showMessageDialog(null, "Ya no habra enroque corto negras");
					}
			}
		}
	}
	
	/*
	 * Los valores que tooman toF+1,toC son los ultimos que se han actualizado, por lo que la 
	 * casiilla a la que se puede menear al paso puede no  ser la correcta
	 * return new Position(toF+1, toC); Almaecanar estos parametros en otras variables
	 */
	private static void actualizarPeon()
	{
		if(turno==JUGADOR_BLANCAS) 
		{
			if(fromF == tableroAjedrez.filas-2 && toF == tableroAjedrez.filas-4)
			{
				if(tableroAjedrez.getEstadoActual().isValidPosition(toF, toC-1))
					if(tableroAjedrez.getEstadoActual().tablero[toF][toC-1].esPeonDe(-JUGADOR_BLANCAS))
					{
						tableroAjedrez.getEstadoActual().deleteAction=false;
						tableroAjedrez.getEstadoActual().peonIzq = tableroAjedrez.getEstadoActual().tablero[toF][toC-1];
						tableroAjedrez.getEstadoActual().setCaptura
						(tableroAjedrez.getEstadoActual().tablero[toF+1][toC]);
						
						tableroAjedrez.getEstadoActual().tablero[toF][toC-1].especialAct = ()->
						{
							//Este es la casilla a la que pasara una negra alcapurar aal paso
							return new Position(toF+1, toC);
						};
						
					}
					else;
				
				if(tableroAjedrez.getEstadoActual().isValidPosition(toF, toC+1))
					if(tableroAjedrez.getEstadoActual().tablero[toF][toC+1].esPeonDe(-JUGADOR_BLANCAS))
					{
						tableroAjedrez.getEstadoActual().deleteAction=false;
						tableroAjedrez.getEstadoActual().peonDer = tableroAjedrez.getEstadoActual().tablero[toF][toC+1];
						
						tableroAjedrez.getEstadoActual().setCaptura
						(tableroAjedrez.getEstadoActual().tablero[toF+1][toC]);
						
						tableroAjedrez.getEstadoActual().tablero[toF][toC+1].especialAct = ()->
						{
							return new Position(toF+1, toC);
						};
					}
			}
			else if(tableroAjedrez.getEstadoActual().tablero[toF][toC] == tableroAjedrez.getEstadoActual().peonPaso)
			{
				tableroAjedrez.getEstadoActual().deleteAction=true;
				
			}
		}
		else
		{
			if(fromF == 1 && toF == 3)
			{
				if(tableroAjedrez.getEstadoActual().isValidPosition(toF, toC-1))
					if(tableroAjedrez.getEstadoActual().tablero[toF][toC-1].esPeonDe(JUGADOR_BLANCAS))
					{
						tableroAjedrez.getEstadoActual().deleteAction=false;
						tableroAjedrez.getEstadoActual().peonIzq = tableroAjedrez.getEstadoActual().tablero[toF][toC-1];
						tableroAjedrez.getEstadoActual().setCaptura
						(tableroAjedrez.getEstadoActual().tablero[toF-1][toC]);
						
						tableroAjedrez.getEstadoActual().tablero[toF][toC-1].especialAct = ()->
						{
							return new Position(toF-1, toC);
						};
						
					}
					else;
				
				if(tableroAjedrez.getEstadoActual().isValidPosition(toF, toC+1))
					if(tableroAjedrez.getEstadoActual().tablero[toF][toC+1].esPeonDe(JUGADOR_BLANCAS))
					{
						tableroAjedrez.getEstadoActual().deleteAction=false;
						tableroAjedrez.getEstadoActual().peonIzq = tableroAjedrez.getEstadoActual().tablero[toF][toC+1];
						tableroAjedrez.getEstadoActual().setCaptura
						(tableroAjedrez.getEstadoActual().tablero[toF-1][toC]);
						
						tableroAjedrez.getEstadoActual().tablero[toF][toC+1].especialAct = ()->
						{
							
							return new Position(toF-1, toC);
						};
					}
			}
			else if(tableroAjedrez.getEstadoActual().tablero[toF][toC] == tableroAjedrez.getEstadoActual().peonPaso)
			{
				tableroAjedrez.getEstadoActual().deleteAction=true;
			}
		}
			
	}
	
	private static void actualizarRey()
	{

		if(turno == JUGADOR_BLANCAS)
		{
			if(tableroAjedrez.getEstadoActual().enroqueB)
			{
				tableroAjedrez.getEstadoActual().enroqueB = false;
			
				if(tableroAjedrez.getEstadoActual().get(toF, toC).especialAct!=null)
				{
					tableroAjedrez.getEstadoActual().get(toF, toC).especialAct.especial_action();
				}
				
				//Estos dos no son necesarios 
				tableroAjedrez.getEstadoActual().deleteActionOf(tableroAjedrez.filas-1, 2);
				tableroAjedrez.getEstadoActual().deleteActionOf(tableroAjedrez.filas-1, 6);
			}
			tableroAjedrez.getEstadoActual().positionRey1.setNewPosition(toF, toC);
		}
		else
		{
			if(tableroAjedrez.getEstadoActual().enroqueN)
			{
				tableroAjedrez.getEstadoActual().enroqueN = false;
				
				
				if(tableroAjedrez.getEstadoActual().get(toF, toC).especialAct!=null)
				{
					tableroAjedrez.getEstadoActual().get(toF, toC).especialAct.especial_action();
				}
				
				//No so necsarios
				tableroAjedrez.getEstadoActual().deleteActionOf(0, 2);
				tableroAjedrez.getEstadoActual().deleteActionOf(0, 6);
			}
			tableroAjedrez.getEstadoActual().positionRey2.setNewPosition(toF, toC);
		}
	}
}

package Games.Ajedrez.Perfomance;


import java.io.Serializable;

import Games.Abstract.Especial;

import static Games.Ajedrez.Perfomance.VarsChess.JUGADOR_BLANCAS;
import static Games.Ajedrez.Perfomance.VarsChess.JUGADOR_NEGRAS;
import static Games.Ajedrez.Perfomance.VarsChess.peon;
import static Games.Ajedrez.Perfomance.VarsChess.rey;
import static Games.Ajedrez.Perfomance.VarsChess.reina;
import static Games.Ajedrez.Perfomance.VarsChess.alfil;
import static Games.Ajedrez.Perfomance.VarsChess.torre;
import static Games.Ajedrez.Perfomance.VarsChess.caballo;

public class CasillaData  implements Serializable, Cloneable
{
	private static final long serialVersionUID = 8501626888631293952L;
	public byte id_color;
	public Especial especialAct;
	
	public String casillaName;
	public byte f,c;
	public byte valor;
	public Pieza pieza;
	
	public CasillaData(byte f , byte c,byte id)
	{
		this.f = f;
		this.c = c;
		casillaName = "--";
		valor = -1;
		id_color=id;
		
	}
	
	public void actualizar(byte val, Pieza piece)
	{
		this.valor=val;
		pieza=piece;
		
		if(valor == JUGADOR_BLANCAS)
			casillaName = piece.clave+"B";
		
		else if(valor == JUGADOR_NEGRAS)
			casillaName = piece.clave+"N";
		
		else casillaName="--";
	}
	
	
	public boolean estaVacia()
	{
		return valor == -1;
	}
	
	
	public boolean esBlancas()
	{
		
		return valor == JUGADOR_BLANCAS;
	}
	
	public boolean esNegras()
	{
		return valor == JUGADOR_NEGRAS;
	}
	
	public boolean esPiezaDe(Pieza p, int py)
	{
		return pieza == p && valor == py;
	}
	
	public boolean esReyDe(int player)
	{
		return pieza == rey && valor == player;
	}
	
	public boolean esDamaDe(int player)
	{
		return pieza == reina && valor == player;
	}
	
	public boolean esCaballoDe(int player)
	{
		return pieza == caballo && valor==player;
	}
	
	public boolean esAlfil()
	{
		return pieza == alfil;
	}
	
	public boolean esPeonDe(int player)
	{
		return pieza == peon && valor == player;
	}
	
	public boolean esTorre()
	{
		return pieza == torre;
	}
	
	@Override
	public Object clone() throws CloneNotSupportedException 
	{
		CasillaData clon;
		
		clon = (CasillaData) super.clone();
		
		return clon;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return String.format("%s: [%d]-[%d] = %s\n", pieza,f,c,(especialAct==null) ? "N" : "Y");
	}
}

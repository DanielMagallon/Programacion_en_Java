package Games.Ajedrez.Perfomance;

public class PC {

	public EstadoTablero estado;
	
	
}


package Games.Ajedrez.Perfomance;

import javax.swing.Icon;
import javax.swing.JOptionPane;

import static Games.Ajedrez.Perfomance.VarsChess.k;
import static Games.Ajedrez.Perfomance.VarsChess.l;
import static Games.Ajedrez.Perfomance.VarsChess.turno;
import static Games.Ajedrez.Diseno.PanelAjedrez.tableroAjedrez;


@SuppressWarnings("serial")
public class Peon extends Pieza 
{
	
	private byte inc,filaDoblePaso;
	
	public Peon(byte val) {
		// TODO Auto-generated constructor stub
		nombre="peon";
		clave="P";
		valor = val;
	}
	
	@Override
	public Icon getPieza(byte pl) 
	{
		if(pl==VarsChess.JUGADOR_BLANCAS)
			return VarsChess.PEON;
		
		else if(pl==VarsChess.JUGADOR_NEGRAS)
			return VarsChess.PEON2;
		
		return null;
	} 
	

	@Override
	public void buscaCaminos(byte f, byte c)
	{
		if(turno == VarsChess.JUGADOR_BLANCAS) 
		{
			inc = -1;
			filaDoblePaso = (byte) (tableroAjedrez.filas-4);
		}
		else 
		{			
			inc = 1;
			filaDoblePaso = 3;
		}
		
		if(tableroAjedrez.getEstadoActual().get(f+inc, c).estaVacia())
		{
			l = c;
			k = (byte) (f+inc);
			metodo.method();
			
			if(f == filaDoblePaso + (-2*inc))
				if(tableroAjedrez.getEstadoActual().get(filaDoblePaso, c).estaVacia())
				{
					k = filaDoblePaso;
					metodo.method();
				}
		}
		
		if(esEnemigo(f+inc, c+1))
		{
			k = (byte) (f+inc);
			l = (byte) (c+1);
			
			metodo.method();
		}
		
		if(esEnemigo(f+inc, c-1))
		{
			k = (byte) (f+inc);
			l = (byte) (c-1);
			
			metodo.method();
		}
		
		
		if(tableroAjedrez.getEstadoActual().tablero[f][c].especialAct!=null)
		{
			Position pos = (Position) tableroAjedrez.getEstadoActual().tablero[f][c].especialAct.especial_action();
			k = (byte) pos.fila;
			l = (byte) pos.columna;
			metodo.method();
					
		}
	}
}
package Games.Ajedrez.Perfomance;


import java.io.Serializable;
import java.util.ArrayList;

import javax.swing.JOptionPane;

import Games.Abstract.ParameterMethod;

import static Games.Ajedrez.Perfomance.VarsChess.JUGADOR_BLANCAS;
import static Games.Ajedrez.Perfomance.VarsChess.JUGADOR_NEGRAS;
import static Games.Ajedrez.Perfomance.VarsChess.alfil;
import static Games.Ajedrez.Perfomance.VarsChess.caballo;
import static Games.Ajedrez.Perfomance.VarsChess.torre;

import static Games.Abstract.Variables.iFor;
import static Games.Abstract.Variables.jFor;
import static Games.Abstract.Variables.assertIJFor;
import static Games.Abstract.Variables.reserIJ;


import static Games.Ajedrez.Diseno.PanelAjedrez.tableroAjedrez;
import static javax.swing.JOptionPane.*;


public class EstadoTablero implements Cloneable, Serializable
{

	private static final long serialVersionUID = -2256843622365396159L;

	public CasillaData tablero[][];
	
	public Position positionRey1,positionRey2;
	
	public ArrayList<CasillaData> piezasBlancas,piezasNegras;
	
	public CasillaData peonPaso,peonIzq,peonDer;
	
	public int modoJuego,varianteJuego,f,c;
	
	private transient boolean comio;
	public transient boolean reseteando;
	public boolean enroqueN=true,enroqueB=true,actionOnPanel,deleteAction;
	
	public EstadoTablero(int f,int c)
	{
		tablero = new CasillaData[f][c];
		actionOnPanel = true;
		this.f = f;
		this.c = c;
		assertIJFor();
		boolean x=true;
		for(; iFor<f; iFor++)
		{
			for(jFor=0;jFor<c; jFor++)
			{
				tablero[iFor][jFor] = new CasillaData(iFor, jFor,  (byte) (x ? 1 : 2));
				x=!x;
			}
			x=!x;
		}
		
		jugadasEspeciales();
		positionRey1 = new Position();
		positionRey2 = new Position();
		piezasBlancas = new ArrayList<CasillaData>(16);
		piezasNegras = new ArrayList<CasillaData>(16);
		
		reserIJ();
	}
	
	@SuppressWarnings("unchecked")
	private EstadoTablero(CasillaData tablero[][],Position posR1,Position posR2, ArrayList<CasillaData> piezaN,
			ArrayList<CasillaData> piezaB,boolean enroqueBla,boolean enroqueNeg,int fi,int col) 
	{
		this.tablero = new CasillaData[tablero.length][tablero[0].length];
		f = fi;
		c = col;
		actionOnPanel = false;
		
		for(int i=0; i<tablero.length; i++)
		{
			for(int j=0; j<tablero[0].length; j++)
			{
				try {
					this.tablero[i][j] = (CasillaData) tablero[i][j].clone();
				} catch (CloneNotSupportedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		this.positionRey1=posR1.clone();
		this.positionRey2=posR2.clone();
		piezasNegras = (ArrayList<CasillaData>) piezaN.clone();
		piezasBlancas=(ArrayList<CasillaData>) piezaB.clone();
		enroqueB = enroqueBla;
		enroqueN = enroqueNeg;
	}
	
	public void setCaptura(CasillaData cas)
	{
		if(cas==null)
		{
			peonPaso = null;
			
			if(peonIzq!=null)
			{
				peonIzq.especialAct = null;
				peonIzq = null;
			}
			
			if(peonDer!=null)
			{
				peonDer.especialAct = null;
				peonDer = null;
			}
		}
		
		else if(peonPaso == null)
			peonPaso = cas;
	}
	
	public EstadoTablero copy()
	{
		EstadoTablero estado = new EstadoTablero(tablero, positionRey1, positionRey2, piezasNegras, piezasBlancas,
						enroqueB,enroqueN,f,c);
		
		return estado;
	}

	private void jugadasEspeciales()
	{
		tablero[0][2].especialAct = ()->
		{

			this.actualizarTablero(0, 0, JUGADOR_NEGRAS);
			this.actualizarTablero(0, 3, torre, JUGADOR_NEGRAS);
			
			
			tableroAjedrez.jugadas.addJugada(new Position(0, 0), new Position(0, 3));
			if(actionOnPanel)
			{
				tableroAjedrez.casillasAj[0][0].setIcon(null);
				tableroAjedrez.casillasAj[0][3].putPiece(torre, JUGADOR_NEGRAS);
			}
			return null;
		};
		tablero[0][6].especialAct = ()->
		{
			this.actualizarTablero(0, 7, JUGADOR_NEGRAS);
			this.actualizarTablero(0, 5, torre, JUGADOR_NEGRAS);
			
			tableroAjedrez.jugadas.addJugada(new Position(0, 7), new Position(0, 5));
			
			if(actionOnPanel)
			{
				tableroAjedrez.casillasAj[0][7].setIcon(null);
				tableroAjedrez.casillasAj[0][5].putPiece(torre, JUGADOR_NEGRAS);
			}
			return null;
		};
		tablero[f-1][2].especialAct = ()->
		{
			this.actualizarTablero(f-1, 0, JUGADOR_BLANCAS);
			this.actualizarTablero(f-1, 3, torre, JUGADOR_BLANCAS);
			
			tableroAjedrez.jugadas.addJugada(new Position(f-1, 0), new Position(f-1, 3));
			
			if(actionOnPanel)
			{
				tableroAjedrez.casillasAj[f-1][0].setIcon(null);
				tableroAjedrez.casillasAj[f-1][3].putPiece(torre, JUGADOR_BLANCAS);
			}
			return null;
		};
		tablero[f-1][6].especialAct = ()->
		{
			this.actualizarTablero(f-1, 7, JUGADOR_BLANCAS);
			this.actualizarTablero(f-1, 5, torre, JUGADOR_BLANCAS);
			
			tableroAjedrez.jugadas.addJugada(new Position(f-1, 7), new Position(f-1, 5));
			
			if(actionOnPanel)
			{
				tableroAjedrez.casillasAj[f-1][7].setIcon(null);
				tableroAjedrez.casillasAj[f-1][5].putPiece(torre, JUGADOR_BLANCAS);
			}
			return null;
		};
		
	}
	
	public void actualizarTablero(int f, int c,Pieza pieza,byte val)
	{
		comio=false;
		if(val == JUGADOR_BLANCAS)
		{
			piezasBlancas.add(tablero[f][c]);
			
			//Indica que las blancas se comieron una pieza
			if(tablero[f][c].pieza != null && !reseteando)
			{
				piezasNegras.remove(tablero[f][c]);
				comio=true;
			}
		}
		else {
			piezasNegras.add(tablero[f][c]);
			
			if(tablero[f][c].pieza != null && !reseteando)
			{
				piezasBlancas.remove(tablero[f][c]);
				comio=true;
				
			}
		}
		
		tablero[f][c].actualizar(val, pieza);
		
		if(comio)
		{
			if(piezasBlancas.size()+piezasNegras.size()<=4)
			{
				if(piezasSobrantes(piezasNegras, piezasBlancas) || piezasSobrantes(piezasBlancas, piezasNegras))
					JOptionPane.showMessageDialog(null, "Juego terminado/Tablas");
			}
		}
	}
	

	public void actualizarTablero(int f, int c, int val)
	{
		tablero[f][c].actualizar((byte) -1, null);
		
		if(val == JUGADOR_BLANCAS)
			piezasBlancas.remove(tablero[f][c]);
		
		else if(val == -JUGADOR_BLANCAS)
			piezasNegras.remove(tablero[f][c]);
	}
	
	public boolean isValidPosition(int f, int c)
	{
		return f>=0 && f<tablero.length && c>=0 && c<tablero[0].length;
	}
	
	public CasillaData get(int f, int c)
	{
		return tablero[f][c];
	}
	
	public void reset()
	{
		piezasBlancas.clear();
		piezasNegras.clear();
		enroqueB = enroqueN = true;
		jugadasEspeciales();
	}
	
	public void deleteActionOf(int f, int c)
	{
		tablero[f][c].especialAct=null;
	}
	
	public void mostrar(ParameterMethod metodo)
	{
		for(CasillaData x[] : tablero)
		{
			for(int i=0; i<x.length; i++)
			{
				if(i==x.length-1)
					metodo.get("\""+x[i].casillaName+"\"\n");
				
				else metodo.get("\""+x[i].casillaName+"\" ");
				
			}
			
		}
		metodo.get("\nPB: "+piezasBlancas.size());
		metodo.get("\nPN: "+piezasNegras.size());
		metodo.get("\nPosR1: "+positionRey1);
		metodo.get("\nPosR2: "+positionRey2);
		metodo.get("\nEnroqueB: "+enroqueB);
		metodo.get("\nEnroqueN: "+enroqueN);
		metodo.get("\nFilas: "+f);
	}
	
	public void determinarTablas()
	{
		
		//piezasSobrantes();
	}
	
	
	private boolean piezasSobrantes(ArrayList<CasillaData> lista,ArrayList<CasillaData> lista2)
	{
		if(lista.size()==1 && lista2.size()==1)
		{
			return true;
		}
		
		if(lista.size()==2 && lista2.size()==1)
		{
			 return contienePieza(alfil, lista,1) || contienePieza(caballo, lista,1);
		}
		
		if(lista.size()==2 && lista2.size()==2)
		{
			return (contienePieza(alfil, lista,1) && contienePieza(alfil, lista2,1)) ||
					(contienePieza(caballo, lista,1) && contienePieza(caballo, lista2,1));
		}
		
		if(lista.size()==3 && lista2.size()==1)
		{
			return contienePieza(caballo, lista,2);
		}
		
		return false;
	}
	
	private boolean contienePieza(Pieza piece,ArrayList<CasillaData> list, int veces)
	{
		int cont=0;
		
		for(CasillaData c : list)
			if(c.pieza == piece)
				cont++;
				
		return cont==veces;
	}
}

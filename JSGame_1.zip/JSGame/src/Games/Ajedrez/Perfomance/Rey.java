package Games.Ajedrez.Perfomance;

import static Games.Abstract.Variables.iFor;
import static Games.Abstract.Variables.reserIJ;
import static Games.Abstract.Variables.assertIJFor;

import static Games.Ajedrez.Perfomance.VarsChess.movsLibre;
import static Games.Ajedrez.Perfomance.VarsChess.k;
import static Games.Ajedrez.Perfomance.VarsChess.l;
import static Games.Ajedrez.Perfomance.VarsChess.turno;

import static Games.Ajedrez.Diseno.PanelAjedrez.tableroAjedrez;

import static Games.Ajedrez.Perfomance.Amenazas.breakOnFoundDanger;
import static Games.Ajedrez.Perfomance.Amenazas.setActualPosition;
import static Games.Ajedrez.Perfomance.Amenazas.buscaPiezas;

import javax.swing.Icon;
import javax.swing.JOptionPane;


@SuppressWarnings("serial")
public class Rey extends Pieza
{
	private byte ff,cf;
	
	public Rey(byte val)
	{
		nombre="Rey";
		clave="R";
		valor = val;
	}

	
	@Override
	public Icon getPieza(byte pla) 
	{
		
		if(pla==VarsChess.JUGADOR_BLANCAS)
			return VarsChess.REY1;
		
		else if(pla==VarsChess.JUGADOR_NEGRAS)
			return VarsChess.REY2;
		
		return null;
	}

	@Override
	public void buscaCaminos(byte f, byte c)
	{
		assertIJFor();
		
		breakOnFoundDanger();
		setActualPosition(f, c);
		
		for(iFor = 0; iFor<movsLibre.length; iFor++)
		{
			try
			{
				k = (byte) (f+movsLibre[iFor][0]);
				l = (byte) (c+movsLibre[iFor][1]);
				
				if((esEnemigo(k, l) || tableroAjedrez.getEstadoActual().get(k,l).estaVacia()))
				{
					if(!buscaPiezas(k, l, turno, true,true))
					{
						metodo.method();
					}
				}
				
			}
			catch(ArrayIndexOutOfBoundsException ex) {
			}
		}
		
		ff = f;
		cf = c;
		enroque();
		reserIJ();
	}
	
	private void enroque()
	{
		if(turno == VarsChess.JUGADOR_BLANCAS)
		{
			if(tableroAjedrez.getEstadoActual().enroqueB)
			{
				//Eveluar si estaa en jaque o si hay peligro:
				if(tableroAjedrez.getEstadoActual().get(tableroAjedrez.filas-1, 2)!=null)
				{
					enroqueLargo();
				}
				
				if(tableroAjedrez.getEstadoActual().get(tableroAjedrez.filas-1, 5)!=null)
				{
					enroqueCorto();
				}
			}
		}
		else
		{
			if(tableroAjedrez.getEstadoActual().enroqueN)
			{
				//Eveluar si estaa en jaque o si hay peligro:
				if(tableroAjedrez.getEstadoActual().get(0, 2)!=null)
				{
					enroqueLargo();
				}
				
				if(tableroAjedrez.getEstadoActual().get(0, 5)!=null)
				{
					enroqueCorto();
				}
			}
		}
	}
	
	private void enroqueLargo()
	{
		byte v;
		
		for(v = (byte) (cf-1); v>=1; v--)
		{
			if(!tableroAjedrez.getEstadoActual().get(ff, v).estaVacia() || buscaPiezas(ff, v, turno, true,true)) 
				return;
		}
		
		k = ff;
		l = (byte) (v+2);
		
		metodo.method();
		tableroAjedrez.getEstadoActual().get(k, l);
	}
	
	private void enroqueCorto()
	{
		byte v;
		
		for(v = (byte) (cf+1); v<tableroAjedrez.columnas-1; v++)
		{
			if(!tableroAjedrez.getEstadoActual().get(ff, v).estaVacia() || buscaPiezas(ff, v, turno, true,true))
				return;
		}
		
		
		k = ff;
		l = (byte) (v-1);
		
		metodo.method();
	}
}

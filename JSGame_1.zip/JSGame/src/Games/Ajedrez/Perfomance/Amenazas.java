package Games.Ajedrez.Perfomance;

import Games.Abstract.BooleanMethod;
import Games.Abstract.Tablero;
import Games.Abstract.Variables;
import Games.Abstract.VoidMethod;

import static Games.Ajedrez.Perfomance.VarsChess.alfil;
import static Games.Ajedrez.Perfomance.VarsChess.torre;

import javax.swing.JOptionPane;

import static Games.Ajedrez.Perfomance.VarsChess.movsLibre;
import static Games.Ajedrez.Perfomance.VarsChess.movsCaballo;

import static Games.Ajedrez.Diseno.PanelAjedrez.tableroAjedrez;
import static Games.Ajedrez.Perfomance.VarsChess.JUGADOR_BLANCAS;
import static Games.Ajedrez.Perfomance.VarsChess.JUGADOR_NEGRAS;

public class Amenazas 
{
	private static BooleanMethod metodo;
	private static byte index,filaAct,colAct,incF;

	public static void breakOnFoundDanger()
	{
		metodo = () -> {
			return true;
		};
		
	}
	
	
	public static void setOnFoundDanger(VoidMethod vm)
	{
		metodo = () -> {
			vm.method();
			return false;
		};
	}
	
	public static void setActualPosition(byte f, byte c)
	{
		filaAct = f;
		colAct = c;
	}
	
	public static boolean buscaPiezas(byte f, byte c, int player, boolean breakAfound, boolean enemigas)
	{
		if(enemigas)
		{
			player=-player;
			incF = (byte) (player==JUGADOR_BLANCAS ? 1 : -1);
		}else incF = (byte) (player==JUGADOR_BLANCAS ? -1 : 1);
		
		//Esta condicion debe ir asi
		//Ya que si la hacems alreves evaluara primero el breakAFound y dado que esta
		//variable estara algunas veces en true pues no entrara al metodo del caballo
		//e inmediatamente retornara true;
		//Esta condicion no respeta la ley ..... ya que  (x && y) = (y && x) pero aqui no respeta eso. 
		if(amenazaCaballo(f, c, player) && breakAfound)
				return true;
		
		return amenazaOtra(f, c, player);
	}
	
	public static boolean amenazaOtra(byte f, byte c, int player)
	{
		Pieza aux = torre;
		int m,n;
		boolean enemigo=false;
		
		for(index=0; index<movsLibre.length; index++)
		{
			if(index==4)
				aux = alfil;
			
			if(tableroAjedrez.getEstadoActual().isValidPosition(f+incF, c+1))
			{
				if(tableroAjedrez.getEstadoActual().get(f+incF, c+1).esPeonDe(player))
				{
					enemigo=true;
					if(metodo.getBool())
					{
						return true;
					}
				}
			}
			
			if(tableroAjedrez.getEstadoActual().isValidPosition(f+incF, c-1))
			{
				if(tableroAjedrez.getEstadoActual().get(f+incF, c-1).esPeonDe(player))
				{
					enemigo=true;
					if(metodo.getBool())
					{
						return true;
					}
				}
			}
			
			m = f+movsLibre[index][0];
			n = c+movsLibre[index][1];
			
			if(!tableroAjedrez.getEstadoActual().isValidPosition(m, n))
				continue;
			
			if(tableroAjedrez.getEstadoActual().tablero[m][n].esReyDe(player))
			{
				if(!enemigo)
					enemigo=true;
				
				if(metodo.getBool())
				{
					return true;
				}
				
				continue;
			}
			
			
				while(true)
				{
					if(!tableroAjedrez.getEstadoActual().isValidPosition(m, n))
						break;
					
					if(tableroAjedrez.getEstadoActual().tablero[m][n].estaVacia() || (m==filaAct && n==colAct))
					{
						m += movsLibre[index][0];
						n += movsLibre[index][1];
						continue;
					}
					
					else if(tableroAjedrez.getEstadoActual().tablero[m][n].esDamaDe(player) ||
							tableroAjedrez.getEstadoActual().tablero[m][n].esPiezaDe(aux, player))
					{
						if(!enemigo)
							enemigo=true;
						
						if(metodo.getBool())
						{
							return true;
						}
					
						else break;
					}
					
					break;
				}
		}
		
		return enemigo;
	}
	
	public static boolean amenazaCaballo(byte f, byte c, int player)
	{
		int m,n;
		boolean enemigo=false;
		
		for(index=0; index<movsCaballo.length; index++)
		{
			m = f+movsCaballo[index][0];
			n = c+movsCaballo[index][1]; 
			
			if(!tableroAjedrez.getEstadoActual().isValidPosition(m, n))
				continue;
			
			if(tableroAjedrez.getEstadoActual().tablero[m][n].esCaballoDe(player))
			{
				if(!enemigo)
					enemigo=true;
				
				if(metodo.getBool())
					return true;
			}
		}
		return enemigo;
	}
}

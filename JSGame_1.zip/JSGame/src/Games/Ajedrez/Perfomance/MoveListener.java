package Games.Ajedrez.Perfomance;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JOptionPane;

import Conexiones.Constants;
import Games.Ajedrez.Diseno.CasillAjedrez;
import Manejador.Portapapeles;

import static Games.Ajedrez.Perfomance.VarsChess.continued;
import static Games.Ajedrez.Perfomance.VarsChess.piezaEnJuego;
import static Games.Ajedrez.Perfomance.VarsChess.turno;

import static Games.Ajedrez.Diseno.PanelAjedrez.tableroAjedrez;

public class MoveListener extends MouseAdapter implements Constants
{
	private CasillAjedrez casillaTocada,casillaMeneada;
	private byte filaT,columnaT,filaM,columnaM;
	private boolean haEscogido;
	
	
	
	@Override
	public void mouseClicked(MouseEvent e) 
	{
		
		if(!haEscogido)
		{
			
			casillaTocada = (CasillAjedrez) e.getComponent();
			escoge();
		}
		else
		{
			casillaMeneada =  (CasillAjedrez) e.getComponent();
			filaM = casillaMeneada.fila;
			columnaM = casillaMeneada.columna;
			
			menea();
		}
	}
	
	public void menea()
	{
//		if(casillaMeneada.isValid)
		{
			casillaMeneada.setIcon(casillaTocada.getIcon());
			casillaTocada.setIcon(null);

			tableroAjedrez.jugadas.addJugada(new Position(filaT,columnaT), new Position(filaM,columnaM));
			
			Propiedades.copyPropierties(filaT, columnaT, filaM, columnaM);
			
//			movEsepcial();
			
			if(!tableroAjedrez.modoConexion)
			{
				turno = (byte) -turno;
			}else {
					tableroAjedrez.tcp.write(FROM_TO,String.format("%d,%d,%d,%d", filaT,columnaT,filaM,columnaM));
					continued=false;
			}
			
			tableroAjedrez.getEstadoActual().mostrar((a)->{
				System.out.print(" "+a.toString()+" ");
			});
			
		}
		
		casillaTocada.defaultColor();
		tableroAjedrez.removeCasillas();
		haEscogido = false;
	}
	
	public void escoge()
	{
		if(casillaTocada.getIcon()!=null)
		{
			filaT = casillaTocada.fila;
			columnaT = casillaTocada.columna;
		
			if(validarTurno())
			{
				piezaEnJuego = tableroAjedrez.getEstadoActual().get(filaT, columnaT).pieza;
				casillaTocada.select();
				piezaEnJuego.buscaCaminos(filaT, columnaT);
				haEscogido = true;
			}
		}
	}
	
	public boolean validarTurno()
	{
		return continued && tableroAjedrez.getEstadoActual().get(filaT, columnaT).valor == turno;
	}
}

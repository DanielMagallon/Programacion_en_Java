package Games.Ajedrez.Diseno;

import java.awt.Color;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

import javax.swing.JOptionPane;

import Conexiones.Action;
import Conexiones.ConectionListener;
import Conexiones.Constants;
import Conexiones.net.ConexionLocal;
import Conexiones.net.TCP;
import Games.Principal;
import Games.Abstract.CasillaDataAbstract;
import Games.Abstract.Tablero;
import Games.Ajedrez.Perfomance.CasillaData;
import Games.Ajedrez.Perfomance.EstadoTablero;
import Games.Ajedrez.Perfomance.GuardaJugadas;
import Games.Ajedrez.Perfomance.MoveListener;
import Games.Ajedrez.Perfomance.PC;
import Games.Ajedrez.Perfomance.Pieza;
import Games.Ajedrez.Perfomance.Propiedades;
import Manejador.Serializa;

import static Games.Ajedrez.Perfomance.VarsChess.k;
import static Games.Ajedrez.Perfomance.VarsChess.l;
import static Games.Ajedrez.Perfomance.VarsChess.JUGADOR_BLANCAS;
import static Games.Ajedrez.Perfomance.VarsChess.JUGADOR_NEGRAS;
import static Games.Ajedrez.Perfomance.VarsChess.peon;
import static Games.Ajedrez.Perfomance.VarsChess.TRADICIONAL;
import static Games.Ajedrez.Perfomance.VarsChess.TRASCENDENTAL;
import static Games.Ajedrez.Perfomance.VarsChess.JUBILADO;
import static Games.Ajedrez.Perfomance.VarsChess.ALETORIO_FISCHER;
import static Games.Ajedrez.Perfomance.VarsChess.rey;
import static Games.Ajedrez.Perfomance.VarsChess.reina;
import static Games.Ajedrez.Perfomance.VarsChess.alfil;
import static Games.Ajedrez.Perfomance.VarsChess.torre;
import static Games.Ajedrez.Perfomance.VarsChess.caballo;
import static Games.Ajedrez.Perfomance.VarsChess.piezaEnJuego;

import static Games.Abstract.Variables.MODO_CLIENT;
import static Games.Abstract.Variables.MODO_SERVER;

import static Games.Abstract.Variables.convertArray;
import static Games.Abstract.Variables.iFor;
import static Games.Abstract.Variables.jFor;
import static Games.Abstract.Variables.assertIJFor;
import static Games.Abstract.Variables.reserIJ;
import static Games.Ajedrez.Perfomance.VarsChess.turno;
import static Games.Ajedrez.Perfomance.VarsChess.continued;
@SuppressWarnings("serial")
public class TableroAjedrez extends Tablero implements Action,ConectionListener,  Constants
{
		
		public CasillAjedrez casillasAj[][];
		private EstadoTablero estadoAux,estado;
		public GuardaJugadas jugadas;
		public PC pc;
		
		public ConexionLocal conexion;
		public TCP tcp;
		public byte movs[];
		public boolean modoConexion;
		
		public MoveListener listener;
		public Color selectColor,marckColor;
		public byte ID_GAME = 1;
		
		public ArrayList<CasillAjedrez> casillasValidas;
		
		public TableroAjedrez(byte filas, byte columnas,Color c1,Color c2) 
		{
			super(filas, columnas,c1,c2);
			
			estado = new EstadoTablero(filas,columnas);
//			estado.get(0, 4);
//			estado.get(filas-1, 4);
			selectColor = Color.green;
			marckColor = Color.yellow;
			pc = new PC();
			
		}

		@Override
		public void onConected() 
		{
			JOptionPane.showMessageDialog(null, "Se han conectado");
//			if(modo==CSERVER)
			{
//				if(varianteJuego == TRASCENDENTAL || varianteJuego == ALETORIO_FISCHER)
//				{
//					Codificador codif = new Codificador(estado.tablero);
//					tcp.write(CODIFICAR, codif);
//				}
//				
//				if(varianteJuego == TRADICIONAL || varianteJuego == JUBILADO)
//				{
//					tcp.write(varianteJuego, null);
//				}
			}
		}
		
		@Override
		public void onDesconected() 
		{
		
		}
		
		
		@Override
		public boolean connect() 
		{
			if(conexion==null)
			{
				//192.168.1.1
				//192.168.1.7
				//yeo-Lenovo-G50-30
				//127.0.1.1
				//localhost
				conexion = new ConexionLocal("localhost", 4444);
			}
			
			turno = (continued=estado.modoJuego==MODO_SERVER) ? JUGADOR_BLANCAS : JUGADOR_NEGRAS;

			tcp = conexion.get(estado.modoJuego==MODO_SERVER,this,this,Principal.instance,null);

			return tcp.connect(conexion.host,conexion.puerto);
		}
		
		@Override
		public void action(int key, Object code) 
		{
			continued=true;
			switch(key)
			{
				case FROM_TO:
					String mov = (String)code;
					
					movs = convertArray(mov.split(","));
					
					piezaEnJuego = estado.get(movs[0], movs[1]).pieza;
					
					casillasAj[movs[2]][movs[3]].setIcon(casillasAj[movs[0]][movs[1]].getIcon());
					casillasAj[movs[0]][movs[1]].setIcon(null);
					
					turno=(byte) -turno;
					Propiedades.copyPropierties(movs[0], movs[1], movs[2], movs[3]);
					turno=(byte) -turno;
//					movPeon=true;
					break;
					
//				case FROM:
//					mov = (String)code;
//					movPeon = false;
//					movs = convertArray(mov.split(","));
//					
//					estado.actualizarTablero(movs[0], movs[1],turno);
//					casillasAj[movs[0]][movs[1]].setIcon(null);
//					break;
					
//				case CODIFIC:
//					Codificador codificador = (Codificador) code;
//					descodificar(codificador.casillas);
//					break;
					
//				case TRADICIONAL:
//					ajedrezTradicional();
//					break;
//					
//				case JUBILADO:
//					ajedrezJubilado();
//					break;
			}
		}
		
		public EstadoTablero getEstadoActual()
		{
			return estadoAux;
		}
		
		public void setEstadoTo(boolean normal)
		{
				estadoAux = normal ? estado : pc.estado;
		}
		
		//Se debe actualizar tablero
		private void descodificar(CasillaData casillas[][])
		{
			estado.tablero = casillas;
			assertIJFor();
			
			for(; iFor<casillas.length; iFor++)
			{
				for(jFor=0; jFor<casillas[iFor].length; jFor++)
				{
					casillasAj[iFor][jFor].putPiece(casillas[iFor][jFor].pieza, casillas[iFor][jFor].valor);
				}
			}
			reserIJ();
		}
		
		private Pieza piezas [] = {torre,caballo, alfil, reina,rey,alfil,caballo,torre};
		
		private void ajedrezTradicional()
		{
			CasillaDataAbstract cda[][] = new CasillaDataAbstract[filas][columnas];
			
			if(modoConexion)
			{
					if(!connect())
						return;
					
				turno = (continued = estado.modoJuego==MODO_SERVER )? JUGADOR_BLANCAS : JUGADOR_NEGRAS;
			}else {
				turno = JUGADOR_BLANCAS;
				continued=true;
			}
//			
			Pieza piezas[] = {torre,caballo, alfil,reina,rey,alfil,caballo,torre};
			
			
			estado.reseteando=true;
			for (int j=0; j<piezas.length; j++)
			{
				
				casillasAj[0][j].putPiece(piezas[j],JUGADOR_NEGRAS);
				estado.actualizarTablero(0,j,piezas[j],JUGADOR_NEGRAS);
				cda[0][j] = new CasillaDataAbstract(JUGADOR_NEGRAS, piezas[j]);
				
				
				casillasAj[super.filas-1][j].putPiece(piezas[j],JUGADOR_BLANCAS);
				estado.actualizarTablero(super.filas-1,j,piezas[j],JUGADOR_BLANCAS);
				cda[super.filas-1][j] = new CasillaDataAbstract(JUGADOR_BLANCAS, piezas[j]);
				
				casillasAj[1][j].putPiece(peon, JUGADOR_NEGRAS);
				estado.actualizarTablero(1,j,peon,JUGADOR_NEGRAS);
				cda[1][j] = new CasillaDataAbstract(JUGADOR_NEGRAS, peon);
				
				casillasAj[super.filas-2][j].putPiece(peon,JUGADOR_BLANCAS);
				estado.actualizarTablero(super.filas-2,j,peon,JUGADOR_BLANCAS);
				cda[super.filas-2][j] = new CasillaDataAbstract(JUGADOR_BLANCAS, peon);
			}
			estado.reseteando=false;
			estado.positionRey1.setNewPosition(super.filas-1, 4);
			estado.positionRey2.setNewPosition(0, 4);
//			
			jugadas = new GuardaJugadas(cda, super.firstColor, super.secondColor);
			
		}
		
		private void ajedrezAletorioDe(boolean fischer)
		{
			reset();
			
			Collections.shuffle(Arrays.asList(this.piezas));
			int j;
			
			
			for (j=0; j<piezas.length; j++)
			{
				
				casillasAj[0][j].putPiece(piezas[j],JUGADOR_NEGRAS);
				estado.actualizarTablero(0,j,piezas[j],JUGADOR_NEGRAS);
				
				if(piezas[j]==rey)
					estado.positionRey2.setNewPosition(0, j);
				
				casillasAj[1][j].putPiece(peon, JUGADOR_NEGRAS);
				estado.actualizarTablero(1,j,peon,JUGADOR_NEGRAS);
				
				casillasAj[6][j].putPiece(peon,JUGADOR_BLANCAS);
				estado.actualizarTablero(6,j,peon,JUGADOR_BLANCAS);
			}
			
			if(!fischer)
				Collections.shuffle(Arrays.asList(this.piezas));
			
			for(j=0; j<piezas.length; j++)
			{
				casillasAj[7][j].putPiece(piezas[j],JUGADOR_BLANCAS);
				estado.actualizarTablero(7,j,piezas[j],JUGADOR_BLANCAS);
				
				if(piezas[j]==rey)
					estado.positionRey1.setNewPosition(7, j);
			}
			
			
		}
		
		private void ajedrezJubilado()
		{
//			if(listener.modoConexion = (modo == CSERVER || modo == CCLIENT))
//				if(modo!=CCLIENT)
//					if(!connect())
//						return;
//			
//			reset();
//			
//			for (int j=0; j<columnas; j++)
//			{
//				casillasAj[1][j].putPiece(peon, JUGADOR_NEGRAS);
//				estado.actualizarTablero(1,j,peon,JUGADOR_NEGRAS);
//				
//				casillasAj[6][j].putPiece(peon,JUGADOR_BLANCAS);
//				estado.actualizarTablero(6,j,peon,JUGADOR_BLANCAS);
//				
//				if(j==4)
//				{
//				casillasAj[0][4].putPiece(rey, JUGADOR_NEGRAS);
//				estado.actualizarTablero(0,4,rey,JUGADOR_NEGRAS);
//				
//				casillasAj[7][4].putPiece(rey,JUGADOR_BLANCAS);
//				estado.actualizarTablero(7,4,rey,JUGADOR_BLANCAS);
//				}
//				else
//				{
//					casillasAj[0][j].setIcon(null);
//					estado.actualizarTablero(0,j,JUGADOR_NEGRAS);
//					
//					casillasAj[7][j].setIcon(null);
//					estado.actualizarTablero(7,j,JUGADOR_BLANCAS);
//					
//				}
//			}
	//
//			estado.positionRey1.setNewPosition(7, 4);
//			estado.positionRey2.setNewPosition(0, 4);
			
			
		}
		
		@Override
		public CasillAjedrez getCasilla(int f, int c) 
		{
			return casillasAj[f][c];
		}

		@Override
		public void crearAtributos(int f, int c) 
		{
			casillasAj = new CasillAjedrez[f][c];
			listener = new MoveListener();
			casillasValidas = new ArrayList<CasillAjedrez>(25);
			Pieza.metodo = ()->{
//				copyEspecial = true;
				busquedasClick();
			};
		}

		@Override
		public void instanciar(byte i, byte j) 
		{
			casillasAj[i][j] = new CasillAjedrez(i, j, pintado ? firstColor : secondColor);
			casillasAj[i][j].addMouseListener(listener);
			super.add(casillasAj[i][j]);
		}
		
		@Override
		public void juegoNuevo(int modoJ,int varJ) 
		{
			estado.varianteJuego=varJ;
			estado.modoJuego=modoJ;
			modoConexion = (modoJ==MODO_SERVER || modoJ==MODO_CLIENT);
			tipoJuegos();
		}
		
		private void tipoJuegos()
		{
			setEstadoTo(true);
			
			switch(estado.varianteJuego)
			{
				case TRADICIONAL:
					ajedrezTradicional();
					break;
					
//				case ALETORIO_FISCHER:
//						if(listener.modoConexion = (modo == CSERVER))
//							if(!connect())
//								return;
//							
//						ajedrezAletorioDe(true);
//					break;
//					
//				case TRASCENDENTAL:
//						if(listener.modoConexion = (modo == CSERVER))
//							if(!connect())
//								return;
//							
//						ajedrezAletorioDe(false);
//					break;
					
				case JUBILADO:
					ajedrezJubilado();
					break;
			}
		}
		
		@Override
		public void reset() 
		{
			assertIJFor();
			removeCasillas();
			estado.reset();
//			movPeon=true;
			for(iFor=2; iFor<=5; iFor++)
			{
				for(jFor=0; jFor<columnas; jFor++)
				{
					casillasAj[iFor][jFor].setIcon(null);
					estado.actualizarTablero(iFor, jFor,(byte)0);
				}
			}
			
			casillasValidas.clear();
			
			reserIJ();
			tipoJuegos();
			
		}
		
		@Override
		public void cargarJuego() 
		{
			estado = (EstadoTablero) Serializa.writeObject(new File("/home/yeo/Escritorio/partida.jpp"));
			descodificar(estado.tablero);
			setEstadoTo(true);
			turno= JUGADOR_BLANCAS;
			//El turno ponerlo en estado tablero
		}
		
		@Override
		public void guardarJuego() 
		{
			// TODO Auto-generated method stub
			Serializa.saveObject(estado, new File("/home/yeo/Escritorio/partida.jpp"));
		}
		
		@Override
		public void guardarJugadas() 
		{
			Serializa.saveObject(jugadas, new File("/home/yeo/Escritorio/jugadas2.jcvg"));
		}
		
		
		public void busquedasClick()
		{
			casillasAj[k][l].validateCasilla(true);
			
			casillasValidas.add(casillasAj[k][l]);
		}
		
		public void removeCasillas()
		{
			casillasValidas.forEach((c)-> c.validateCasilla(false));
			
			casillasValidas.clear();
		}
		
		public void busquedasPC()
		{
			
		}
	
	}
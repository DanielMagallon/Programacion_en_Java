package Games.Ajedrez.Diseno;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.UIManager;
import javax.swing.border.MatteBorder;

import Games.Abstract.Variables;
import Games.Ajedrez.Perfomance.VarsChess;
import java.awt.CardLayout;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class PanelAjedrez extends JPanel 
{

	private static final long serialVersionUID = -2802525308470741997L;
	
	public static TableroAjedrez tableroAjedrez;
	
	JTextArea textArea;
	
	public PanelAjedrez() 
	{
		setBackground(Color.BLACK);
		
		JPanel panel = new JPanel();
		panel.setBorder(UIManager.getBorder("RootPane.colorChooserDialogBorder"));
		panel.setBackground(Color.DARK_GRAY);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new MatteBorder(3, 3, 3, 3, (Color) Color.BLUE));
		panel_1.setBackground(Color.DARK_GRAY);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBorder(new MatteBorder(3, 3, 3, 3, (Color) Color.CYAN));
		panel_2.setBackground(Color.DARK_GRAY);
		GroupLayout groupLayout = new GroupLayout(this);
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addContainerGap()
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addComponent(panel, GroupLayout.PREFERRED_SIZE, 562, GroupLayout.PREFERRED_SIZE)
						.addComponent(panel_1, GroupLayout.PREFERRED_SIZE, 563, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(panel_2, GroupLayout.DEFAULT_SIZE, 187, Short.MAX_VALUE)
					.addContainerGap())
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.TRAILING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(31)
					.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
						.addComponent(panel_2, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 629, Short.MAX_VALUE)
						.addGroup(Alignment.LEADING, groupLayout.createSequentialGroup()
							.addComponent(panel, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(panel_1, GroupLayout.DEFAULT_SIZE, 70, Short.MAX_VALUE)))
					.addContainerGap())
		);
		panel_1.setLayout(null);
		
		JButton btnReiniciar = new JButton("Reiniciar");
		btnReiniciar.setForeground(Color.BLACK);
		btnReiniciar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) 
			{
				tableroAjedrez.reset();
				
			}
		});
		btnReiniciar.setBounds(12, 33, 85, 25);
		btnReiniciar.setBackground(Color.LIGHT_GRAY);
		panel_1.add(btnReiniciar);
		
		JLabel label = new JLabel("00:00");
		label.setForeground(Color.BLACK);
		label.setVerticalAlignment(SwingConstants.BOTTOM);
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setFont(new Font("Dyuthi", Font.BOLD, 16));
		label.setOpaque(true);
		label.setBackground(Color.LIGHT_GRAY);
		label.setBounds(424, 34, 127, 25);
		panel_1.add(label);
		
		JButton btnGuardarPartida = new JButton("Guardar partida");
		btnGuardarPartida.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				tableroAjedrez.guardarJuego();
			}
		});
		btnGuardarPartida.setBackground(Color.LIGHT_GRAY);
		btnGuardarPartida.setForeground(Color.BLACK);
		btnGuardarPartida.setBounds(110, 33, 146, 25);
		panel_1.add(btnGuardarPartida);
		
		JButton btnGuardarJugadas = new JButton("Guardar jugadas");
		btnGuardarJugadas.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				tableroAjedrez.guardarJugadas();
			}
		});
		btnGuardarJugadas.setBackground(Color.LIGHT_GRAY);
		btnGuardarJugadas.setForeground(Color.BLACK);
		btnGuardarJugadas.setBounds(267, 33, 139, 25);
		panel_1.add(btnGuardarJugadas);
		
		JButton btnServidor = new JButton("Servidor");
		btnServidor.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) 
			{
				tableroAjedrez.juegoNuevo(Variables.MODO_SERVER, VarsChess.TRADICIONAL);
			}
		});
		
		JButton btnCliente = new JButton("Cliente");
		btnCliente.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) 
			{
				tableroAjedrez.juegoNuevo(Variables.MODO_CLIENT, VarsChess.TRADICIONAL);
			}
		});
		
		JScrollPane scrollPane = new JScrollPane();
		
		JButton btnClonar = new JButton("Clonar");
		btnClonar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				tableroAjedrez.pc.estado = tableroAjedrez.getEstadoActual().copy();
			}
		});
		
		JButton btnMostrar = new JButton("Mostrar");
		btnMostrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				textArea.setText("");
				
				tableroAjedrez.pc.estado.mostrar((a)->{
					
					textArea.append((String)a);
					
				});
			}
		});
		
		JButton btnCargar = new JButton("Cargar");
		btnCargar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				tableroAjedrez.cargarJuego();
			}
		});
		GroupLayout gl_panel_2 = new GroupLayout(panel_2);
		gl_panel_2.setHorizontalGroup(
			gl_panel_2.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_2.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_panel_2.createParallelGroup(Alignment.TRAILING, false)
						.addComponent(btnCliente, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addComponent(btnServidor, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(btnCargar)
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
				.addGroup(gl_panel_2.createSequentialGroup()
					.addContainerGap()
					.addComponent(btnClonar)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(btnMostrar, GroupLayout.PREFERRED_SIZE, 72, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(19, Short.MAX_VALUE))
				.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 181, Short.MAX_VALUE)
		);
		gl_panel_2.setVerticalGroup(
			gl_panel_2.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_2.createSequentialGroup()
					.addGap(22)
					.addGroup(gl_panel_2.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnServidor)
						.addComponent(btnCargar))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(btnCliente)
					.addGroup(gl_panel_2.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_panel_2.createSequentialGroup()
							.addPreferredGap(ComponentPlacement.RELATED, 22, Short.MAX_VALUE)
							.addComponent(btnClonar))
						.addGroup(gl_panel_2.createSequentialGroup()
							.addGap(18)
							.addComponent(btnMostrar)))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 318, GroupLayout.PREFERRED_SIZE)
					.addGap(162))
		);
		
		 textArea = new JTextArea();
		scrollPane.setViewportView(textArea);
		panel_2.setLayout(gl_panel_2);
		panel.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		tableroAjedrez = new TableroAjedrez((byte)8,(byte) 8,Color.LIGHT_GRAY, Color.gray);
		//new Color(0xecd49c),new Color(0xbf9e52)
		panel.add(tableroAjedrez);
		tableroAjedrez.juegoNuevo(Variables.MODO_NORMAL, VarsChess.TRADICIONAL);
		setLayout(groupLayout);
	}
}


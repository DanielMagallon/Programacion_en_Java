package Games.Ajedrez.Diseno;

public class EscogeFicha{

}

package Games.Abstract;

import java.io.Serializable;

public interface Especial extends Serializable
{
	Object especial_action();
}

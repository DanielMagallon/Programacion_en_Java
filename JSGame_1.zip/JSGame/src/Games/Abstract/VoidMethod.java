package Games.Abstract;

public interface VoidMethod
{

	public void method();
	
}

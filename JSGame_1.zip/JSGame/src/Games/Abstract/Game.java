package Games.Abstract;


public interface Game 
{
	void juegoNuevo(int modoJuego,int variante);
	void cargarJuego();
	void guardarJuego();
	void guardarJugadas();
	boolean connect();
}

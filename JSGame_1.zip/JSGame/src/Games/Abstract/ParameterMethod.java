package Games.Abstract;

public interface ParameterMethod {

	void get(Object obj);
}

package Games.Abstract;

import java.awt.Color;

import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.border.Border;


public class Variables 
{
	public static Border bordeCasillas = BorderFactory.createLineBorder(Color.black);
	
	//public static String path = Variables.class.getResource("/").getPath();

//	public static Icon rootIcon = getImage("/", "root.png"),
//			chess = getImage("/", "chess"),
//			damas = getImage("/", "damas.png"),
//			videos = getImage("/", "videos.png"),
//			play = getImage("/", "ver.png"),
//			partidas = getImage("/", "archivo.png"),
//			cargarPart = getImage("/", "play.png"),
//			fichero = getImage("/", "fich.png"),
//			pack = getImage("/", "package.png"),
//			pieces = getImage("/", "piezas.png");
	
	
	
	public static final byte JvsJ = 1, JvsPC = 2, CSERVER = 3, CCLIENT = 4;
	
	public static byte iFor,jFor;
	
//	public static boolean x;
	
	public static void reserIJ()
	{
		iFor = jFor = 0;
	}
	
	public static void assertIJFor()
	{
		if( iFor!=0 || jFor != 0)
			throw new RuntimeException("Los valores de i_jFor no estan en 0");
	}
	
	public static byte[] convertArray(String arr[])
	{
		byte x[] = new byte[arr.length];
		
		for(int i=0; i<x.length; i++)
			x[i] = Byte.parseByte(arr[i]);
		
		return x;
	}
	
	public static Icon getImage(String carpeta, String file)
	{
		return new ImageIcon(Variables.class.getResource("/Img"+carpeta+file));
	}
}

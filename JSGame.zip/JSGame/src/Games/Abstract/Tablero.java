package Games.Abstract;

import static Games.Abstract.Variables.iFor;
import static Games.Abstract.Variables.jFor;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;

import javax.swing.JLabel;
import javax.swing.JPanel;


public abstract class Tablero extends JPanel implements Game
{

	private static final long serialVersionUID = 3653183218781865085L;
	public boolean pintado;
	protected JPanel panelJuego;
	public Color firstColor,secondColor;
	public byte filas,columnas;
	
	public Tablero(byte f, byte c,boolean addTexts, Color c1, Color c2) 
	{
		filas = f;
		columnas = c;
		pintado=true;
		setLayout(new BorderLayout(10,10));
		firstColor = c1;
		secondColor = c2;
		panelJuego = new JPanel();
		panelJuego.setLayout(new GridLayout(f,c,3,3));
		add(panelJuego,"Center");
		
		if(addTexts)
		{
			JPanel panelFilas = new JPanel();
			panelFilas.setLayout(new GridLayout(8,1));
			add(panelFilas,"West");
			
			for(iFor=0; iFor<f; iFor++)
			{
				JLabel lbl = new JLabel(iFor+"",JLabel.CENTER);
				panelFilas.add(lbl);
			}
			
			JPanel panelCols = new JPanel();
			panelCols.setLayout(new GridLayout(1,8,3,3));
			add(panelCols,"North");
	
			int v = iFor+c;
			for(iFor=65; iFor<=v; iFor++)
			{
				panelCols.add(new JLabel(( (char) (iFor))+"",JLabel.CENTER));
			}
			
		}
		
		crearAtributos(f,c);
		
		for(iFor=0; iFor<f; iFor++)
		{
			for(jFor=0; jFor<c; jFor++)
			{
				instanciar(iFor, jFor);
				pintado=!pintado;
			}
			
			pintado=!pintado;
		}
		
		Variables.reserIJ();
	}
	
	public abstract void reset(); 
	public abstract void crearAtributos(int f, int c);
	public abstract void instanciar(byte i,byte j);
	public abstract Casilla getCasilla(int i,int j);
}



package Games.Ajedrez.Perfomance;

import java.awt.Color;
import java.io.Serializable;

import Games.ListPositions;

public class GuardaJugadas implements Serializable 
{
	
	private static final long serialVersionUID = 87964580646661306L;
	public Color c1,c2;
	public CasillaData[][] estadoInicial;
	public ListPositions<Position> lista; 
	
	public GuardaJugadas(CasillaData casillas[][],Color color1,Color color2) 
	{
		estadoInicial = new CasillaData[casillas.length][casillas[0].length];
		
		for(int i=0; i<casillas.length; i++)
		{
			for(int j=0; j<casillas[0].length; j++)
			{
				try {
					estadoInicial[i][j] = (CasillaData) casillas[i][j].clone();
				} catch (CloneNotSupportedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		c1 = color1;
		c2 = color2;
		lista = new ListPositions<>();
	}
	
	public void addJugada(Position posF,Position posT)
	{
		lista.insertPositions(posF, posT);
	}
}

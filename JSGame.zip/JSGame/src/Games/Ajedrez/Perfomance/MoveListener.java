package Games.Ajedrez.Perfomance;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import Conexiones.Constants;
import Games.Ajedrez.Diseno.CasillAjedrez;

import static Games.Ajedrez.Perfomance.VarsChess.continued;
import static Games.Ajedrez.Perfomance.VarsChess.piezaEnJuego;
import static Games.Ajedrez.Perfomance.VarsChess.turno;

import static Games.Ajedrez.Diseno.TableroAjedrez.tableroAjedrez;

public class MoveListener extends MouseAdapter implements Constants
{
	private CasillAjedrez casillaTocada,casillaMeneada;
	private byte filaT,columnaT,filaM,columnaM;
	private boolean haEscogido;
	public boolean modoConexion;
	
	
	@Override
	public void mouseClicked(MouseEvent e) 
	{
		
		if(!haEscogido)
		{
			
			casillaTocada = (CasillAjedrez) e.getComponent();
			escoge();
		}
		else
		{
			casillaMeneada =  (CasillAjedrez) e.getComponent();
			filaM = casillaMeneada.fila;
			columnaM = casillaMeneada.columna;
			
			menea();
		}
	}
	
	public void menea()
	{
//		if(casillaMeneada.isValid)
		{
			casillaMeneada.setIcon(casillaTocada.getIcon());
			casillaTocada.setIcon(null);

			tableroAjedrez.propierties.copyPropierties(filaT, columnaT, filaM, columnaM);
			
			tableroAjedrez.jugadas.addJugada(new Position(filaT,columnaT), new Position(filaM,columnaM));
			
//			movEsepcial();
			
			
//			if(!modoConexion)
//			{
				turno = (byte) -turno;
//			}else {
//					tableroAjedrez.tcp.write(FROM_TO,String.format("%d,%d,%d,%d", filaT,columnaT,filaM,columnaM));
//				continued=false;
//			}
			
			
			
			tableroAjedrez.getEstadoActual().mostrar();
			
		}
		
		casillaTocada.defaultColor();
		tableroAjedrez.removeCasillas();
		haEscogido = false;
	}
	
	public void movEsepcial()
	{
		
		
		if(CasillAjedrez.fromEspecial != null && CasillAjedrez.toEspecial!=null)
		{
			if(modoConexion)
				tableroAjedrez.tcp.write(FROM_TO,String.format("%d,%d,%d,%d", CasillAjedrez.fromEspecial.fila,
						CasillAjedrez.fromEspecial.columna,CasillAjedrez.toEspecial.fila,
						CasillAjedrez.toEspecial.columna));
			
			CasillAjedrez.toEspecial.setIcon(CasillAjedrez.fromEspecial.getIcon());
			CasillAjedrez.fromEspecial.setIcon(null);
			CasillAjedrez.fromEspecial = CasillAjedrez.toEspecial = null;
		}
		else {
			if(CasillAjedrez.fromEspecial!=null)
			{
				if(modoConexion)
				tableroAjedrez.tcp.write(FROM,String.format("%d,%d", CasillAjedrez.fromEspecial.fila,
						CasillAjedrez.fromEspecial.columna));
				CasillAjedrez.fromEspecial.setIcon(null);
				CasillAjedrez.fromEspecial = null;
			}
			
		}
		
		if(tableroAjedrez.getEstadoActual().casillaPaso1 != null || tableroAjedrez.getEstadoActual().casillaPaso2 != null) 
			tableroAjedrez.getEstadoActual().nullCasillas(turno, false);
	}
	
	public void escoge()
	{
		if(casillaTocada.getIcon()!=null)
		{
			filaT = casillaTocada.fila;
			columnaT = casillaTocada.columna;
		
			if(validarTurno())
			{
				piezaEnJuego = tableroAjedrez.getEstadoActual().get(filaT, columnaT).pieza;
				casillaTocada.select();
				piezaEnJuego.buscaCaminos(filaT, columnaT);
				haEscogido = true;
			}
		}
	}
	
	public boolean validarTurno()
	{
		return continued && tableroAjedrez.getEstadoActual().get(filaT, columnaT).valor == turno;
	}
}

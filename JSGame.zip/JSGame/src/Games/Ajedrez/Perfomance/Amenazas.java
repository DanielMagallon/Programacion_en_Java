package Games.Ajedrez.Perfomance;

import Games.Abstract.BooleanMethod;
import Games.Abstract.VoidMethod;

import static Games.Ajedrez.Perfomance.VarsChess.alfil;
import static Games.Ajedrez.Perfomance.VarsChess.torre;
import static Games.Ajedrez.Perfomance.VarsChess.movsLibre;
import static Games.Ajedrez.Perfomance.VarsChess.movsCaballo;

import static Games.Ajedrez.Diseno.TableroAjedrez.tableroAjedrez;


public class Amenazas 
{
	private static BooleanMethod metodo;
	private static byte index,filaAct,colAct;

	public static void breakOnFoundDanger()
	{
		metodo = () -> {
			return true;
		};
		
	}
	
	
	public static void setOnFoundDanger(VoidMethod vm)
	{
		metodo = () -> {
			vm.method();
			return false;
		};
	}
	
	public static void setActualPosition(byte f, byte c)
	{
		filaAct = f;
		colAct = c;
	}
	
	public static boolean buscaPiezas(byte f, byte c, int player, boolean breakAfound, boolean enemigas)
	{
		if(enemigas)
			player=-player;
		
		//Esta condicion debe ir asi
		//Ya que si la hacems alreves evaluara primero el breakAFound y dado que esta
		//variable estara algunas veces en true pues no entrara al metodo del caballo
		//e inmediatamente retornara true;
		//Esta condicion no respeta la ley ..... ya que  (x && y) = (y && x) pero aqui no respeta eso. 
		if(amenazaCaballo(f, c, player) && breakAfound)
				return true;
		
		return amenazaOtra(f, c, player);
	}
	
	public static boolean amenazaOtra(byte f, byte c, int player)
	{
		Pieza aux = torre;
		int m,n;
		boolean enemigo=false;
		
		for(index=0; index<movsLibre.length; index++)
		{
			if(index==4)
				aux = alfil;
			
			m = f+movsLibre[index][0];
			n = c+movsLibre[index][1];
			
				while(true)
				{
					if(!tableroAjedrez.getEstadoActual().isValidPosition(m, n))
						break;
					
					if(tableroAjedrez.getEstadoActual().tablero[m][n].estaVacia() || (m==filaAct && n==colAct))
					{
						m += movsLibre[index][0];
						n += movsLibre[index][1];
						continue;
					}
					
					else if(tableroAjedrez.getEstadoActual().tablero[m][n].esDamaDe(player) ||
							tableroAjedrez.getEstadoActual().tablero[m][n].esPiezaDe(aux, player))
					{
						if(!enemigo)
							enemigo=true;
						
						if(metodo.getBool())
						{
							return true;
						}
					
						else break;
					}
					
					break;
				}
		}
		
		return enemigo;
	}
	
	public static boolean amenazaCaballo(byte f, byte c, int player)
	{
		int m,n;
		boolean enemigo=false;
		
		for(index=0; index<movsCaballo.length; index++)
		{
			m = f+movsCaballo[index][0];
			n = c+movsCaballo[index][1]; 
			
			if(!tableroAjedrez.getEstadoActual().isValidPosition(m, n))
				continue;
			
			if(tableroAjedrez.getEstadoActual().tablero[m][n].esCaballoDe(player))
			{
				if(!enemigo)
					enemigo=true;
				
				if(metodo.getBool())
					return true;
			}
		}
		return enemigo;
	}
}

package Games.Ajedrez.Perfomance;

import static Games.Ajedrez.Perfomance.VarsChess.JUGADOR_BLANCAS;
import static Games.Ajedrez.Perfomance.VarsChess.SIN_ENROQUE;
import static Games.Ajedrez.Perfomance.VarsChess.torre;
import static Games.Ajedrez.Perfomance.VarsChess.turno;

import Games.Ajedrez.Diseno.CasillAjedrez;

import static Games.Ajedrez.Perfomance.VarsChess.peon;
import static Games.Ajedrez.Perfomance.VarsChess.piezaEnJuego;
import static Games.Ajedrez.Perfomance.VarsChess.rey;

import static Games.Ajedrez.Diseno.TableroAjedrez.tableroAjedrez;

public class Propiedades 
{
	private  byte fromF,fromC,toF,toC;
	private EstadoTablero est;
	
	public void setEstado(EstadoTablero e)
	{
		est = e;
	}
	
	public  void copyPropierties(byte fromF,byte fromC,byte toF,byte toC)
	{
		this.fromF = fromF;
		this.fromC = fromC;
		this.toF = toF;
		this.toC = toC;
		
		est.actualizarTablero(fromF, fromC,turno);
		est.actualizarTablero(toF, toC, piezaEnJuego, turno);
		
//		if(piezaEnJuego == torre)
//		{
//			actualizarEnroque();
//		}
		
		//else 
//			if(piezaEnJuego == rey)
//		{
//			actualizarRey();
//		}
		
//		else if(piezaEnJuego == peon)
//		{
//			if(tablero.movPeon)
//				actualizaPeon();
//		}
		
		est.determinarTablas();
	}
	
	
	private  void actualizarRey()
	{

//		if(turno == JUGADOR_BLANCAS)
//		{
//			if(est.enroqueR1 != SIN_ENROQUE)
//			{
//				if(est.casillaI1!=null)
//				{
//					if(est.get(toF, toC) == est.casillaI1)
//					{
//						copyPropierties(toF, (byte)(est.columnas-1),toF , (byte)5,torre);
//					}
//				}
//				
//				else if(est.casillaD1!=null)
//				{
//					if(est.get(toF, toC) == est.casillaD1)
//					{
//						copyPropierties(toF, (byte)0, toF, (byte)3,torre);
//					}
//				}
//				
//				est.enroqueR1 = SIN_ENROQUE;
//				est.nullCasillas(turno,true);
//			}
//			
//			est.positionRey1.setNewPosition(toF, toC);
//		}
//		else
//		{
//			if(est.enroqueR2 != SIN_ENROQUE)
//			{
//				if(est.casillaI2!=null)
//				{
//					if(est.get(toF, toC) == est.casillaI2)
//					{
//						copyPropierties(toF, (byte)(est.columnas-1),toF , (byte)5,torre);
//					}
//				}
//				
//				else if(est.casillaD2!=null)
//				{
//					if(est.get(toF, toC) == est.casillaD2)
//					{
//						copyPropierties(toF,  (byte)0, toF,  (byte)3,torre);
//					}
//				}
//				
//				est.enroqueR2 = SIN_ENROQUE;
//				est.nullCasillas(turno,true);
//			}
//			
//			est.positionRey2.setNewPosition(toF, toC);
//		}
	}
	
	private  void copyPropierties(byte fromF,byte fromC,byte toF,byte toC,Pieza piezaEnJuego)
	{
		est.actualizarTablero(fromF, fromC,turno);
		est.actualizarTablero(toF, toC, piezaEnJuego, turno);
		
		if(tableroAjedrez!=null)
			if(tableroAjedrez.copyEspecial)
			{
				CasillAjedrez.fromEspecial = tableroAjedrez.casillasAj[fromF][fromC];
				CasillAjedrez.toEspecial = tableroAjedrez.casillasAj[toF][toC];
			}
	}
}

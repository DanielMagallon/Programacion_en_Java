package Games.Ajedrez.Perfomance;


import javax.swing.Icon;

import Games.Abstract.VoidMethod;

import java.io.Serializable;

import static Games.Ajedrez.Perfomance.VarsChess.JUGADOR_BLANCAS;
import static Games.Ajedrez.Perfomance.VarsChess.turno;

import static Games.Ajedrez.Diseno.TableroAjedrez.tableroAjedrez;

public abstract class Pieza implements Serializable
{
	
	private static final long serialVersionUID = 3564217027542927155L;
	public String nombre,clave;
	public byte valor;
	
	public static VoidMethod metodo;
	
	public abstract Icon getPieza(byte player);
	public abstract void buscaCaminos(byte f, byte c);

	public boolean esEnemigo(int f, int c)
	{
		try
		{
		if(tableroAjedrez.getEstadoActual().get(f, c).estaVacia())
			return false;
		
		return turno==JUGADOR_BLANCAS  ? tableroAjedrez.getEstadoActual().get(f, c).esNegras() :
					tableroAjedrez.getEstadoActual().get(f, c).esBlancas();
		}
		catch(ArrayIndexOutOfBoundsException e) {
			return false;
		}
	}
	
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return nombre;
	}
}

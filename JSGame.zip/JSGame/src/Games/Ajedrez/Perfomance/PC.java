package Games.Ajedrez.Perfomance;

public class PC {

	public EstadoTablero estado;
	
	public PC(int f, int c) 
	{
		estado = new EstadoTablero(f, c);
	}
	
	
}

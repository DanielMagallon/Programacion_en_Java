package Games.Ajedrez.Perfomance;


import java.util.ArrayList;

import javax.swing.JOptionPane;


import static Games.Ajedrez.Perfomance.VarsChess.JUGADOR_BLANCAS;
import static Games.Ajedrez.Perfomance.VarsChess.ENROQUE_CORTO;
import static Games.Ajedrez.Perfomance.VarsChess.ENROQUE_LARGO;
import static Games.Ajedrez.Perfomance.VarsChess.SIN_ENROQUE;
import static Games.Ajedrez.Perfomance.VarsChess.estaTablas;
import static Games.Ajedrez.Perfomance.VarsChess.torre;
import static Games.Ajedrez.Perfomance.VarsChess.alfil;
import static Games.Ajedrez.Perfomance.VarsChess.valores;

import static Games.Abstract.Variables.iFor;
import static Games.Abstract.Variables.jFor;
import static Games.Abstract.Variables.assertIJFor;
import static Games.Abstract.Variables.reserIJ;

import static javax.swing.JOptionPane.*;


public class EstadoTablero  
{

	public CasillaData tablero[][];
	
	public Position positionRey1,positionRey2;
	
	public byte enroqueR1,enroqueR2, a,b,acu;
	
	public CasillaData casillaD1,casillaI1,casillaD2,casillaI2,
						casillaPD1,casillaPD2,casillaPI1,casillaPI2,
						casillaPaso1,casillaPaso2;
	
	public ArrayList<CasillaData> piezasBlancas,piezasNegras;
	
	public int filas,columnas;
	
	public EstadoTablero(int f,int c)
	{
		tablero = new CasillaData[f][c];
		
		filas = f;
		columnas = c;
		
		assertIJFor();
		boolean x=true;
		for(; iFor<f; iFor++)
		{
			for(jFor=0;jFor<c; jFor++)
			{
				tablero[iFor][jFor] = new CasillaData(iFor, jFor,  (byte) (x ? 1 : 2));
				x=!x;
			}
			x=!x;
		}
		
		positionRey1 = new Position();
		positionRey2 = new Position();
		piezasBlancas = new ArrayList<CasillaData>(16);
		piezasNegras = new ArrayList<CasillaData>(16);
		
		reserIJ();
	}

	public void especial(int player, boolean der, int f, int c, boolean torres)
	{
		if(player == JUGADOR_BLANCAS)
		{
			if(der)
				if(torres)
					casillaD1 = tablero[f][c];
				else {
					casillaPD1 = tablero[f][c];
					casillaPaso1 = tablero[f-1][c-1];

				}
			
			else {
				if(torres)
					casillaI1 = tablero[f][c];
				else {
					casillaPI1 = tablero[f][c];
					casillaPaso1 = tablero[f-1][c+1];

				}
			}
		}
		else
		{
			if(der)
				if(torres)
					casillaD2 = tablero[f][c];
				else {
					casillaPD2 = tablero[f][c];
					casillaPaso2 = tablero[f+1][c-1];
				}
			else {
				if(torres)
					casillaI2 = tablero[f][c];
				else {
					casillaPI2 = tablero[f][c];
					casillaPaso2 = tablero[f+1][c+1];
				}
			}
				
		}
	}
	
	public void nullCasillas(int player,boolean torres)
	{
		if(player == JUGADOR_BLANCAS)
			if(torres)
				casillaI1 = casillaD1 = null;
			else casillaPaso1 = casillaPD1 = casillaPI1 = null;
		
		else {
			if(torres)
				casillaI2 = casillaD2 = null;
			
			else casillaPaso2 = casillaPD2 = casillaPI2 = null;
		}
	}
	
	
	public void actualizarTablero(int f, int c,Pieza pieza,byte val)
	{
		if(val == JUGADOR_BLANCAS)
		{
			piezasBlancas.add(tablero[f][c]);
			
			//Indica que las blancas se comieron una pieza
			if(tablero[f][c].pieza != null)
			{
				piezasNegras.remove(tablero[f][c]);
			}
		}
		else {
			piezasNegras.add(tablero[f][c]);
			
			if(tablero[f][c].pieza != null)
			{
				piezasBlancas.remove(tablero[f][c]);
			}
		}
		
		tablero[f][c].actualizar(val, pieza);
		
	}
	

	public void actualizarTablero(int f, int c, byte val)
	{
		tablero[f][c].actualizar((byte) -1, null);
		
		if(val == JUGADOR_BLANCAS)
			piezasBlancas.remove(tablero[f][c]);
		
		else if(val == -JUGADOR_BLANCAS)
			piezasNegras.remove(tablero[f][c]);
	}
	
	public boolean isValidPosition(int f, int c)
	{
		return f>=0 && f<tablero.length && c>=0 && c<tablero[0].length;
	}
	
	public CasillaData get(int f, int c)
	{
		return tablero[f][c];
	}
	
	public void reset()
	{
		piezasBlancas.clear();
		piezasNegras.clear();
	}
	
	
	public void mostrar()
	{
		System.out.println("Estado del tablero: ");
		for(CasillaData x[] : tablero)
		{
			for(CasillaData y : x)
			{
				System.out.print("\"");
				System.out.print(y.casillaName);
				System.out.print ("\" ");
			}
			
			System.out.println();
		}
		
//		System.out.println("Piezas blancas: "+piezasBlancas);
//		System.out.println("Piezas negras: "+piezasNegras);
		
		System.out.println("\n-------------------");
	}
	
	public void determinarTablas()
	{
		piezasSobrantes();
	}
	
	
	private void piezasSobrantes()
	{
		//Tablas por rey, y dos caballos vs rey
		if( (piezasBlancas.size()==3 && piezasNegras.size()==1) 
				|| (piezasBlancas.size()==1 && piezasNegras.size()==3))
		{
			if(suma(false) == valores[4])
			{
				JOptionPane.showMessageDialog(null, "Juego empatado/Tablas");
			}
		}
		
		else if(piezasBlancas.size()<=2 && piezasNegras.size()<=2)
		{
			acu=0;
			
			int x = estaTablas(suma(true));
			
			if(x!=-1)
			{
				if(x == VarsChess.valores.length-1)
				{
					if(acu==2)
						JOptionPane.showMessageDialog(null, "Juego empatado/Tablas");
				}
				
				else JOptionPane.showMessageDialog(null, "Juego empatado/Tablas");
			}
		}
	}
	
	private int suma(boolean checkAlfil)
	{
		a=b=0;
		
		piezasBlancas.forEach((cas)->{
			a+=cas.pieza.valor;
				
			if(checkAlfil)
				if(cas.pieza == alfil)
					acu = cas.id_color;
			
		});
		
		piezasNegras.forEach((cas)->{
			b+=cas.pieza.valor;
			
			if(checkAlfil)
				if(cas.pieza == alfil)
					acu = (byte) ((acu==cas.id_color) ? 2 : -1);
		});
		
		return a+b;
	}
	
	
//	public String[][] getStringTablero()
//	{
//		
//	}
}

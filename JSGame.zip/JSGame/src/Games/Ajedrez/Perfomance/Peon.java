
package Games.Ajedrez.Perfomance;

import javax.swing.Icon;

import static Games.Ajedrez.Perfomance.VarsChess.k;
import static Games.Ajedrez.Perfomance.VarsChess.l;
import static Games.Ajedrez.Perfomance.VarsChess.turno;
import static Games.Ajedrez.Diseno.TableroAjedrez.tableroAjedrez;


@SuppressWarnings("serial")
public class Peon extends Pieza 
{
	
	private byte inc,filaDoblePaso;
	
	public Peon(byte val) {
		// TODO Auto-generated constructor stub
		nombre="peon";
		clave="P";
		valor = val;
	}
	
	@Override
	public Icon getPieza(byte pl) 
	{
		if(pl==VarsChess.JUGADOR_BLANCAS)
			return VarsChess.PEON;
		
		else if(pl==VarsChess.JUGADOR_NEGRAS)
			return VarsChess.PEON2;
		
		return null;
	} 
	

	@Override
	public void buscaCaminos(byte f, byte c)
	{
		if(turno == VarsChess.JUGADOR_BLANCAS) 
		{
			inc = -1;
			filaDoblePaso = (byte) (tableroAjedrez.filas-4);
		}
		else 
		{			
			inc = 1;
			filaDoblePaso = 3;
		}
		
		if(tableroAjedrez.getEstadoActual().get(f+inc, c).estaVacia())
		{
			l = c;
			k = (byte) (f+inc);
			metodo.method();
			
			if(f == filaDoblePaso + (-2*inc))
				if(tableroAjedrez.getEstadoActual().get(filaDoblePaso, c).estaVacia())
				{
					k = filaDoblePaso;
					metodo.method();
				}
		}
		
		if(esEnemigo(f+inc, c+1))
		{
			k = (byte) (f+inc);
			l = (byte) (c+1);
			
			metodo.method();
		}
		
		if(esEnemigo(f+inc, c-1))
		{
			k = (byte) (f+inc);
			l = (byte) (c-1);
			
			metodo.method();
		}
		
		CasillaData cas = tableroAjedrez.getEstadoActual().get(f, c);
		
		if(turno==VarsChess.JUGADOR_BLANCAS)
			if(cas == tableroAjedrez.getEstadoActual().casillaPD1 || cas == tableroAjedrez.getEstadoActual().casillaPI1)
			{
				k = tableroAjedrez.getEstadoActual().casillaPaso1.f;
				l = tableroAjedrez.getEstadoActual().casillaPaso1.c;
				metodo.method();
				
				
			}else;
		else
		{
			if(cas == tableroAjedrez.getEstadoActual().casillaPD2 || cas == tableroAjedrez.getEstadoActual().casillaPI2)
			{
				k = tableroAjedrez.getEstadoActual().casillaPaso2.f;
				l = tableroAjedrez.getEstadoActual().casillaPaso2.c;
				metodo.method();
				
			}else;
		}
		
		
	}
}
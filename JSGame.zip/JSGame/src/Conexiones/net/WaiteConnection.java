package Conexiones.net;

import javax.swing.JFrame;

public abstract class WaiteConnection 
{
	
	
	public abstract void waitClient(Server ss, JFrame f); 
	
	
}

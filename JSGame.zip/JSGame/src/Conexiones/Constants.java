package Conexiones;

public interface Constants {
	
	int CLIENT_DESCONECTED=-2;
	int WRITE_FILE=5;
	int CODIFICAR=1;
	int FROM=2;
	int FROM_TO=3;
}

package Conexiones;

public interface ConectionListener {

	void onDesconected();
	void onConected();
}
